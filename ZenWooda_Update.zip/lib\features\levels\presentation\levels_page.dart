import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../../core/theme/game_theme.dart';
import '../../../core/services/sound_manager.dart';
import '../../../core/providers/coin_provider.dart';
import '../../auth/data/user_repository.dart';
import '../../auth/domain/auth_notifier.dart';
import '../../game/game_screen.dart';
import '../../starter_rewards/presentation/starter_rewards_popup.dart';
import '../data/level_config.dart';

// ─────────────────────────────────────────────
//  LevelsPage — neon dark UI
//  Unlocking: highScore-based
//  Stars: score-based per level goal
// ─────────────────────────────────────────────

int _visibleCount(int highScore) {
  final unlocked = (highScore ~/ 300) + 1;
  return (unlocked + 3).clamp(15, 999);
}

bool _isLevelUnlocked(int levelNumber, int highScore) {
  final config = LevelConfig.forLevel(levelNumber);
  final unlockScore = (levelNumber - 1) * 300;
  return highScore >= unlockScore;
}

int _computeStars(LevelConfig level, int highScore) {
  return level.starsEarned(highScore);
}

Color _neonColorForLevel(int number) {
  final hue = (number * 24.0) % 360.0;
  return HSLColor.fromAHSL(1.0, hue, 0.95, 0.65).toColor();
}

// ─────────────────────────────────────────────
//  LevelsPage
// ─────────────────────────────────────────────

class LevelsPage extends ConsumerStatefulWidget {
  const LevelsPage({super.key});

  @override
  ConsumerState<LevelsPage> createState() => _LevelsPageState();
}

class _LevelsPageState extends ConsumerState<LevelsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _headerCtrl;
  late Animation<double> _headerAnim;

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _headerAnim = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerCtrl.forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(soundManagerProvider).playMusic('background.mp3');
    });
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userAsync = ref.watch(userProfileProvider);
    final auth = ref.watch(authNotifierProvider);
    // Real-time coin balance
    final coins = ref.watch(coinProvider).valueOrNull ??
        userAsync.valueOrNull?.coins ??
        0;

    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: Stack(
        children: [
          const _NeonBg(),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FadeTransition(
                  opacity: _headerAnim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, -0.3),
                      end: Offset.zero,
                    ).animate(_headerAnim),
                    child: _Header(
                      userAsync: userAsync,
                      coins: coins,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: userAsync.when(
                    data: (user) => _LevelGrid(
                      highScore: user?.highScore ?? 0,
                      coins: coins,
                    ),
                    loading: () => const Center(
                      child: CircularProgressIndicator(
                          color: Color(0xFF00F5FF)),
                    ),
                    error: (_, __) =>
                        _LevelGrid(highScore: 0, coins: coins),
                  ),
                ),
              ],
            ),
          ),

          // Starter rewards popup
          if (auth.shouldShowStarterRewards)
            StarterRewardsPopup(
              theme: beachTheme,
              onDismiss: () {
                ref
                    .read(authNotifierProvider.notifier)
                    .clearStarterRewardsFlag();
              },
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Animated Neon Background
// ─────────────────────────────────────────────

class _NeonBg extends StatelessWidget {
  const _NeonBg();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.5),
          radius: 1.4,
          colors: [
            Color(0xFF0A1830),
            Color(0xFF040D1A),
            Color(0xFF020810),
          ],
          stops: [0.0, 0.6, 1.0],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Header
// ─────────────────────────────────────────────

class _Header extends StatelessWidget {
  final AsyncValue<UserModel?> userAsync;
  final int coins;

  const _Header({required this.userAsync, required this.coins});

  @override
  Widget build(BuildContext context) {
    final highScore = userAsync.valueOrNull?.highScore ?? 0;
    final username = userAsync.valueOrNull?.username ?? '';

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (username.isNotEmpty)
                    Text(
                      'Hello, $username 👋',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Color(0xFF00F5FF), Color(0xFFBF40FF)],
                    ).createShader(bounds),
                    child: const Text(
                      'LEVELS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 6,
                      ),
                    ),
                  ),
                ],
              ),
              _AnimatedCoinBadge(coins: coins),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                Icons.emoji_events_rounded,
                color: const Color(0xFFFFD700).withOpacity(0.7),
                size: 14,
              ),
              const SizedBox(width: 4),
              Text(
                'Best  $highScore pts',
                style: const TextStyle(
                  color: Color(0x8000F5FF),
                  fontSize: 12,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Animated Coin Badge (real-time updates)
// ─────────────────────────────────────────────

class _AnimatedCoinBadge extends StatefulWidget {
  final int coins;
  const _AnimatedCoinBadge({required this.coins});

  @override
  State<_AnimatedCoinBadge> createState() => _AnimatedCoinBadgeState();
}

class _AnimatedCoinBadgeState extends State<_AnimatedCoinBadge>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulse = Tween(begin: 0.08, end: 0.25)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFFFFD700).withOpacity(0.15),
              const Color(0xFFFF8F00).withOpacity(0.08),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0xFFFFD700).withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFFFD700)
                  .withOpacity(0.08 + _pulse.value * 0.1),
              blurRadius: 14,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.monetization_on_rounded,
                color: Color(0xFFFFD700), size: 16),
            const SizedBox(width: 6),
            Text(
              '$widget.coins',
              style: const TextStyle(
                color: Color(0xFFFFD700),
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Grid
// ─────────────────────────────────────────────

class _LevelGrid extends StatelessWidget {
  final int highScore;
  final int coins;
  const _LevelGrid({required this.highScore, required this.coins});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.82,
      ),
      itemCount: _visibleCount(highScore),
      itemBuilder: (context, i) {
        final levelNum = i + 1;
        final config = LevelConfig.forLevel(levelNum);
        final isUnlocked = _isLevelUnlocked(levelNum, highScore);
        final stars = isUnlocked ? _computeStars(config, highScore) : 0;
        return _LevelTile(
          config: config,
          isUnlocked: isUnlocked,
          stars: stars,
        );
      },
    );
  }
}

// ─────────────────────────────────────────────
//  Level Tile
// ─────────────────────────────────────────────

class _LevelTile extends StatefulWidget {
  final LevelConfig config;
  final bool isUnlocked;
  final int stars;

  const _LevelTile({
    required this.config,
    required this.isUnlocked,
    required this.stars,
  });

  @override
  State<_LevelTile> createState() => _LevelTileState();
}

class _LevelTileState extends State<_LevelTile>
    with TickerProviderStateMixin {
  late AnimationController _tapCtrl;
  late Animation<double> _tapScale;
  late AnimationController _glitterCtrl;
  late Animation<double> _glitterAnim;

  @override
  void initState() {
    super.initState();
    _tapCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 110),
    );
    _tapScale = Tween(begin: 1.0, end: 0.91)
        .animate(CurvedAnimation(parent: _tapCtrl, curve: Curves.easeIn));

    _glitterCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );
    _glitterAnim =
        CurvedAnimation(parent: _glitterCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _tapCtrl.dispose();
    _glitterCtrl.dispose();
    super.dispose();
  }

  void _onTap(BuildContext context) {
    if (!widget.isUnlocked) return;
    HapticFeedback.lightImpact();
    _glitterCtrl.forward(from: 0);
    final nav = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => _LevelDialog(
        config: widget.config,
        stars: widget.stars,
        onPlay: () {
          nav.pop();
          nav.push(MaterialPageRoute<void>(
            builder: (_) => GameScreen(levelConfig: widget.config),
          ));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final neon = _neonColorForLevel(widget.config.number);
    final isUnlocked = widget.isUnlocked;
    final stars = widget.stars;
    final diff = widget.config.difficulty;

    return GestureDetector(
      onTapDown:
          isUnlocked ? (_) => _tapCtrl.forward() : null,
      onTapUp: isUnlocked
          ? (_) {
              _tapCtrl.reverse();
              _onTap(context);
            }
          : null,
      onTapCancel: isUnlocked ? () => _tapCtrl.reverse() : null,
      child: AnimatedBuilder(
        animation: _tapScale,
        builder: (_, child) =>
            Transform.scale(scale: _tapScale.value, child: child),
        child: Container(
          decoration: BoxDecoration(
            gradient: isUnlocked
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF0A1628).withOpacity(0.9),
                      const Color(0xFF0D1F3C).withOpacity(0.85),
                    ],
                  )
                : LinearGradient(
                    colors: [
                      const Color(0xFF070C14).withOpacity(0.7),
                      const Color(0xFF050A10).withOpacity(0.6),
                    ],
                  ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isUnlocked
                  ? neon.withOpacity(0.55)
                  : Colors.white.withOpacity(0.07),
              width: 1.5,
            ),
            boxShadow: isUnlocked
                ? [
                    BoxShadow(
                        color: neon.withOpacity(0.18), blurRadius: 12)
                  ]
                : [],
          ),
          child: Stack(
            children: [
              // Top sheen
              if (isUnlocked)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 1.5,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.white.withOpacity(0.25),
                          Colors.transparent,
                        ],
                      ),
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(14)),
                    ),
                  ),
                ),

              // Content
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 4, vertical: 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Level number
                    isUnlocked
                        ? ShaderMask(
                            shaderCallback: (bounds) =>
                                LinearGradient(
                              colors: [Colors.white, neon],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ).createShader(bounds),
                            child: Text(
                              '${widget.config.number}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          )
                        : Text(
                            '${widget.config.number}',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.18),
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                    const SizedBox(height: 3),
                    // Stars
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (i) {
                        final filled = i < stars;
                        return Icon(
                          filled
                              ? Icons.star_rounded
                              : Icons.star_outline_rounded,
                          color: filled
                              ? const Color(0xFFFFD700)
                              : Colors.white.withOpacity(0.12),
                          size: 12,
                          shadows: filled
                              ? [
                                  Shadow(
                                    color: const Color(0xFFFFD700)
                                        .withOpacity(0.7),
                                    blurRadius: 6,
                                  )
                                ]
                              : null,
                        );
                      }),
                    ),
                    const SizedBox(height: 3),
                    // Difficulty badge
                    if (isUnlocked)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 1),
                        decoration: BoxDecoration(
                          color: diff.color.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: diff.color.withOpacity(0.45),
                            width: 0.8,
                          ),
                        ),
                        child: Text(
                          diff.emoji,
                          style: const TextStyle(fontSize: 8),
                        ),
                      ),
                  ],
                ),
              ),

              // Lock overlay
              if (!isUnlocked)
                Positioned.fill(
                  child: Center(
                    child: Icon(
                      Icons.lock_rounded,
                      color: Colors.white.withOpacity(0.15),
                      size: 20,
                    ),
                  ),
                ),

              // Glitter on tap
              if (isUnlocked)
                AnimatedBuilder(
                  animation: _glitterAnim,
                  builder: (_, __) => Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: neon.withOpacity(
                            (1.0 - _glitterAnim.value) * 0.35,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Dialog Popup
// ─────────────────────────────────────────────

class _LevelDialog extends StatefulWidget {
  final LevelConfig config;
  final int stars;
  final VoidCallback onPlay;

  const _LevelDialog({
    required this.config,
    required this.stars,
    required this.onPlay,
  });

  @override
  State<_LevelDialog> createState() => _LevelDialogState();
}

class _LevelDialogState extends State<_LevelDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final neon = _neonColorForLevel(widget.config.number);
    final diff = widget.config.difficulty;
    final hasTimer = widget.config.timerSeconds != null;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 32),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xF80D1628), Color(0xF8090E1C)],
            ),
            borderRadius: BorderRadius.circular(28),
            border:
                Border.all(color: neon.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: neon.withOpacity(0.25),
                  blurRadius: 35,
                  spreadRadius: 2),
              BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 20),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Accent bar
              Container(
                height: 3,
                width: 48,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, neon, Colors.transparent],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              Text(
                'LEVEL',
                style: TextStyle(
                  color: neon.withOpacity(0.7),
                  fontSize: 11,
                  letterSpacing: 5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [neon, Colors.white],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ).createShader(bounds),
                child: Text(
                  '${widget.config.number}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    height: 1.0,
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Difficulty badge
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: diff.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: diff.color.withOpacity(0.5), width: 1),
                ),
                child: Text(
                  '${diff.emoji}  ${diff.label.toUpperCase()}',
                  style: TextStyle(
                    color: diff.color,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // Goal info row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _InfoChip(
                    icon: Icons.flag_rounded,
                    label: 'Goal',
                    value: '${widget.config.scoreGoal} pts',
                    color: const Color(0xFF00F5FF),
                  ),
                  if (hasTimer)
                    _InfoChip(
                      icon: Icons.timer_rounded,
                      label: 'Time',
                      value: '${widget.config.timerSeconds}s',
                      color: const Color(0xFFFF6B35),
                    )
                  else
                    _InfoChip(
                      icon: Icons.all_inclusive_rounded,
                      label: 'Time',
                      value: 'Unlimited',
                      color: const Color(0xFF4CAF50),
                    ),
                ],
              ),

              const SizedBox(height: 16),

              // Stars
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(3, (i) {
                  final filled = i < widget.stars;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Icon(
                      filled
                          ? Icons.star_rounded
                          : Icons.star_outline_rounded,
                      color: filled
                          ? const Color(0xFFFFD700)
                          : Colors.white.withOpacity(0.2),
                      size: 30,
                      shadows: filled
                          ? [
                              Shadow(
                                color: const Color(0xFFFFD700)
                                    .withOpacity(0.7),
                                blurRadius: 12,
                              )
                            ]
                          : null,
                    ),
                  );
                }),
              ),

              const SizedBox(height: 6),
              Text(
                _starMessage,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 12,
                  letterSpacing: 0.3,
                ),
              ),

              const SizedBox(height: 24),
              _PlayButton(onTap: widget.onPlay, color: neon),
              const SizedBox(height: 14),

              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Text(
                  'CANCEL',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.25),
                    fontSize: 11,
                    letterSpacing: 2.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String get _starMessage {
    switch (widget.stars) {
      case 0:
        return 'Play to earn stars!';
      case 1:
        return 'Good start! Keep going!';
      case 2:
        return 'Impressive! Almost perfect!';
      default:
        return 'Legendary! All 3 stars!';
    }
  }
}

// ── Info Chip ──────────────────────────────

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _InfoChip({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(height: 3),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.35),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Neon Play Button
// ─────────────────────────────────────────────

class _PlayButton extends StatefulWidget {
  final VoidCallback onTap;
  final Color color;

  const _PlayButton({required this.onTap, required this.color});

  @override
  State<_PlayButton> createState() => _PlayButtonState();
}

class _PlayButtonState extends State<_PlayButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.94)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        HapticFeedback.mediumImpact();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  widget.color.withOpacity(0.85),
                  widget.color.withOpacity(0.55),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: widget.color.withOpacity(0.75),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withOpacity(0.45),
                  blurRadius: 18,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: widget.color.withOpacity(0.2),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.play_arrow_rounded,
                    color: Colors.white, size: 26),
                SizedBox(width: 8),
                Text(
                  'PLAY',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 5,
                    shadows: [
                      Shadow(color: Colors.white54, blurRadius: 8)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
