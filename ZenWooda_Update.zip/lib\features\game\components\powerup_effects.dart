import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Premium Powerup Effect Overlays
//  Displayed on top of the game grid when a
//  powerup is activated. Animations are short-
//  lived, GPU-friendly, and low-impact on FPS.
// ─────────────────────────────────────────────

enum PowerupEffectType { hammer, bomb, lightning, combo, levelComplete }

// ── Screen Shake Controller ──────────────────

/// Attach to a widget to trigger screen shake.
class ScreenShakeController extends ChangeNotifier {
  double shakeMagnitude = 0;

  void shake({double magnitude = 6.0}) {
    shakeMagnitude = magnitude;
    notifyListeners();
  }

  void reset() {
    shakeMagnitude = 0;
    notifyListeners();
  }
}

/// Wraps [child] and shakes it when controller triggers.
class ScreenShakeWidget extends StatefulWidget {
  final Widget child;
  final ScreenShakeController controller;

  const ScreenShakeWidget({
    super.key,
    required this.child,
    required this.controller,
  });

  @override
  State<ScreenShakeWidget> createState() => _ScreenShakeWidgetState();
}

class _ScreenShakeWidgetState extends State<ScreenShakeWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    widget.controller.addListener(_onShake);
  }

  void _onShake() {
    if (widget.controller.shakeMagnitude > 0) {
      _ctrl.forward(from: 0).then((_) {
        widget.controller.reset();
      });
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onShake);
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, child) {
        final mag = widget.controller.shakeMagnitude;
        final dx = mag * sin(_anim.value * pi * 3) * (1 - _anim.value);
        final dy = mag * 0.3 * sin(_anim.value * pi * 2) * (1 - _anim.value);
        return Transform.translate(
          offset: Offset(dx, dy),
          child: child,
        );
      },
      child: widget.child,
    );
  }
}

// ── Hammer Effect ────────────────────────────

class HammerEffect extends StatefulWidget {
  final Offset cellCenter;
  final VoidCallback onDone;

  const HammerEffect({
    super.key,
    required this.cellCenter,
    required this.onDone,
  });

  @override
  State<HammerEffect> createState() => _HammerEffectState();
}

class _HammerEffectState extends State<HammerEffect>
    with TickerProviderStateMixin {
  late AnimationController _strikeCtrl;
  late AnimationController _debrisCtrl;
  late Animation<double> _strikeScale;
  late Animation<double> _strikeOpacity;
  late Animation<double> _debrisOpacity;
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _strikeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _debrisCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _strikeScale = TweenSequence<double>([
      TweenSequenceItem(
          tween: Tween(begin: 2.5, end: 0.8)
              .chain(CurveTween(curve: Curves.easeIn)),
          weight: 40),
      TweenSequenceItem(
          tween: Tween(begin: 0.8, end: 1.4)
              .chain(CurveTween(curve: Curves.elasticOut)),
          weight: 60),
    ]).animate(_strikeCtrl);

    _strikeOpacity = TweenSequence<double>([
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 70),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_strikeCtrl);

    _debrisOpacity = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _debrisCtrl, curve: Curves.easeOut));

    _strikeCtrl.forward();
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) _debrisCtrl.forward();
    });
    _debrisCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed) widget.onDone();
    });
  }

  @override
  void dispose() {
    _strikeCtrl.dispose();
    _debrisCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Hammer emoji strike
        Positioned(
          left: widget.cellCenter.dx - 24,
          top: widget.cellCenter.dy - 40,
          child: AnimatedBuilder(
            animation: _strikeCtrl,
            builder: (_, __) => Opacity(
              opacity: _strikeOpacity.value.clamp(0.0, 1.0),
              child: Transform.scale(
                scale: _strikeScale.value,
                child: const Text('🔨', style: TextStyle(fontSize: 32)),
              ),
            ),
          ),
        ),
        // Impact flash
        Positioned(
          left: widget.cellCenter.dx - 20,
          top: widget.cellCenter.dy - 20,
          child: AnimatedBuilder(
            animation: _strikeCtrl,
            builder: (_, __) {
              final progress = _strikeCtrl.value;
              if (progress < 0.35 || progress > 0.65) return const SizedBox.shrink();
              final opacity = (1.0 - ((progress - 0.5) / 0.15).abs()).clamp(0.0, 1.0);
              return Opacity(
                opacity: opacity * 0.8,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFFFCC44),
                  ),
                ),
              );
            },
          ),
        ),
        // Debris particles
        AnimatedBuilder(
          animation: _debrisCtrl,
          builder: (_, __) => Opacity(
            opacity: _debrisOpacity.value.clamp(0.0, 1.0),
            child: Stack(
              children: List.generate(6, (i) {
                final angle = (i / 6) * pi * 2;
                final dist = 30.0 * _debrisCtrl.value;
                return Positioned(
                  left: widget.cellCenter.dx + cos(angle) * dist - 5,
                  top: widget.cellCenter.dy + sin(angle) * dist - 5,
                  child: Container(
                    width: 8 + _rng.nextDouble() * 5,
                    height: 8 + _rng.nextDouble() * 5,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFCC44)
                          .withOpacity(0.8 * (1 - _debrisCtrl.value)),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Bomb Blast Effect ────────────────────────

class BombBlastEffect extends StatefulWidget {
  final Offset center;
  final double cellSize;
  final VoidCallback onDone;

  const BombBlastEffect({
    super.key,
    required this.center,
    required this.cellSize,
    required this.onDone,
  });

  @override
  State<BombBlastEffect> createState() => _BombBlastEffectState();
}

class _BombBlastEffectState extends State<BombBlastEffect>
    with TickerProviderStateMixin {
  late AnimationController _blastCtrl;
  late AnimationController _ringCtrl;
  late Animation<double> _blastScale;
  late Animation<double> _blastOpacity;
  late Animation<double> _ringRadius;
  late Animation<double> _ringOpacity;
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _blastCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _ringCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _blastScale = TweenSequence<double>([
      TweenSequenceItem(
          tween: Tween(begin: 0.3, end: 1.8)
              .chain(CurveTween(curve: Curves.easeOut)),
          weight: 60),
      TweenSequenceItem(
          tween: Tween(begin: 1.8, end: 2.5)
              .chain(CurveTween(curve: Curves.easeIn)),
          weight: 40),
    ]).animate(_blastCtrl);

    _blastOpacity = TweenSequence<double>([
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 60),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 40),
    ]).animate(_blastCtrl);

    final radius = widget.cellSize * 2.0;
    _ringRadius = Tween<double>(begin: 0, end: radius)
        .animate(CurvedAnimation(parent: _ringCtrl, curve: Curves.easeOut));
    _ringOpacity = Tween<double>(begin: 0.9, end: 0.0)
        .animate(CurvedAnimation(parent: _ringCtrl, curve: Curves.easeIn));

    _blastCtrl.forward();
    _ringCtrl.forward();
    _blastCtrl.addStatusListener((s) {
      if (s == AnimationStatus.completed) widget.onDone();
    });
  }

  @override
  void dispose() {
    _blastCtrl.dispose();
    _ringCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Shockwave ring
        AnimatedBuilder(
          animation: _ringCtrl,
          builder: (_, __) => Positioned(
            left: widget.center.dx - _ringRadius.value,
            top: widget.center.dy - _ringRadius.value,
            child: Opacity(
              opacity: _ringOpacity.value.clamp(0.0, 1.0),
              child: Container(
                width: _ringRadius.value * 2,
                height: _ringRadius.value * 2,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFFF6600),
                    width: 3,
                  ),
                ),
              ),
            ),
          ),
        ),
        // Explosion flash
        AnimatedBuilder(
          animation: _blastCtrl,
          builder: (_, __) => Positioned(
            left: widget.center.dx - 36,
            top: widget.center.dy - 36,
            child: Opacity(
              opacity: _blastOpacity.value.clamp(0.0, 1.0),
              child: Transform.scale(
                scale: _blastScale.value,
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Color(0xFFFFFFCC),
                        Color(0xFFFF8800),
                        Color(0xFFFF2200),
                        Colors.transparent,
                      ],
                      stops: [0.0, 0.4, 0.7, 1.0],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        // Emoji
        AnimatedBuilder(
          animation: _blastCtrl,
          builder: (_, __) => Positioned(
            left: widget.center.dx - 18,
            top: widget.center.dy - 18,
            child: Opacity(
              opacity: (_blastOpacity.value * 1.5).clamp(0.0, 1.0),
              child: const Text('💥', style: TextStyle(fontSize: 36)),
            ),
          ),
        ),
        // Spark particles
        AnimatedBuilder(
          animation: _blastCtrl,
          builder: (_, __) => Stack(
            children: List.generate(10, (i) {
              final angle = (i / 10) * pi * 2 + _rng.nextDouble() * 0.4;
              final speed = 40.0 + _rng.nextDouble() * 30;
              final dist = speed * _blastCtrl.value;
              final gy = 20.0 * pow(_blastCtrl.value, 2);
              return Positioned(
                left: widget.center.dx + cos(angle) * dist - 4,
                top: widget.center.dy + sin(angle) * dist - 4 + gy,
                child: Opacity(
                  opacity: (1.0 - _blastCtrl.value).clamp(0.0, 1.0),
                  child: Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFFFFAA00),
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }
}

// ── Lightning Effect ─────────────────────────

class LightningEffect extends StatefulWidget {
  final Offset tapCenter;
  final double gridLeft;
  final double gridTop;
  final double gridSize;   // total px width/height of grid
  final int tapRow;
  final int tapCol;
  final int gridCells;
  final VoidCallback onDone;

  const LightningEffect({
    super.key,
    required this.tapCenter,
    required this.gridLeft,
    required this.gridTop,
    required this.gridSize,
    required this.tapRow,
    required this.tapCol,
    required this.gridCells,
    required this.onDone,
  });

  @override
  State<LightningEffect> createState() => _LightningEffectState();
}

class _LightningEffectState extends State<LightningEffect>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeOut;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeOut = Tween<double>(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1.0)));
    _ctrl.forward().then((_) => widget.onDone());
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cellPx = widget.gridSize / widget.gridCells;
    final rowY = widget.gridTop + widget.tapRow * cellPx + cellPx / 2;
    final colX = widget.gridLeft + widget.tapCol * cellPx + cellPx / 2;

    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Opacity(
        opacity: _fadeOut.value.clamp(0.0, 1.0),
        child: Stack(
          children: [
            // Horizontal beam (row)
            Positioned(
              left: widget.gridLeft,
              top: rowY - 3,
              child: Container(
                width: widget.gridSize,
                height: 6,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      const Color(0xFFFFFF44).withOpacity(0.9),
                      const Color(0xFF00CCFF),
                      const Color(0xFFFFFF44).withOpacity(0.9),
                      Colors.transparent,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(3),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00CCFF).withOpacity(0.8),
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
            // Vertical beam (column)
            Positioned(
              left: colX - 3,
              top: widget.gridTop,
              child: Container(
                width: 6,
                height: widget.gridSize,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      const Color(0xFFFFFF44).withOpacity(0.9),
                      const Color(0xFF00CCFF),
                      const Color(0xFFFFFF44).withOpacity(0.9),
                      Colors.transparent,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(3),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00CCFF).withOpacity(0.8),
                      blurRadius: 12,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
            // Center burst
            Positioned(
              left: colX - 20,
              top: rowY - 20,
              child: Transform.scale(
                scale: 0.5 + _ctrl.value * 0.8,
                child: const Text('⚡', style: TextStyle(fontSize: 28)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Combo Burst (floating score text) ───────

class ComboScoreEffect extends StatefulWidget {
  final Offset position;
  final String text;
  final Color color;
  final VoidCallback onDone;

  const ComboScoreEffect({
    super.key,
    required this.position,
    required this.text,
    required this.color,
    required this.onDone,
  });

  @override
  State<ComboScoreEffect> createState() => _ComboScoreEffectState();
}

class _ComboScoreEffectState extends State<ComboScoreEffect>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _opacity;
  late Animation<double> _scale;
  late Animation<Offset> _position;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _opacity = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 15),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 55),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 30),
    ]).animate(_ctrl);
    _scale = TweenSequence([
      TweenSequenceItem(
          tween: Tween(begin: 0.5, end: 1.4)
              .chain(CurveTween(curve: Curves.elasticOut)),
          weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.4, end: 1.0), weight: 60),
    ]).animate(_ctrl);
    _position = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(0, -1.2),
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));

    _ctrl.forward().then((_) => widget.onDone());
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.position.dx - 30,
      top: widget.position.dy - 20,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Opacity(
            opacity: _opacity.value.clamp(0.0, 1.0),
            child: SlideTransition(
              position: _position,
              child: Transform.scale(
                scale: _scale.value,
                child: Text(
                  widget.text,
                  style: TextStyle(
                    color: widget.color,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    shadows: [
                      Shadow(
                        color: widget.color.withOpacity(0.6),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
