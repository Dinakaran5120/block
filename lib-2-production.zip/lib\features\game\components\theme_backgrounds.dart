// ─────────────────────────────────────────────
//  Theme Backgrounds — Beach · Devil · Angel
// ─────────────────────────────────────────────

import 'dart:math';
import 'package:flutter/material.dart';

// ══════════════════════════════════════════════
//  BEACH THEME BACKGROUND
//  Waves · Sun rays · Seagulls · Ocean shimmer
// ══════════════════════════════════════════════

class BeachBackground extends StatefulWidget {
  final Widget child;
  const BeachBackground({super.key, required this.child});

  @override
  State<BeachBackground> createState() => _BeachBackgroundState();
}

class _BeachBackgroundState extends State<BeachBackground>
    with TickerProviderStateMixin {
  late AnimationController _waveCtrl;
  late AnimationController _sunCtrl;
  late AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _waveCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 4),
    )..repeat();
    _sunCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 6),
    )..repeat(reverse: true);
    _shimmerCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _waveCtrl.dispose();
    _sunCtrl.dispose();
    _shimmerCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_waveCtrl, _sunCtrl, _shimmerCtrl]),
      builder: (ctx, _) => Stack(children: [
        // Deep ocean gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF0A1628),  // midnight ocean
                Color(0xFF0D2A4A),  // deep sea
                Color(0xFF1A3A5C),  // dusk water
                Color(0xFF0A1E36),  // abyss
              ],
            ),
          ),
        ),

        // Sun glow at top
        Positioned(
          top: -60,
          right: 60,
          child: Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  const Color(0xFFFFD54F).withOpacity(
                      0.15 + _sunCtrl.value * 0.1),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),

        // Wave layers
        CustomPaint(
          painter: _WavePainter(_waveCtrl.value),
          size: Size.infinite,
        ),

        // Ocean shimmer particles
        CustomPaint(
          painter: _OceanShimmerPainter(_shimmerCtrl.value),
          size: Size.infinite,
        ),

        widget.child,
      ]),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double t;
  const _WavePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < 4; i++) {
      final opacity = 0.06 + i * 0.02;
      final yBase = size.height * (0.55 + i * 0.08);
      final amp = 12.0 - i * 2;
      final freq = 1.5 + i * 0.3;
      final paint = Paint()
        ..color = const Color(0xFF29B6F6).withOpacity(opacity)
        ..style = PaintingStyle.fill;

      final path = Path()..moveTo(0, size.height);
      for (double x = 0; x <= size.width; x += 2) {
        final y = yBase +
            sin((x / size.width * freq * pi * 2) + t * pi * 2 + i) * amp;
        path.lineTo(x, y);
      }
      path
        ..lineTo(size.width, size.height)
        ..close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_WavePainter o) => true;
}

class _OceanShimmerPainter extends CustomPainter {
  final double t;
  static final _rng = Random(42);
  static final _shimmers = List.generate(20, (_) => [
    _rng.nextDouble(),
    _rng.nextDouble() * 0.6 + 0.2,
    _rng.nextDouble(),
  ]);

  const _OceanShimmerPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in _shimmers) {
      final flicker = sin((t + s[2]) * pi * 3) * 0.5 + 0.5;
      final paint = Paint()
        ..color = const Color(0xFF4FC3F7).withOpacity(0.15 * flicker)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
      canvas.drawCircle(
        Offset(s[0] * size.width, s[1] * size.height),
        2 + flicker * 2,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_OceanShimmerPainter o) => true;
}

// ══════════════════════════════════════════════
//  DEVIL THEME BACKGROUND
//  Lava · Ember sparks · Hellfire glow · Smoke
// ══════════════════════════════════════════════

class DevilBackground extends StatefulWidget {
  final Widget child;
  const DevilBackground({super.key, required this.child});

  @override
  State<DevilBackground> createState() => _DevilBackgroundState();
}

class _DevilBackgroundState extends State<DevilBackground>
    with TickerProviderStateMixin {
  late AnimationController _lavaCtrl;
  late AnimationController _emberCtrl;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _lavaCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 6),
    )..repeat();
    _emberCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _lavaCtrl.dispose();
    _emberCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_lavaCtrl, _emberCtrl, _pulseCtrl]),
      builder: (ctx, _) => Stack(children: [
        // Hellfire gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF050000),
                Color(0xFF1A0000),
                Color(0xFF2A0500),
                Color(0xFF100000),
              ],
            ),
          ),
        ),

        // Lava glow from bottom
        Positioned(
          bottom: -100,
          left: 0,
          right: 0,
          child: Container(
            height: 300,
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.bottomCenter,
                radius: 1.5,
                colors: [
                  const Color(0xFFFF1744).withOpacity(
                      0.2 + _pulseCtrl.value * 0.1),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),

        // Lava cracks
        CustomPaint(
          painter: _LavaCrackPainter(_lavaCtrl.value),
          size: Size.infinite,
        ),

        // Ember particles
        CustomPaint(
          painter: _EmberPainter(_emberCtrl.value),
          size: Size.infinite,
        ),

        // Smoke
        CustomPaint(
          painter: _SmokePainter(_lavaCtrl.value),
          size: Size.infinite,
        ),

        widget.child,
      ]),
    );
  }
}

class _LavaCrackPainter extends CustomPainter {
  final double t;
  const _LavaCrackPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final glow = sin(t * pi * 2) * 0.5 + 0.5;
    final paint = Paint()
      ..color = const Color(0xFFFF6D00).withOpacity(0.12 + glow * 0.08)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    // Static crack lines seeded at compile time
    final cracks = [
      [0.1, 0.7, 0.3, 0.9, 0.5, 0.75],
      [0.6, 0.8, 0.8, 0.95, 0.9, 0.85],
      [0.2, 0.85, 0.4, 0.78, 0.6, 0.92],
      [0.0, 0.9, 0.25, 0.82, 0.5, 0.95],
      [0.55, 0.72, 0.7, 0.88, 0.85, 0.78],
    ];

    for (final c in cracks) {
      final path = Path()
        ..moveTo(c[0] * size.width, c[1] * size.height)
        ..quadraticBezierTo(
          c[2] * size.width, c[3] * size.height,
          c[4] * size.width, c[5] * size.height,
        );
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_LavaCrackPainter o) => true;
}

class _EmberPainter extends CustomPainter {
  final double t;
  static final _rng = Random(7);
  static final _embers = List.generate(25, (_) => [
    _rng.nextDouble(),
    _rng.nextDouble(),
    _rng.nextDouble() * 0.2 + 0.05,
    _rng.nextDouble(),
  ]);

  const _EmberPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final e in _embers) {
      final cycle = (t + e[3]) % 1.0;
      final py = (1.0 - cycle) * size.height;
      final px = e[0] * size.width + sin((cycle + e[3]) * pi * 4) * 15;
      final flicker = sin((t * 8 + e[3] * 10) * pi) * 0.4 + 0.6;

      final paint = Paint()
        ..color = const Color(0xFFFF6D00).withOpacity(0.7 * flicker)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
      canvas.drawCircle(Offset(px, py), 2, paint);
    }
  }

  @override
  bool shouldRepaint(_EmberPainter o) => true;
}

class _SmokePainter extends CustomPainter {
  final double t;
  const _SmokePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 3; i++) {
      final offset = (t * 0.1 + i * 0.33) % 1.0;
      final y = size.height * (0.3 - offset * 0.4);
      final x = size.width * (0.2 + i * 0.3 + sin(t * pi + i) * 0.05);
      final radius = 30.0 + offset * 40;
      final opacity = (1.0 - offset) * 0.05;

      paint.shader = RadialGradient(
        colors: [
          const Color(0xFF2D0000).withOpacity(opacity),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
          center: Offset(x, y), radius: radius));
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(_SmokePainter o) => true;
}

// ══════════════════════════════════════════════
//  ANGEL THEME BACKGROUND
//  Stars · Clouds · Divine light rays · Halos
// ══════════════════════════════════════════════

class AngelBackground extends StatefulWidget {
  final Widget child;
  const AngelBackground({super.key, required this.child});

  @override
  State<AngelBackground> createState() => _AngelBackgroundState();
}

class _AngelBackgroundState extends State<AngelBackground>
    with TickerProviderStateMixin {
  late AnimationController _starCtrl;
  late AnimationController _cloudCtrl;
  late AnimationController _rayCtrl;

  @override
  void initState() {
    super.initState();
    _starCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _cloudCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 10),
    )..repeat();
    _rayCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _starCtrl.dispose();
    _cloudCtrl.dispose();
    _rayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_starCtrl, _cloudCtrl, _rayCtrl]),
      builder: (ctx, _) => Stack(children: [
        // Celestial gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF05050F),
                Color(0xFF0D0D20),
                Color(0xFF12123A),
                Color(0xFF080818),
              ],
            ),
          ),
        ),

        // Divine light source
        Positioned(
          top: -80,
          left: 0,
          right: 0,
          child: Container(
            height: 300,
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.2,
                colors: [
                  const Color(0xFF9FA8DA).withOpacity(
                      0.15 + _rayCtrl.value * 0.1),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),

        // Light rays
        CustomPaint(
          painter: _LightRayPainter(_rayCtrl.value),
          size: Size.infinite,
        ),

        // Stars
        CustomPaint(
          painter: _StarPainter(_starCtrl.value),
          size: Size.infinite,
        ),

        // Clouds
        CustomPaint(
          painter: _CloudPainter(_cloudCtrl.value),
          size: Size.infinite,
        ),

        widget.child,
      ]),
    );
  }
}

class _LightRayPainter extends CustomPainter {
  final double t;
  const _LightRayPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = -50.0;
    final numRays = 8;
    for (int i = 0; i < numRays; i++) {
      final angle = (i / numRays) * pi * 2 + t * 0.5;
      final opacity = (sin(angle * 2 + t * pi) * 0.5 + 0.5) * 0.06;
      final paint = Paint()
        ..color = const Color(0xFF9FA8DA).withOpacity(opacity)
        ..style = PaintingStyle.fill;

      final endX = cx + cos(angle) * size.width;
      final endY = cy + sin(angle) * size.height * 1.5;

      final path = Path()
        ..moveTo(cx - 2, cy)
        ..lineTo(endX - 15, endY)
        ..lineTo(endX + 15, endY)
        ..lineTo(cx + 2, cy)
        ..close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_LightRayPainter o) => true;
}

class _StarPainter extends CustomPainter {
  final double t;
  static final _rng = Random(13);
  static final _stars = List.generate(40, (_) => [
    _rng.nextDouble(),
    _rng.nextDouble() * 0.7,
    _rng.nextDouble() * 2 + 0.5,
    _rng.nextDouble(),
  ]);

  const _StarPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in _stars) {
      final twinkle = sin((t + s[3]) * pi * 2) * 0.4 + 0.6;
      final paint = Paint()
        ..color = Colors.white.withOpacity(twinkle * 0.7);
      canvas.drawCircle(
        Offset(s[0] * size.width, s[1] * size.height),
        s[2] * 0.8,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_StarPainter o) => true;
}

class _CloudPainter extends CustomPainter {
  final double t;
  const _CloudPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF3F51B5).withOpacity(0.06)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);

    for (int i = 0; i < 3; i++) {
      final x = ((t * 0.08 + i * 0.4) % 1.4 - 0.2) * size.width;
      final y = size.height * (0.15 + i * 0.12);
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(x, y),
          width: 150,
          height: 40,
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_CloudPainter o) => true;
}
