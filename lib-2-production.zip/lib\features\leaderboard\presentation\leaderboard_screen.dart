import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/leaderboard_repository.dart';
import '../../auth/domain/auth_notifier.dart';
import '../../../core/models/user_model.dart';
import '../../../core/theme/game_theme.dart';
import '../../../core/services/location_service.dart';

// ─────────────────────────────────────────────
//  LeaderboardScreen
// ─────────────────────────────────────────────

class LeaderboardScreen extends ConsumerWidget {
  final GameThemeData theme;
  const LeaderboardScreen({super.key, required this.theme});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lb = ref.watch(leaderboardProvider);
    final authState = ref.watch(authNotifierProvider);
    final colors = theme.colors;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
        children: [
          // ── Header ────────────────────────
          _LbHeader(colors: colors, authState: authState),

          // ── Filter tabs ───────────────────
          _FilterTabs(
            current: lb.filter,
            colors: colors,
            hasCountry: authState.user?.country != null,
            onChanged: (f) =>
                ref.read(leaderboardProvider.notifier).switchFilter(f),
          ),

          // ── My rank banner ────────────────
          if (lb.myRank != null && authState.user != null)
            _MyRankBanner(
              rank: lb.myRank!,
              user: authState.user!,
              colors: colors,
            ),

          // ── List ──────────────────────────
          Expanded(
            child: lb.isLoading
                ? Center(
                    child: CircularProgressIndicator(color: colors.glowColor))
                : lb.error != null
                    ? _ErrorView(
                        error: lb.error!,
                        colors: colors,
                        onRetry: () => ref
                            .read(leaderboardProvider.notifier)
                            .loadGlobal(),
                      )
                    : lb.entries.isEmpty
                        ? _EmptyView(colors: colors)
                        : _LeaderboardList(
                            entries: lb.entries,
                            myUid: authState.user?.uid,
                            colors: colors,
                          ),
          ),
        ],
        ),
      ),
    );
  }
}

class _LbHeader extends StatelessWidget {
  final GameThemeColors colors;
  final AuthState authState;
  const _LbHeader({required this.colors, required this.authState});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Icon(Icons.arrow_back_ios, color: colors.textPrimary, size: 22),
          ),
          const SizedBox(width: 12),
          Text(
            'LEADERBOARD',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w800,
              letterSpacing: 3,
              shadows: [
                Shadow(color: colors.glowColor.withOpacity(0.5), blurRadius: 12),
              ],
            ),
          ),
          const Spacer(),
          if (authState.user?.country != null)
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    colors.panelBg,
                    colors.panelBg.withOpacity(0.85),
                  ],
                ),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1),
                boxShadow: [
                  BoxShadow(color: colors.glowColor.withOpacity(0.2), blurRadius: 8),
                ],
              ),
              child: Text(
                LocationService.countryFlag(authState.user!.country!),
                style: const TextStyle(fontSize: 26),
              ),
            ),
        ],
      ),
    );
  }
}

class _FilterTabs extends StatelessWidget {
  final LeaderboardFilter current;
  final GameThemeColors colors;
  final bool hasCountry;
  final ValueChanged<LeaderboardFilter> onChanged;

  const _FilterTabs({
    required this.current,
    required this.colors,
    required this.hasCountry,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              colors.panelBg,
              colors.panelBg.withOpacity(0.85),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(color: colors.glowColor.withOpacity(0.15), blurRadius: 12, spreadRadius: 1),
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 3), spreadRadius: -2),
            BoxShadow(color: Colors.white.withOpacity(0.08), blurRadius: 4, offset: const Offset(-1, -1), spreadRadius: -1),
          ],
        ),
        child: Row(
          children: [
            _Tab(
              label: '🌍  Global',
              isActive: current == LeaderboardFilter.global,
              colors: colors,
              onTap: () => onChanged(LeaderboardFilter.global),
            ),
            if (hasCountry)
              _Tab(
                label: '📍  My Country',
                isActive: current == LeaderboardFilter.country,
                colors: colors,
                onTap: () => onChanged(LeaderboardFilter.country),
              ),
          ],
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String label;
  final bool isActive;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _Tab({
    required this.label,
    required this.isActive,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: isActive
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [colors.buttonPrimary, colors.buttonSecondary],
                  )
                : null,
            color: isActive ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            boxShadow: isActive
                ? [
                    BoxShadow(color: colors.glowColor.withOpacity(0.3), blurRadius: 10, spreadRadius: 1),
                    BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6, offset: const Offset(0, 2), spreadRadius: -2),
                  ]
                : null,
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isActive
                  ? colors.textPrimary
                  : colors.textPrimary.withOpacity(0.4),
              fontSize: 13,
              fontWeight:
                  isActive ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}

class _MyRankBanner extends StatelessWidget {
  final int rank;
  final UserModel user;
  final GameThemeColors colors;

  const _MyRankBanner({
    required this.rank,
    required this.user,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colors.buttonPrimary.withOpacity(0.2),
            colors.buttonPrimary.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.panelBorder.withOpacity(0.6), width: 1.5),
        boxShadow: [
          BoxShadow(color: colors.glowColor.withOpacity(0.2), blurRadius: 15, spreadRadius: 2),
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4), spreadRadius: -3),
          BoxShadow(color: Colors.white.withOpacity(0.08), blurRadius: 5, offset: const Offset(-1, -1), spreadRadius: -1),
        ],
      ),
      child: Row(
        children: [
          Text(
            'Your rank',
            style: TextStyle(
              color: colors.textPrimary.withOpacity(0.6),
              fontSize: 13,
            ),
          ),
          const Spacer(),
          Text(
            '#$rank',
            style: TextStyle(
              color: colors.textAccent,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              shadows: [
                Shadow(color: colors.glowColor.withOpacity(0.8), blurRadius: 12),
                Shadow(color: colors.glowColor.withOpacity(0.4), blurRadius: 6, offset: Offset(0, 2)),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '${user.highScore} pts',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _LeaderboardList extends StatelessWidget {
  final List<LeaderboardEntry> entries;
  final String? myUid;
  final GameThemeColors colors;

  const _LeaderboardList({
    required this.entries,
    required this.myUid,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: entries.length,
      itemBuilder: (ctx, i) {
        final entry = entries[i];
        final isMe = entry.uid == myUid;
        return _LeaderboardRow(
          entry: entry,
          isMe: isMe,
          colors: colors,
        );
      },
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  final LeaderboardEntry entry;
  final bool isMe;
  final GameThemeColors colors;

  const _LeaderboardRow({
    required this.entry,
    required this.isMe,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    final rankColor = entry.rank == 1
        ? const Color(0xFFFFD700)
        : entry.rank == 2
            ? const Color(0xFFC0C0C0)
            : entry.rank == 3
                ? const Color(0xFFCD7F32)
                : colors.textPrimary.withOpacity(0.5);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: isMe
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.buttonPrimary.withOpacity(0.25),
                  colors.buttonPrimary.withOpacity(0.15),
                ],
              )
            : LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.panelBg.withOpacity(0.8),
                  colors.panelBg.withOpacity(0.6),
                ],
              ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isMe
              ? colors.panelBorder.withOpacity(0.8)
              : colors.panelBorder.withOpacity(0.3),
          width: isMe ? 1.5 : 1,
        ),
        boxShadow: isMe
            ? [
                BoxShadow(color: colors.glowColor.withOpacity(0.25), blurRadius: 15, spreadRadius: 2),
                BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4), spreadRadius: -3),
                BoxShadow(color: Colors.white.withOpacity(0.08), blurRadius: 5, offset: const Offset(-1, -1), spreadRadius: -1),
              ]
            : [
                BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 6, offset: const Offset(0, 2), spreadRadius: -2),
              ],
      ),
      child: Row(
        children: [
          // Rank
          SizedBox(
            width: 36,
            child: entry.rank <= 3
                ? Text(
                    entry.rank == 1
                        ? '🥇'
                        : entry.rank == 2
                            ? '🥈'
                            : '🥉',
                    style: const TextStyle(fontSize: 22),
                  )
                : Text(
                    '#${entry.rank}',
                    style: TextStyle(
                      color: rankColor,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),

          // Avatar circle
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.buttonPrimary.withOpacity(0.4),
                  colors.buttonPrimary.withOpacity(0.2),
                ],
              ),
              border: Border.all(color: colors.panelBorder.withOpacity(0.6), width: 1.5),
              boxShadow: isMe
                  ? [
                      BoxShadow(color: colors.glowColor.withOpacity(0.3), blurRadius: 10, spreadRadius: 1),
                    ]
                  : [
                      BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6, offset: const Offset(0, 2), spreadRadius: -2),
                    ],
            ),
            child: Center(
              child: Text(
                entry.username.isNotEmpty
                    ? entry.username[0].toUpperCase()
                    : '?',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),

          const SizedBox(width: 12),

          // Name + country
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        entry.username,
                        style: TextStyle(
                          color: isMe ? colors.textAccent : colors.textPrimary,
                          fontWeight:
                              isMe ? FontWeight.bold : FontWeight.w500,
                          fontSize: 14,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isMe)
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                colors.glowColor.withOpacity(0.3),
                                colors.glowColor.withOpacity(0.15),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: colors.glowColor.withOpacity(0.5), width: 1),
                            boxShadow: [
                              BoxShadow(color: colors.glowColor.withOpacity(0.2), blurRadius: 6, spreadRadius: 1),
                            ],
                          ),
                          child: Text(
                            'YOU',
                            style: TextStyle(
                              color: colors.textAccent,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                if (entry.countryName != null)
                  Text(
                    '${entry.country != null ? LocationService.countryFlag(entry.country!) : ''} ${entry.countryName}',
                    style: TextStyle(
                      color: colors.textPrimary.withOpacity(0.4),
                      fontSize: 11,
                    ),
                  ),
              ],
            ),
          ),

          // Score
          Text(
            _formatScore(entry.score),
            style: TextStyle(
              color: entry.rank <= 3 ? rankColor : colors.textPrimary,
              fontSize: 17,
              fontWeight: FontWeight.w800,
              shadows: entry.rank <= 3
                  ? [
                      Shadow(color: rankColor.withOpacity(0.5), blurRadius: 8),
                    ]
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  String _formatScore(int score) {
    if (score >= 1000000) return '${(score / 1000000).toStringAsFixed(1)}M';
    if (score >= 1000) return '${(score / 1000).toStringAsFixed(1)}K';
    return score.toString();
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  final GameThemeColors colors;
  final VoidCallback onRetry;

  const _ErrorView({
    required this.error,
    required this.colors,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, color: colors.textPrimary.withOpacity(0.4),
              size: 48),
          const SizedBox(height: 12),
          Text(
            'Failed to load',
            style: TextStyle(
                color: colors.textPrimary, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: onRetry,
            child: Text('Retry', style: TextStyle(color: colors.textAccent)),
          ),
        ],
      ),
    );
  }
}

class _EmptyView extends StatelessWidget {
  final GameThemeColors colors;
  const _EmptyView({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🏆', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 12),
          Text(
            'Be the first on the board!',
            style: TextStyle(
                color: colors.textPrimary.withOpacity(0.5), fontSize: 15),
          ),
        ],
      ),
    );
  }
}
