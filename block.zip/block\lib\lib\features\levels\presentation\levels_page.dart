import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../auth/data/user_repository.dart';
import '../../game/game_screen.dart';

// ─────────────────────────────────────────────
//  Levels Page — neon dark UI
//  Unlocking: highScore-based  |  Stars: coin-based
// ─────────────────────────────────────────────

class _LevelDef {
  final int number;
  final int unlockAtScore;
  final int coinsFor1Star;
  final int coinsFor2Stars;
  final int coinsFor3Stars;

  const _LevelDef({
    required this.number,
    required this.unlockAtScore,
    required this.coinsFor1Star,
    required this.coinsFor2Stars,
    required this.coinsFor3Stars,
  });
}

// Generates level N on demand — infinite levels, no hardcoded cap.
// Unlock threshold: every 300 pts unlocks the next level.
// Star thresholds scale linearly with level number.
_LevelDef _levelFor(int n) => _LevelDef(
  number:        n,
  unlockAtScore: (n - 1) * 300,
  coinsFor1Star: (n - 1) * 20,
  coinsFor2Stars:(n - 1) * 55,
  coinsFor3Stars:(n - 1) * 120,
);

// How many tiles to show: all unlocked + 3 locked preview,
// with a minimum of 15 so fresh installs aren't empty.
int _visibleCount(int highScore) {
  final unlocked = (highScore ~/ 300) + 1;
  return (unlocked + 3).clamp(15, 999);
}

int _computeStars(_LevelDef level, int coins) {
  if (coins >= level.coinsFor3Stars) return 3;
  if (coins >= level.coinsFor2Stars) return 2;
  if (coins >= level.coinsFor1Star)  return 1;
  return 0;
}

Color _neonColorForLevel(int number) {
  final hue = (number * 24.0) % 360.0;
  return HSLColor.fromAHSL(1.0, hue, 0.95, 0.65).toColor();
}

// ─────────────────────────────────────────────
//  LevelsPage
// ─────────────────────────────────────────────

class LevelsPage extends ConsumerWidget {
  const LevelsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(userProfileProvider);
    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: Stack(
        children: [
          const _NeonBg(),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Header(userAsync: userAsync),
                const SizedBox(height: 4),
                Expanded(
                  child: userAsync.when(
                    data: (user) => _LevelGrid(
                      highScore: user?.highScore ?? 0,
                      coins:     user?.coins     ?? 0,
                    ),
                    loading: () => const Center(
                      child: CircularProgressIndicator(color: Color(0xFF00F5FF)),
                    ),
                    error: (_, __) => _LevelGrid(highScore: 0, coins: 0),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Background
// ─────────────────────────────────────────────

class _NeonBg extends StatelessWidget {
  const _NeonBg();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.5),
          radius: 1.3,
          colors: [
            Color(0xFF0A1628),
            Color(0xFF040D1A),
            Color(0xFF020810),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Header
// ─────────────────────────────────────────────

class _Header extends StatelessWidget {
  final AsyncValue<UserModel?> userAsync;
  const _Header({required this.userAsync});

  @override
  Widget build(BuildContext context) {
    final coins     = userAsync.valueOrNull?.coins     ?? 0;
    final highScore = userAsync.valueOrNull?.highScore ?? 0;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Color(0xFF00F5FF), Color(0xFFBF40FF)],
                ).createShader(bounds),
                child: const Text(
                  'LEVELS',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 6,
                  ),
                ),
              ),
              _CoinBadge(coins: coins),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Best  $highScore pts',
            style: const TextStyle(
              color: Color(0x8000F5FF),
              fontSize: 12,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _CoinBadge extends StatelessWidget {
  final int coins;
  const _CoinBadge({required this.coins});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF0DFFE4).withOpacity(0.12),
            const Color(0xFFBF40FF).withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFF0DFFE4).withOpacity(0.35),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0DFFE4).withOpacity(0.1),
            blurRadius: 12,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD700), size: 16),
          const SizedBox(width: 6),
          Text(
            '$coins',
            style: const TextStyle(
              color: Color(0xFFFFD700),
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Grid
// ─────────────────────────────────────────────

class _LevelGrid extends StatelessWidget {
  final int highScore;
  final int coins;
  const _LevelGrid({required this.highScore, required this.coins});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.82,
      ),
      itemCount: _visibleCount(highScore),
      itemBuilder: (context, i) {
        final level      = _levelFor(i + 1);
        final isUnlocked = highScore >= level.unlockAtScore;
        final stars      = isUnlocked ? _computeStars(level, coins) : 0;
        return _LevelTile(level: level, isUnlocked: isUnlocked, stars: stars);
      },
    );
  }
}

// ─────────────────────────────────────────────
//  Level Tile
// ─────────────────────────────────────────────

class _LevelTile extends StatefulWidget {
  final _LevelDef level;
  final bool isUnlocked;
  final int  stars;

  const _LevelTile({
    required this.level,
    required this.isUnlocked,
    required this.stars,
  });

  @override
  State<_LevelTile> createState() => _LevelTileState();
}

class _LevelTileState extends State<_LevelTile>
    with TickerProviderStateMixin {
  late AnimationController _tapCtrl;
  late Animation<double>   _tapScale;
  late AnimationController _glitterCtrl;
  late Animation<double>   _glitterAnim;

  @override
  void initState() {
    super.initState();
    _tapCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 110),
    );
    _tapScale = Tween(begin: 1.0, end: 0.91).animate(
      CurvedAnimation(parent: _tapCtrl, curve: Curves.easeIn),
    );

    _glitterCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    );
    _glitterAnim = CurvedAnimation(parent: _glitterCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _tapCtrl.dispose();
    _glitterCtrl.dispose();
    super.dispose();
  }

  void _onTap(BuildContext context) {
    if (!widget.isUnlocked) return;
    _glitterCtrl.forward(from: 0);
    final nav = Navigator.of(context);
    showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => _LevelDialog(
        level:  widget.level,
        stars:  widget.stars,
        onPlay: () {
          nav.pop();
          nav.push(MaterialPageRoute<void>(
            builder: (_) => const GameScreen(),
          ));
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final neon       = _neonColorForLevel(widget.level.number);
    final isUnlocked = widget.isUnlocked;
    final stars      = widget.stars;

    return GestureDetector(
      onTapDown:   isUnlocked ? (_) => _tapCtrl.forward()                                 : null,
      onTapUp:     isUnlocked ? (_) { _tapCtrl.reverse(); _onTap(context); }              : null,
      onTapCancel: isUnlocked ? ()  => _tapCtrl.reverse()                                 : null,
      child: AnimatedBuilder(
        animation: _tapScale,
        builder: (_, child) =>
            Transform.scale(scale: _tapScale.value, child: child),
        child: Container(
          decoration: BoxDecoration(
            gradient: isUnlocked
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF0A1628).withOpacity(0.9),
                      const Color(0xFF0D1F3C).withOpacity(0.85),
                    ],
                  )
                : LinearGradient(
                    colors: [
                      const Color(0xFF070C14).withOpacity(0.7),
                      const Color(0xFF050A10).withOpacity(0.6),
                    ],
                  ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isUnlocked
                  ? neon.withOpacity(0.55)
                  : Colors.white.withOpacity(0.07),
              width: 1.5,
            ),
            boxShadow: isUnlocked
                ? [BoxShadow(color: neon.withOpacity(0.18), blurRadius: 12)]
                : [],
          ),
          child: Stack(
            children: [
              // Glassmorphic top sheen
              if (isUnlocked)
                Positioned(
                  top: 0, left: 0, right: 0,
                  child: Container(
                    height: 1.5,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.white.withOpacity(0.25),
                          Colors.transparent,
                        ],
                      ),
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(14),
                      ),
                    ),
                  ),
                ),
              // Level number + stars
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    isUnlocked
                        ? ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: [Colors.white, neon],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ).createShader(bounds),
                            child: Text(
                              '${widget.level.number}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          )
                        : Text(
                            '${widget.level.number}',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.18),
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                    const SizedBox(height: 5),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (i) {
                        final filled = i < stars;
                        return Icon(
                          filled ? Icons.star_rounded : Icons.star_outline_rounded,
                          color: filled
                              ? const Color(0xFFFFD700)
                              : Colors.white.withOpacity(0.12),
                          size: 13,
                          shadows: filled
                              ? [Shadow(
                                  color: const Color(0xFFFFD700).withOpacity(0.7),
                                  blurRadius: 6,
                                )]
                              : null,
                        );
                      }),
                    ),
                  ],
                ),
              ),
              // Lock overlay
              if (!isUnlocked)
                Positioned.fill(
                  child: Center(
                    child: Icon(
                      Icons.lock_rounded,
                      color: Colors.white.withOpacity(0.15),
                      size: 20,
                    ),
                  ),
                ),
              // Glitter flash on selection
              if (isUnlocked)
                AnimatedBuilder(
                  animation: _glitterAnim,
                  builder: (_, __) => Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: neon.withOpacity(
                            (1.0 - _glitterAnim.value) * 0.35,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Level Dialog popup
// ─────────────────────────────────────────────

class _LevelDialog extends StatelessWidget {
  final _LevelDef      level;
  final int            stars;
  final VoidCallback   onPlay;

  const _LevelDialog({
    required this.level,
    required this.stars,
    required this.onPlay,
  });

  @override
  Widget build(BuildContext context) {
    final neon = _neonColorForLevel(level.number);

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 32),
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF80D1628), Color(0xF8090E1C)],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: neon.withOpacity(0.6), width: 1.5),
          boxShadow: [
            BoxShadow(color: neon.withOpacity(0.25), blurRadius: 35, spreadRadius: 2),
            BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Glow bar accent
            Container(
              height: 3,
              width: 48,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, neon, Colors.transparent],
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Text(
              'LEVEL',
              style: TextStyle(
                color: neon.withOpacity(0.7),
                fontSize: 11,
                letterSpacing: 5,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [neon, Colors.white],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ).createShader(bounds),
              child: Text(
                '${level.number}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 64,
                  fontWeight: FontWeight.w900,
                  height: 1.0,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Stars display
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (i) {
                final filled = i < stars;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Icon(
                    filled ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: filled
                        ? const Color(0xFFFFD700)
                        : Colors.white.withOpacity(0.2),
                    size: 30,
                    shadows: filled
                        ? [Shadow(
                            color: const Color(0xFFFFD700).withOpacity(0.7),
                            blurRadius: 12,
                          )]
                        : null,
                  ),
                );
              }),
            ),
            const SizedBox(height: 8),
            Text(
              stars == 0 ? 'Earn coins to unlock stars!'
                  : stars == 1 ? 'Good start! Keep going!'
                  : stars == 2 ? 'Impressive! Almost perfect!'
                  :              'Legendary! All 3 stars!',
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontSize: 12,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 28),
            _PlayButton(onTap: onPlay, color: neon),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => Navigator.of(context).pop(),
              child: Text(
                'CANCEL',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.25),
                  fontSize: 11,
                  letterSpacing: 2.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Neon Play Button
// ─────────────────────────────────────────────

class _PlayButton extends StatefulWidget {
  final VoidCallback onTap;
  final Color        color;

  const _PlayButton({required this.onTap, required this.color});

  @override
  State<_PlayButton> createState() => _PlayButtonState();
}

class _PlayButtonState extends State<_PlayButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeIn),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown:   (_) => _ctrl.forward(),
      onTapUp:     (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: ()  => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  widget.color.withOpacity(0.85),
                  widget.color.withOpacity(0.55),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: widget.color.withOpacity(0.75),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.color.withOpacity(0.45),
                  blurRadius: 18,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: widget.color.withOpacity(0.2),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
                SizedBox(width: 8),
                Text(
                  'PLAY',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 5,
                    shadows: [Shadow(color: Colors.white54, blurRadius: 8)],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
