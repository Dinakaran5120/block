import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Theme system — Forest · Beach · Devil · Angel
// ─────────────────────────────────────────────

enum GameThemeType { forest, beach, devil, angel }

class GameThemeColors {
  final Color background1;
  final Color background2;
  final Color background3;
  final Color gridBg;
  final Color gridLine;
  final Color cellEmpty;
  final Color panelBg;
  final Color panelBorder;
  final Color textPrimary;
  final Color textAccent;
  final Color particleColor1;
  final Color particleColor2;
  final Color particleColor3;
  final Color glowColor;
  final List<Color> blockColors;
  final Color buttonPrimary;
  final Color buttonSecondary;

  const GameThemeColors({
    required this.background1,
    required this.background2,
    required this.background3,
    required this.gridBg,
    required this.gridLine,
    required this.cellEmpty,
    required this.panelBg,
    required this.panelBorder,
    required this.textPrimary,
    required this.textAccent,
    required this.particleColor1,
    required this.particleColor2,
    required this.particleColor3,
    required this.glowColor,
    required this.blockColors,
    required this.buttonPrimary,
    required this.buttonSecondary,
  });
}

class GameThemeData {
  final GameThemeType type;
  final String name;
  final GameThemeColors colors;
  final String ambientSound;
  final String blastSound;

  const GameThemeData({
    required this.type,
    required this.name,
    required this.colors,
    required this.ambientSound,
    required this.blastSound,
  });
}

// ─── Forest Theme (unlocked by default) ───────
const forestTheme = GameThemeData(
  type: GameThemeType.forest,
  name: 'Enchanted Forest',
  ambientSound: 'forest_ambient.mp3',
  blastSound: 'forest_blast.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF0D1F0D),
    background2: Color(0xFF162A14),
    background3: Color(0xFF1E3A1A),
    gridBg: Color(0xFF0A1A09),
    gridLine: Color(0xFF2A4A25),
    cellEmpty: Color(0xFF111E10),
    panelBg: Color(0xCC0D1F0D),
    panelBorder: Color(0xFF3A6B30),
    textPrimary: Color(0xFFE8F5E0),
    textAccent: Color(0xFF7FD96B),
    particleColor1: Color(0xFF7FD96B),
    particleColor2: Color(0xFFFFE066),
    particleColor3: Color(0xFF4FC3F7),
    glowColor: Color(0xFF4CAF50),
    blockColors: [
      Color(0xFF2E7D32), // deep green
      Color(0xFF558B2F), // olive
      Color(0xFF827717), // golden moss
      Color(0xFF00695C), // teal moss
      Color(0xFF1565C0), // twilight blue
      Color(0xFF6A1B9A), // forest violet
      Color(0xFFAD1457), // berry
    ],
    buttonPrimary: Color(0xFF2E7D32),
    buttonSecondary: Color(0xFF1B5E20),
  ),
);

// ─── Beach Theme ──────────────────────────────
const beachTheme = GameThemeData(
  type: GameThemeType.beach,
  name: 'Sunset Beach',
  ambientSound: 'beach_waves.mp3',
  blastSound: 'beach_splash.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF040F1E),
    background2: Color(0xFF0A2240),
    background3: Color(0xFF071830),
    gridBg: Color(0xFF030C18),
    gridLine: Color(0xFF0E4060),
    cellEmpty: Color(0xFF061526),
    panelBg: Color(0xCC040F1E),
    panelBorder: Color(0xFF00B4D8),
    textPrimary: Color(0xFFFFF9E6),
    textAccent: Color(0xFFFFE566),
    particleColor1: Color(0xFFFFE566),
    particleColor2: Color(0xFF00E5FF),
    particleColor3: Color(0xFFFF6B35),
    glowColor: Color(0xFF00D4FF),
    blockColors: [
      Color(0xFF0096FF), // electric blue
      Color(0xFF00E5FF), // neon cyan
      Color(0xFFFF6B35), // vivid sunset orange
      Color(0xFFFF4D6D), // neon coral-pink
      Color(0xFF00E5C3), // neon mint
      Color(0xFF2979FF), // deep electric blue
      Color(0xFFFF006E), // neon magenta
    ],
    buttonPrimary: Color(0xFF0096FF),
    buttonSecondary: Color(0xFF0057B8),
  ),
);

// ─── Devil Theme ──────────────────────────────
const devilTheme = GameThemeData(
  type: GameThemeType.devil,
  name: 'Inferno Realm',
  ambientSound: 'devil_ambient.mp3',
  blastSound: 'devil_blast.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF120000),
    background2: Color(0xFF200000),
    background3: Color(0xFF150500),
    gridBg: Color(0xFF0A0000),
    gridLine: Color(0xFF6D0000),
    cellEmpty: Color(0xFF100000),
    panelBg: Color(0xCC120000),
    panelBorder: Color(0xFFFF1744),
    textPrimary: Color(0xFFFFE0D0),
    textAccent: Color(0xFFFF6E40),
    particleColor1: Color(0xFFFF1744),
    particleColor2: Color(0xFFFFAB00),
    particleColor3: Color(0xFFFF6D00),
    glowColor: Color(0xFFFF0022),
    blockColors: [
      Color(0xFFFF1744), // neon red
      Color(0xFFE91E63), // neon hot-pink
      Color(0xFFFF6D00), // neon orange
      Color(0xFF6D4C41), // volcanic ash
      Color(0xFFAA00FF), // electric purple
      Color(0xFF6200EA), // deep electric violet
      Color(0xFFFF3D00), // vivid lava
    ],
    buttonPrimary: Color(0xFFD50000),
    buttonSecondary: Color(0xFF7F0000),
  ),
);

// ─── Angel Theme ──────────────────────────────
const angelTheme = GameThemeData(
  type: GameThemeType.angel,
  name: 'Celestial Heaven',
  ambientSound: 'angel_ambient.mp3',
  blastSound: 'angel_chime.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF0D0A1E),
    background2: Color(0xFF120E2E),
    background3: Color(0xFF0A1040),
    gridBg: Color(0xFF080616),
    gridLine: Color(0xFF3A2A6A),
    cellEmpty: Color(0xFF0C0A20),
    panelBg: Color(0xCC0D0A1E),
    panelBorder: Color(0xFF9C27B0),
    textPrimary: Color(0xFFF0F4FF),
    textAccent: Color(0xFFEEF2FF),
    particleColor1: Color(0xFFFFFFFF),
    particleColor2: Color(0xFF9C27B0),
    particleColor3: Color(0xFFFFD740),
    glowColor: Color(0xFF7C4DFF),
    blockColors: [
      Color(0xFF2979FF), // electric blue
      Color(0xFF651FFF), // electric indigo
      Color(0xFFAA00FF), // neon purple
      Color(0xFFD500F9), // neon magenta
      Color(0xFF00BFA5), // vivid heaven teal
      Color(0xFF00E676), // neon seraphim green
      Color(0xFFFFD740), // bright halo gold
    ],
    buttonPrimary: Color(0xFF651FFF),
    buttonSecondary: Color(0xFF320096),
  ),
);

class ThemeRegistry {
  static const Map<GameThemeType, GameThemeData> themes = {
    GameThemeType.beach: beachTheme,
    GameThemeType.devil: devilTheme,
    GameThemeType.angel: angelTheme,
  };

  static GameThemeData get(GameThemeType type) => themes[type]!;
}
