import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

// ─────────────────────────────────────────────
//  LocationService
//  Gets GPS coords + reverse-geocodes to country
//  Stores result in Firestore via UserRepository
// ─────────────────────────────────────────────

class LocationResult {
  final double latitude;
  final double longitude;
  final String country;       // ISO 3166 e.g. "IN"
  final String countryName;   // e.g. "India"

  const LocationResult({
    required this.latitude,
    required this.longitude,
    required this.country,
    required this.countryName,
  });
}

class LocationService {
  // ── Request permission + get location ────
  Future<LocationResult?> getLocation() async {
    try {
      // Check if location services are enabled
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;

      // Check / request permission
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }
      if (permission == LocationPermission.deniedForever) return null;

      // Get position (low accuracy = battery friendly)
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 10),
      );

      // Reverse geocode
      final placemarks = await placemarkFromCoordinates(
        pos.latitude,
        pos.longitude,
      );

      if (placemarks.isEmpty) {
        return LocationResult(
          latitude: pos.latitude,
          longitude: pos.longitude,
          country: 'Unknown',
          countryName: 'Unknown',
        );
      }

      final place = placemarks.first;
      return LocationResult(
        latitude: pos.latitude,
        longitude: pos.longitude,
        country: place.isoCountryCode ?? 'Unknown',
        countryName: place.country ?? 'Unknown',
      );
    } catch (_) {
      return null;
    }
  }

  // ── Country flag emoji from ISO code ─────
  static String countryFlag(String isoCode) {
    if (isoCode.length != 2) return '🌍';
    const offset = 127397;
    final chars = isoCode.toUpperCase().codeUnits;
    return String.fromCharCodes(
        chars.map((c) => c + offset));
  }
}

final locationServiceProvider = Provider<LocationService>((ref) {
  return LocationService();
});
