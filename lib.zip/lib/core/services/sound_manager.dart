import 'package:flame_audio/flame_audio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../constants/game_constants.dart';

// ─────────────────────────────────────────────
//  SoundManager — wraps flame_audio
// ─────────────────────────────────────────────

class SoundManager {
  bool _sfxEnabled = true;
  bool _musicEnabled = true;
  String? _currentMusic;

  Future<void> preload() async {
    await FlameAudio.audioCache.loadAll([
      'place_block.mp3',
      'line_clear.mp3',
      'combo.mp3',
      'game_over.mp3',
      'tap.mp3',
      'forest_ambient.mp3',
    ]);
  }

  Future<void> playMusic(String file) async {
    if (!_musicEnabled) return;
    if (_currentMusic == file) return;
    await FlameAudio.bgm.stop();
    await FlameAudio.bgm.play(file, volume: GameConstants.musicVolume);
    _currentMusic = file;
  }

  Future<void> stopMusic() async {
    await FlameAudio.bgm.stop();
    _currentMusic = null;
  }

  void playSfx(String file) {
    if (!_sfxEnabled) return;
    FlameAudio.play(file, volume: GameConstants.sfxVolume);
  }

  void placeBlock() => playSfx('place_block.mp3');
  void lineClear() => playSfx('line_clear.mp3');
  void combo()     => playSfx('combo.mp3');
  void gameOver()  => playSfx('game_over.mp3');
  void tap()       => playSfx('tap.mp3');

  void toggleSfx()   => _sfxEnabled = !_sfxEnabled;
  void toggleMusic()  {
    _musicEnabled = !_musicEnabled;
    if (!_musicEnabled) {
      FlameAudio.bgm.pause();
    } else {
      FlameAudio.bgm.resume();
    }
  }

  bool get sfxEnabled   => _sfxEnabled;
  bool get musicEnabled => _musicEnabled;
}

final soundManagerProvider = Provider<SoundManager>((ref) => SoundManager());
