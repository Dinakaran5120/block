import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Theme system — Forest · Beach · Devil · Angel
// ─────────────────────────────────────────────

enum GameThemeType { forest, beach, devil, angel }

class GameThemeColors {
  final Color background1;
  final Color background2;
  final Color background3;
  final Color gridBg;
  final Color gridLine;
  final Color cellEmpty;
  final Color panelBg;
  final Color panelBorder;
  final Color textPrimary;
  final Color textAccent;
  final Color particleColor1;
  final Color particleColor2;
  final Color particleColor3;
  final Color glowColor;
  final List<Color> blockColors;
  final Color buttonPrimary;
  final Color buttonSecondary;

  const GameThemeColors({
    required this.background1,
    required this.background2,
    required this.background3,
    required this.gridBg,
    required this.gridLine,
    required this.cellEmpty,
    required this.panelBg,
    required this.panelBorder,
    required this.textPrimary,
    required this.textAccent,
    required this.particleColor1,
    required this.particleColor2,
    required this.particleColor3,
    required this.glowColor,
    required this.blockColors,
    required this.buttonPrimary,
    required this.buttonSecondary,
  });
}

class GameThemeData {
  final GameThemeType type;
  final String name;
  final GameThemeColors colors;
  final String ambientSound;
  final String blastSound;

  const GameThemeData({
    required this.type,
    required this.name,
    required this.colors,
    required this.ambientSound,
    required this.blastSound,
  });
}

// ─── Forest Theme (unlocked by default) ───────
const forestTheme = GameThemeData(
  type: GameThemeType.forest,
  name: 'Enchanted Forest',
  ambientSound: 'forest_ambient.mp3',
  blastSound: 'forest_blast.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF0D1F0D),
    background2: Color(0xFF162A14),
    background3: Color(0xFF1E3A1A),
    gridBg: Color(0xFF0A1A09),
    gridLine: Color(0xFF2A4A25),
    cellEmpty: Color(0xFF111E10),
    panelBg: Color(0xCC0D1F0D),
    panelBorder: Color(0xFF3A6B30),
    textPrimary: Color(0xFFE8F5E0),
    textAccent: Color(0xFF7FD96B),
    particleColor1: Color(0xFF7FD96B),
    particleColor2: Color(0xFFFFE066),
    particleColor3: Color(0xFF4FC3F7),
    glowColor: Color(0xFF4CAF50),
    blockColors: [
      Color(0xFF2E7D32), // deep green
      Color(0xFF558B2F), // olive
      Color(0xFF827717), // golden moss
      Color(0xFF00695C), // teal moss
      Color(0xFF1565C0), // twilight blue
      Color(0xFF6A1B9A), // forest violet
      Color(0xFFAD1457), // berry
    ],
    buttonPrimary: Color(0xFF2E7D32),
    buttonSecondary: Color(0xFF1B5E20),
  ),
);

// ─── Beach Theme ──────────────────────────────
const beachTheme = GameThemeData(
  type: GameThemeType.beach,
  name: 'Sunset Beach',
  ambientSound: 'beach_waves.mp3',
  blastSound: 'beach_splash.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF0A2A4A),
    background2: Color(0xFF1A4A6A),
    background3: Color(0xFF0D3A5A),
    gridBg: Color(0xFF081E36),
    gridLine: Color(0xFF1E5A7A),
    cellEmpty: Color(0xFF0A2236),
    panelBg: Color(0xCC0A2A4A),
    panelBorder: Color(0xFF1E8DB0),
    textPrimary: Color(0xFFFFF9E6),
    textAccent: Color(0xFFFFD54F),
    particleColor1: Color(0xFFFFD54F),
    particleColor2: Color(0xFF4FC3F7),
    particleColor3: Color(0xFFFF8A65),
    glowColor: Color(0xFF29B6F6),
    blockColors: [
      Color(0xFF0288D1), // ocean blue
      Color(0xFF0097A7), // teal wave
      Color(0xFFF57F17), // sunset orange
      Color(0xFFFF6F00), // coral
      Color(0xFF00897B), // sea green
      Color(0xFF1565C0), // deep ocean
      Color(0xFFAD1457), // sea anemone
    ],
    buttonPrimary: Color(0xFF0288D1),
    buttonSecondary: Color(0xFF01579B),
  ),
);

// ─── Devil Theme ──────────────────────────────
const devilTheme = GameThemeData(
  type: GameThemeType.devil,
  name: 'Inferno Realm',
  ambientSound: 'devil_ambient.mp3',
  blastSound: 'devil_blast.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF1A0000),
    background2: Color(0xFF2D0000),
    background3: Color(0xFF1A0A00),
    gridBg: Color(0xFF120000),
    gridLine: Color(0xFF5A1A00),
    cellEmpty: Color(0xFF180000),
    panelBg: Color(0xCC1A0000),
    panelBorder: Color(0xFFB71C1C),
    textPrimary: Color(0xFFFFE0D0),
    textAccent: Color(0xFFFF5722),
    particleColor1: Color(0xFFFF5722),
    particleColor2: Color(0xFFFFCA28),
    particleColor3: Color(0xFFB71C1C),
    glowColor: Color(0xFFFF1744),
    blockColors: [
      Color(0xFFB71C1C), // blood red
      Color(0xFF880E4F), // dark crimson
      Color(0xFFBF360C), // ember
      Color(0xFF4E342E), // ash brown
      Color(0xFF6A1B9A), // dark fire
      Color(0xFF311B92), // abyss
      Color(0xFFE65100), // lava
    ],
    buttonPrimary: Color(0xFFB71C1C),
    buttonSecondary: Color(0xFF7F0000),
  ),
);

// ─── Angel Theme ──────────────────────────────
const angelTheme = GameThemeData(
  type: GameThemeType.angel,
  name: 'Celestial Heaven',
  ambientSound: 'angel_ambient.mp3',
  blastSound: 'angel_chime.mp3',
  colors: GameThemeColors(
    background1: Color(0xFF1A1A2E),
    background2: Color(0xFF16213E),
    background3: Color(0xFF0F3460),
    gridBg: Color(0xFF0D1628),
    gridLine: Color(0xFF4A5A8A),
    cellEmpty: Color(0xFF111830),
    panelBg: Color(0xCC1A1A2E),
    panelBorder: Color(0xFF7986CB),
    textPrimary: Color(0xFFF8F9FF),
    textAccent: Color(0xFFE0E8FF),
    particleColor1: Color(0xFFFFFFFF),
    particleColor2: Color(0xFF7986CB),
    particleColor3: Color(0xFFFFD700),
    glowColor: Color(0xFF9FA8DA),
    blockColors: [
      Color(0xFF3F51B5), // celestial blue
      Color(0xFF5C6BC0), // twilight
      Color(0xFF7986CB), // lavender cloud
      Color(0xFF9575CD), // divine violet
      Color(0xFF4DB6AC), // heaven teal
      Color(0xFF81C784), // seraphim green
      Color(0xFFFFD54F), // halo gold
    ],
    buttonPrimary: Color(0xFF3F51B5),
    buttonSecondary: Color(0xFF283593),
  ),
);

class ThemeRegistry {
  static const Map<GameThemeType, GameThemeData> themes = {
    GameThemeType.forest: forestTheme,
    GameThemeType.beach: beachTheme,
    GameThemeType.devil: devilTheme,
    GameThemeType.angel: angelTheme,
  };

  static GameThemeData get(GameThemeType type) => themes[type]!;
}
