import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  LeaderboardRepository
//  Collection: /leaderboard/{uid}
//  Indexes needed in Firestore console:
//    score DESC
//    country ASC, score DESC
// ─────────────────────────────────────────────

class LeaderboardRepository {
  final FirebaseFirestore _db;

  LeaderboardRepository({FirebaseFirestore? db})
      : _db = db ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _lb =>
      _db.collection('leaderboard');

  // ── Upsert entry after game ───────────────
  Future<void> submitScore({
    required String uid,
    required String username,
    required int score,
    String? photoUrl,
    String? country,
    String? countryName,
  }) async {
    final ref = _lb.doc(uid);
    final snap = await ref.get();
    final currentScore = snap.exists
        ? (snap.data()?['score'] as num?)?.toInt() ?? 0
        : 0;

    if (score <= currentScore) return; // only update if new high score

    await ref.set(
      LeaderboardEntry(
        uid: uid,
        username: username,
        photoUrl: photoUrl,
        score: score,
        country: country,
        countryName: countryName,
        updatedAt: DateTime.now(),
      ).toFirestore(),
      SetOptions(merge: true),
    );
  }

  // ── Global top 100 ────────────────────────
  Future<List<LeaderboardEntry>> getGlobalLeaderboard({int limit = 100}) async {
    final snap = await _lb
        .orderBy('score', descending: true)
        .limit(limit)
        .get();

    return _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList());
  }

  // ── Real-time global top 50 ───────────────
  Stream<List<LeaderboardEntry>> watchGlobalLeaderboard({int limit = 50}) {
    return _lb
        .orderBy('score', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList()));
  }

  // ── Country leaderboard ───────────────────
  Future<List<LeaderboardEntry>> getCountryLeaderboard({
    required String country,
    int limit = 50,
  }) async {
    final snap = await _lb
        .where('country', isEqualTo: country)
        .orderBy('score', descending: true)
        .limit(limit)
        .get();
    return _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList());
  }

  Stream<List<LeaderboardEntry>> watchCountryLeaderboard({
    required String country,
    int limit = 50,
  }) {
    return _lb
        .where('country', isEqualTo: country)
        .orderBy('score', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            _ranked(snap.docs.map(LeaderboardEntry.fromFirestore).toList()));
  }

  // ── Get my rank ───────────────────────────
  Future<int> getMyRank(String uid) async {
    final mySnap = await _lb.doc(uid).get();
    if (!mySnap.exists) return -1;
    final myScore = (mySnap.data()?['score'] as num?)?.toInt() ?? 0;

    final countSnap = await _lb
        .where('score', isGreaterThan: myScore)
        .count()
        .get();
    return (countSnap.count ?? 0) + 1;
  }

  List<LeaderboardEntry> _ranked(List<LeaderboardEntry> entries) {
    for (int i = 0; i < entries.length; i++) {
      entries[i].rank = i + 1;
    }
    return entries;
  }
}

// ─────────────────────────────────────────────
//  LeaderboardState + Notifier
// ─────────────────────────────────────────────

enum LeaderboardFilter { global, country }

class LeaderboardState {
  final List<LeaderboardEntry> entries;
  final LeaderboardFilter filter;
  final bool isLoading;
  final String? error;
  final int? myRank;

  const LeaderboardState({
    this.entries = const [],
    this.filter = LeaderboardFilter.global,
    this.isLoading = false,
    this.error,
    this.myRank,
  });

  LeaderboardState copyWith({
    List<LeaderboardEntry>? entries,
    LeaderboardFilter? filter,
    bool? isLoading,
    String? error,
    int? myRank,
  }) =>
      LeaderboardState(
        entries: entries ?? this.entries,
        filter: filter ?? this.filter,
        isLoading: isLoading ?? this.isLoading,
        error: error,
        myRank: myRank ?? this.myRank,
      );
}

class LeaderboardNotifier extends StateNotifier<LeaderboardState> {
  final LeaderboardRepository _repo;
  final AuthState _authState;

  LeaderboardNotifier(this._repo, this._authState)
      : super(const LeaderboardState()) {
    loadGlobal();
  }

  Future<void> loadGlobal() async {
    state = state.copyWith(isLoading: true, filter: LeaderboardFilter.global);
    try {
      final entries = await _repo.getGlobalLeaderboard();
      final myRank = _authState.user != null
          ? await _repo.getMyRank(_authState.user!.uid)
          : null;
      state = state.copyWith(
          entries: entries, isLoading: false, myRank: myRank);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadCountry() async {
    final country = _authState.user?.country;
    if (country == null || country == 'Unknown') {
      state = state.copyWith(error: 'No country data available');
      return;
    }
    state = state.copyWith(isLoading: true, filter: LeaderboardFilter.country);
    try {
      final entries = await _repo.getCountryLeaderboard(country: country);
      state = state.copyWith(entries: entries, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void switchFilter(LeaderboardFilter f) {
    if (f == LeaderboardFilter.global) {
      loadGlobal();
    } else {
      loadCountry();
    }
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final leaderboardRepositoryProvider = Provider<LeaderboardRepository>((ref) {
  return LeaderboardRepository();
});

final leaderboardProvider =
    StateNotifierProvider<LeaderboardNotifier, LeaderboardState>((ref) {
  return LeaderboardNotifier(
    ref.read(leaderboardRepositoryProvider),
    ref.read(authNotifierProvider),
  );
});
