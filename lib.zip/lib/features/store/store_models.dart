// ─────────────────────────────────────────────
//  Store Models — Items, Categories, Inventory
// ─────────────────────────────────────────────

enum ItemCategory { hat, wing, glasses, horn, halo, powerup, theme }

enum ItemRarity { common, rare, epic, legendary }

class StoreItem {
  final String id;
  final String name;
  final String description;
  final String emoji;         // used as placeholder; replace with asset
  final ItemCategory category;
  final ItemRarity rarity;
  final int coinPrice;
  final bool isPremium;       // IAP only
  final String? iapProductId;
  final Map<String, dynamic> metadata; // theme name, bomb count, etc.

  const StoreItem({
    required this.id,
    required this.name,
    required this.description,
    required this.emoji,
    required this.category,
    required this.rarity,
    required this.coinPrice,
    this.isPremium = false,
    this.iapProductId,
    this.metadata = const {},
  });
}

// ─────────────────────────────────────────────
//  Full item catalog
// ─────────────────────────────────────────────

const List<StoreItem> storeCatalog = [
  // ── Hats ─────────────────────────────────
  StoreItem(
    id: 'hat_crown',
    name: 'Golden Crown',
    description: 'Royalty suits you.',
    emoji: '👑',
    category: ItemCategory.hat,
    rarity: ItemRarity.legendary,
    coinPrice: 2500,
  ),
  StoreItem(
    id: 'hat_wizard',
    name: 'Wizard Hat',
    description: 'Cast spells on your blocks.',
    emoji: '🧙',
    category: ItemCategory.hat,
    rarity: ItemRarity.rare,
    coinPrice: 800,
  ),
  StoreItem(
    id: 'hat_top',
    name: 'Top Hat',
    description: 'Classic and classy.',
    emoji: '🎩',
    category: ItemCategory.hat,
    rarity: ItemRarity.common,
    coinPrice: 300,
  ),
  StoreItem(
    id: 'hat_santa',
    name: 'Santa Hat',
    description: 'Ho ho ho!',
    emoji: '🎅',
    category: ItemCategory.hat,
    rarity: ItemRarity.rare,
    coinPrice: 600,
  ),
  StoreItem(
    id: 'hat_viking',
    name: 'Viking Helmet',
    description: 'Raid those high scores.',
    emoji: '⛑️',
    category: ItemCategory.hat,
    rarity: ItemRarity.epic,
    coinPrice: 1200,
  ),

  // ── Wings ────────────────────────────────
  StoreItem(
    id: 'wing_angel',
    name: 'Angel Wings',
    description: 'Heavenly grace.',
    emoji: '🪽',
    category: ItemCategory.wing,
    rarity: ItemRarity.epic,
    coinPrice: 1500,
  ),
  StoreItem(
    id: 'wing_devil',
    name: 'Devil Wings',
    description: 'Sinfully fast.',
    emoji: '🦇',
    category: ItemCategory.wing,
    rarity: ItemRarity.epic,
    coinPrice: 1500,
  ),
  StoreItem(
    id: 'wing_fairy',
    name: 'Fairy Wings',
    description: 'Sparkle and shine.',
    emoji: '🧚',
    category: ItemCategory.wing,
    rarity: ItemRarity.rare,
    coinPrice: 900,
  ),

  // ── Glasses ──────────────────────────────
  StoreItem(
    id: 'glasses_cool',
    name: 'Sunglasses',
    description: 'Too cool for school.',
    emoji: '😎',
    category: ItemCategory.glasses,
    rarity: ItemRarity.common,
    coinPrice: 200,
  ),
  StoreItem(
    id: 'glasses_monocle',
    name: 'Monocle',
    description: 'Distinguished.',
    emoji: '🧐',
    category: ItemCategory.glasses,
    rarity: ItemRarity.rare,
    coinPrice: 500,
  ),
  StoreItem(
    id: 'glasses_star',
    name: 'Star Glasses',
    description: 'You are a star!',
    emoji: '🌟',
    category: ItemCategory.glasses,
    rarity: ItemRarity.epic,
    coinPrice: 1000,
  ),

  // ── Devil Horns ──────────────────────────
  StoreItem(
    id: 'horn_devil',
    name: 'Devil Horns',
    description: 'Embrace the chaos.',
    emoji: '😈',
    category: ItemCategory.horn,
    rarity: ItemRarity.rare,
    coinPrice: 700,
  ),
  StoreItem(
    id: 'horn_dragon',
    name: 'Dragon Horns',
    description: 'Breathe fire!',
    emoji: '🐲',
    category: ItemCategory.horn,
    rarity: ItemRarity.legendary,
    coinPrice: 3000,
  ),

  // ── Angel Halo ───────────────────────────
  StoreItem(
    id: 'halo_gold',
    name: 'Golden Halo',
    description: 'Pure and radiant.',
    emoji: '😇',
    category: ItemCategory.halo,
    rarity: ItemRarity.epic,
    coinPrice: 1200,
  ),
  StoreItem(
    id: 'halo_rainbow',
    name: 'Rainbow Halo',
    description: 'Colorful divinity.',
    emoji: '🌈',
    category: ItemCategory.halo,
    rarity: ItemRarity.legendary,
    coinPrice: 2800,
  ),

  // ── Powerups ─────────────────────────────
  StoreItem(
    id: 'powerup_bomb_x1',
    name: 'Bomb ×1',
    description: 'Clear any block instantly.',
    emoji: '💣',
    category: ItemCategory.powerup,
    rarity: ItemRarity.common,
    coinPrice: 150,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_bomb_x5',
    name: 'Bomb ×5',
    description: 'Five block-clearing blasts.',
    emoji: '💥',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 600,
    metadata: {'count': 5},
  ),
  StoreItem(
    id: 'powerup_bomb_x10',
    name: 'Bomb ×10',
    description: 'Ten bombs — unstoppable.',
    emoji: '🔥',
    category: ItemCategory.powerup,
    rarity: ItemRarity.epic,
    coinPrice: 1000,
    metadata: {'count': 10},
  ),

  // ── Themes ───────────────────────────────
  StoreItem(
    id: 'theme_beach',
    name: 'Sunset Beach',
    description: 'Ocean vibes.',
    emoji: '🏖️',
    category: ItemCategory.theme,
    rarity: ItemRarity.rare,
    coinPrice: 2000,
    metadata: {'themeId': 'beach'},
  ),
  StoreItem(
    id: 'theme_devil',
    name: 'Inferno Realm',
    description: 'Hellfire and lava.',
    emoji: '😈',
    category: ItemCategory.theme,
    rarity: ItemRarity.epic,
    coinPrice: 3500,
    metadata: {'themeId': 'devil'},
  ),
  StoreItem(
    id: 'theme_angel',
    name: 'Celestial Heaven',
    description: 'Divine atmosphere.',
    emoji: '😇',
    category: ItemCategory.theme,
    rarity: ItemRarity.legendary,
    coinPrice: 4000,
    metadata: {'themeId': 'angel'},
  ),
];

// ─────────────────────────────────────────────
//  Inventory — what user owns
// ─────────────────────────────────────────────

class Inventory {
  final Set<String> ownedItems;
  final String? equippedHat;
  final String? equippedWing;
  final String? equippedGlasses;
  final String? equippedHorn;
  final String? equippedHalo;
  final int bombs;
  final Set<String> unlockedThemes;

  const Inventory({
    this.ownedItems = const {},
    this.equippedHat,
    this.equippedWing,
    this.equippedGlasses,
    this.equippedHorn,
    this.equippedHalo,
    this.bombs = 0,
    this.unlockedThemes = const {'forest'},
  });

  bool owns(String itemId) => ownedItems.contains(itemId);

  Inventory copyWith({
    Set<String>? ownedItems,
    String? equippedHat,
    String? equippedWing,
    String? equippedGlasses,
    String? equippedHorn,
    String? equippedHalo,
    int? bombs,
    Set<String>? unlockedThemes,
    bool clearHat = false,
    bool clearWing = false,
    bool clearGlasses = false,
    bool clearHorn = false,
    bool clearHalo = false,
  }) =>
      Inventory(
        ownedItems: ownedItems ?? this.ownedItems,
        equippedHat: clearHat ? null : equippedHat ?? this.equippedHat,
        equippedWing: clearWing ? null : equippedWing ?? this.equippedWing,
        equippedGlasses: clearGlasses ? null : equippedGlasses ?? this.equippedGlasses,
        equippedHorn: clearHorn ? null : equippedHorn ?? this.equippedHorn,
        equippedHalo: clearHalo ? null : equippedHalo ?? this.equippedHalo,
        bombs: bombs ?? this.bombs,
        unlockedThemes: unlockedThemes ?? this.unlockedThemes,
      );

  Map<String, dynamic> toMap() => {
        'ownedItems': ownedItems.toList(),
        'equippedHat': equippedHat,
        'equippedWing': equippedWing,
        'equippedGlasses': equippedGlasses,
        'equippedHorn': equippedHorn,
        'equippedHalo': equippedHalo,
        'bombs': bombs,
        'unlockedThemes': unlockedThemes.toList(),
      };

  factory Inventory.fromMap(Map<String, dynamic> m) => Inventory(
        ownedItems: Set<String>.from(m['ownedItems'] ?? []),
        equippedHat: m['equippedHat'],
        equippedWing: m['equippedWing'],
        equippedGlasses: m['equippedGlasses'],
        equippedHorn: m['equippedHorn'],
        equippedHalo: m['equippedHalo'],
        bombs: (m['bombs'] as num?)?.toInt() ?? 0,
        unlockedThemes: Set<String>.from(m['unlockedThemes'] ?? ['forest']),
      );

  static Inventory get empty => const Inventory(unlockedThemes: {'forest'});
}

// ─────────────────────────────────────────────
//  Rarity colors
// ─────────────────────────────────────────────

extension RarityStyle on ItemRarity {
  String get label => switch (this) {
        ItemRarity.common => 'Common',
        ItemRarity.rare => 'Rare',
        ItemRarity.epic => 'Epic',
        ItemRarity.legendary => 'Legendary',
      };

  List<int> get colors => switch (this) {
        ItemRarity.common => [0xFF9E9E9E, 0xFF757575],
        ItemRarity.rare => [0xFF2196F3, 0xFF1565C0],
        ItemRarity.epic => [0xFF9C27B0, 0xFF6A1B9A],
        ItemRarity.legendary => [0xFFFF9800, 0xFFE65100],
      };
}
