import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'components/forest_background.dart';
import 'components/game_grid.dart';
import 'components/theme_backgrounds.dart';
import '../../core/theme/game_theme.dart';
import '../../core/services/sound_manager.dart';
import '../spin_wheel/spin_wheel_screen.dart';
import '../leaderboard/presentation/leaderboard_screen.dart';
import '../store/store_screen.dart';
import '../daily_reward/presentation/daily_reward_screen.dart';

// ─────────────────────────────────────────────
//  Game Screen — Forest Theme
// ─────────────────────────────────────────────

class GameScreen extends ConsumerStatefulWidget {
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  GameThemeData _theme = forestTheme;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _startAmbient();
  }

  Future<void> _startAmbient() async {
    final sound = ref.read(soundManagerProvider);
    await sound.preload();
    await sound.playMusic(_theme.ambientSound);
  }

  void _onThemeChanged(GameThemeData theme) {
    if (theme.type == _theme.type) return;
    setState(() => _theme = theme);
    ref.read(soundManagerProvider).playMusic(theme.ambientSound);
  }

  Widget _themedBackground({required Widget child}) {
    return switch (_theme.type) {
      GameThemeType.forest => ForestBackground(child: child),
      GameThemeType.beach  => BeachBackground(child: child),
      GameThemeType.devil  => DevilBackground(child: child),
      GameThemeType.angel  => AngelBackground(child: child),
    };
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final safeTop = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: Colors.black,
      body: _themedBackground(
        child: SafeArea(
          child: SizedBox(
            height: size.height - safeTop,
            child: Column(
              children: [
                _TopHUD(
                  theme: _theme,
                  onThemeChanged: _onThemeChanged,
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: GameGrid(theme: _theme),
                ),
                const Spacer(),
                _FeatureNavBar(theme: _theme, themedBackground: _themedBackground),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Top HUD
// ─────────────────────────────────────────────

class _TopHUD extends StatelessWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;
  const _TopHUD({required this.theme, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Theme name
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: colors.panelBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: colors.panelBorder.withOpacity(0.4),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: colors.glowColor,
                    boxShadow: [
                      BoxShadow(
                        color: colors.glowColor,
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  theme.name,
                  style: TextStyle(
                    color: colors.textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),

          // Settings button
          _HudButton(
            icon: Icons.settings_outlined,
            colors: colors,
            onTap: () => _showSettings(context),
          ),
        ],
      ),
    );
  }

  void _showSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _SettingsSheet(
        theme: theme,
        onThemeChanged: onThemeChanged,
      ),
    );
  }
}

class _HudButton extends StatelessWidget {
  final IconData icon;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _HudButton({
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: colors.panelBg,
          shape: BoxShape.circle,
          border: Border.all(
            color: colors.panelBorder.withOpacity(0.4),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.1),
              blurRadius: 8,
            ),
          ],
        ),
        child: Icon(icon, color: colors.textPrimary, size: 20),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Feature navigation (spin, leaderboard, store, rewards)
// ─────────────────────────────────────────────

class _FeatureNavBar extends StatelessWidget {
  final GameThemeData theme;
  final Widget Function({required Widget child}) themedBackground;

  const _FeatureNavBar({
    required this.theme,
    required this.themedBackground,
  });

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => themedBackground(child: screen)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: colors.panelBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: colors.panelBorder.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.08),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _NavItem(
              icon: Icons.casino_outlined,
              label: 'Spin',
              colors: colors,
              onTap: () => _open(context, SpinWheelScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.leaderboard_outlined,
              label: 'Ranks',
              colors: colors,
              onTap: () => _open(context, LeaderboardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.card_giftcard_outlined,
              label: 'Daily',
              colors: colors,
              onTap: () => _open(context, DailyRewardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.storefront_outlined,
              label: 'Store',
              colors: colors,
              onTap: () => _open(context, StoreScreen(theme: theme)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: colors.textAccent, size: 26),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: colors.textPrimary.withOpacity(0.75),
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Settings Sheet
// ─────────────────────────────────────────────

class _SettingsSheet extends ConsumerWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;
  const _SettingsSheet({required this.theme, required this.onThemeChanged});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colors = theme.colors;
    final sound = ref.read(soundManagerProvider);

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: colors.panelBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: colors.panelBorder.withOpacity(0.5),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.glowColor.withOpacity(0.15),
            blurRadius: 24,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Settings',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          _SettingsRow(
            label: 'Music',
            icon: Icons.music_note_outlined,
            value: sound.musicEnabled,
            colors: colors,
            onChanged: (_) => sound.toggleMusic(),
          ),
          const SizedBox(height: 12),
          _SettingsRow(
            label: 'Sound Effects',
            icon: Icons.volume_up_outlined,
            value: sound.sfxEnabled,
            colors: colors,
            onChanged: (_) => sound.toggleSfx(),
          ),
          const SizedBox(height: 24),
          Text(
            'Theme',
            style: TextStyle(
              color: colors.textPrimary.withOpacity(0.5),
              fontSize: 12,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          _ThemeChips(
            currentTheme: theme,
            colors: colors,
            onThemeSelected: (t) {
              onThemeChanged(t);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}

class _SettingsRow extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool value;
  final GameThemeColors colors;
  final ValueChanged<bool> onChanged;

  const _SettingsRow({
    required this.label,
    required this.icon,
    required this.value,
    required this.colors,
    required this.onChanged,
  });

  @override
  State<_SettingsRow> createState() => _SettingsRowState();
}

class _SettingsRowState extends State<_SettingsRow> {
  late bool _value;

  @override
  void initState() {
    super.initState();
    _value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.colors;
    return Row(
      children: [
        Icon(widget.icon, color: colors.textPrimary.withOpacity(0.7), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            widget.label,
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 15,
            ),
          ),
        ),
        Switch.adaptive(
          value: _value,
          onChanged: (v) {
            setState(() => _value = v);
            widget.onChanged(v);
          },
          activeColor: colors.glowColor,
        ),
      ],
    );
  }
}

class _ThemeChips extends StatelessWidget {
  final GameThemeData currentTheme;
  final GameThemeColors colors;
  final ValueChanged<GameThemeData> onThemeSelected;

  const _ThemeChips({
    required this.currentTheme,
    required this.colors,
    required this.onThemeSelected,
  });

  @override
  Widget build(BuildContext context) {
    final themes = ThemeRegistry.themes.values.toList();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: themes.map((t) {
        final isActive = t.type == currentTheme.type;
        return GestureDetector(
          onTap: () => onThemeSelected(t),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isActive
                  ? colors.buttonPrimary.withOpacity(0.3)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isActive
                    ? colors.panelBorder
                    : colors.panelBorder.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Text(
              t.name,
              style: TextStyle(
                color: isActive
                    ? colors.textAccent
                    : colors.textPrimary.withOpacity(0.5),
                fontSize: 12,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
