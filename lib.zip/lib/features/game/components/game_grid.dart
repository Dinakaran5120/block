import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../bloc/game_notifier.dart';
import '../../../core/constants/game_constants.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  GameGrid — 8×8 board + tray + drag & drop
//  FIX: GameOverPanel in Stack not Column
//  FIX: Drag uses onPanStart (immediate, no long press)
// ─────────────────────────────────────────────

class GameGrid extends ConsumerStatefulWidget {
  final GameThemeData theme;
  const GameGrid({super.key, required this.theme});

  @override
  ConsumerState<GameGrid> createState() => _GameGridState();
}

class _GameGridState extends ConsumerState<GameGrid>
    with TickerProviderStateMixin {
  int?        _draggingTrayIndex;
  BlockShape? _draggingShape;
  Offset?     _dragPosition;
  int?        _hoverRow, _hoverCol;
  bool        _canDrop = false;

  late AnimationController _comboCtrl;
  late AnimationController _shakeCtrl;
  late Animation<Offset> _shakeAnim;
  final GlobalKey _gridKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _comboCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: GameConstants.comboTextDurationMs),
    );
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = TweenSequence<Offset>([
      TweenSequenceItem(
        tween: Tween(begin: Offset.zero, end: const Offset(3, 2)),
        weight: 25,
      ),
      TweenSequenceItem(
        tween: Tween(begin: const Offset(3, 2), end: const Offset(-3, -2)),
        weight: 25,
      ),
      TweenSequenceItem(
        tween: Tween(begin: const Offset(-3, -2), end: const Offset(2, -1)),
        weight: 25,
      ),
      TweenSequenceItem(
        tween: Tween(begin: const Offset(2, -1), end: Offset.zero),
        weight: 25,
      ),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _comboCtrl.dispose();
    _shakeCtrl.dispose();
    super.dispose();
  }

  // ── Snap cell calculation ─────────────────
  ({int row, int col})? _snapCell(Offset globalOffset) {
    if (_draggingShape == null) return null;
    final box = _gridKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return null;
    final local = box.globalToLocal(globalOffset);
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final adjLocal = Offset(
      local.dx - (_draggingShape!.width  / 2.0) * ct,
      local.dy - (_draggingShape!.height / 2.0) * ct - 30,
    );
    final col = (adjLocal.dx / ct).round();
    final row = (adjLocal.dy / ct).round();
    return (row: row, col: col);
  }

  void _onDragStart(int idx, BlockShape shape, Offset globalPos) {
    setState(() {
      _draggingTrayIndex = idx;
      _draggingShape     = shape;
      _dragPosition      = globalPos;
    });
    _onDragUpdate(globalPos);
  }

  void _onDragUpdate(Offset globalOffset) {
    final snap = _snapCell(globalOffset);
    setState(() {
      _dragPosition = globalOffset;
      _hoverRow = snap?.row;
      _hoverCol = snap?.col;
      _canDrop  = snap != null && _draggingShape != null
          ? ref.read(gameProvider.notifier).canPlace(_draggingShape!, snap.row, snap.col)
          : false;
    });
  }

  Future<void> _onDragEnd() async {
    if (_draggingTrayIndex != null &&
        _draggingShape != null &&
        _hoverRow != null &&
        _hoverCol != null &&
        _canDrop) {
      await ref.read(gameProvider.notifier)
          .placeBlock(_draggingTrayIndex!, _hoverRow!, _hoverCol!);
    }
    setState(() {
      _draggingTrayIndex = null;
      _draggingShape     = null;
      _dragPosition      = null;
      _hoverRow          = null;
      _hoverCol          = null;
      _canDrop           = false;
    });
  }

  bool _isCellHovered(int r, int c) {
    if (_draggingShape == null || _hoverRow == null || _hoverCol == null) return false;
    for (final cell in _draggingShape!.cells) {
      if (_hoverRow! + cell[0] == r && _hoverCol! + cell[1] == c) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final gs     = ref.watch(gameProvider);
    final colors = widget.theme.colors;
    final G      = GameConstants.gridSize;
    final ct     = GameConstants.cellSize + GameConstants.cellGap;
    final gridPx = ct * G - GameConstants.cellGap;

    final renderBox = context.findRenderObject() as RenderBox?;
    final localDrag = _dragPosition != null && renderBox != null
        ? renderBox.globalToLocal(_dragPosition!)
        : null;

    // Trigger screen shake when lines are being cleared
    if (gs.clearingRows.isNotEmpty || gs.clearingCols.isNotEmpty) {
      if (_shakeCtrl.status == AnimationStatus.dismissed) {
        _shakeCtrl.forward(from: 0);
      }
    }

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerMove: (e) {
        if (_draggingShape != null) _onDragUpdate(e.position);
      },
      onPointerUp: (_) => _onDragEnd(),
      onPointerCancel: (_) => _onDragEnd(),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          AnimatedBuilder(
            animation: _shakeAnim,
            builder: (_, child) => Transform.translate(
              offset: _shakeAnim.value,
              child: child,
            ),
            child: Column(
              children: [
                _ScorePanel(theme: widget.theme, gameState: gs),
                const SizedBox(height: 16),
                SizedBox(
                  width: gridPx,
                  height: gridPx,
                  child: Stack(
                    children: [
                      _GridBackground(
                        gridPx: gridPx,
                        colors: colors,
                        gridKey: _gridKey,
                      ),
                      for (int r = 0; r < G; r++)
                        for (int c = 0; c < G; c++)
                          _GridCell(
                            row: r,
                            col: c,
                            state: gs.grid[r][c],
                            colors: colors,
                            isHovered: _isCellHovered(r, c),
                            canDrop: _canDrop,
                            theme: widget.theme,
                          ),
                      if (_draggingShape != null &&
                          _hoverRow != null &&
                          _hoverCol != null)
                        _GhostOverlay(
                          shape: _draggingShape!,
                          row: _hoverRow!,
                          col: _hoverCol!,
                          canDrop: _canDrop,
                          colors: colors,
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                _TrayRow(
                  theme: widget.theme,
                  gameState: gs,
                  onDragStart: _onDragStart,
                  onDragUpdate: _onDragUpdate,
                  onDragEnd: _onDragEnd,
                ),
              ],
            ),
          ),
          if (_draggingShape != null && localDrag != null)
            _DragPreview(
              shape: _draggingShape!,
              position: localDrag,
              colors: colors,
            ),
          if (gs.isGameOver)
            _GameOverPanel(
              theme: widget.theme,
              score: gs.score,
              highScore: gs.highScore,
              onRestart: () => ref.read(gameProvider.notifier).resetGame(),
            ),
        ],
      ),
    );
  }
}

// ── Grid Background ────────────────────────────────────────────────────────

class _GridBackground extends StatelessWidget {
  final double gridPx;
  final GameThemeColors colors;
  final GlobalKey gridKey;
  const _GridBackground({required this.gridPx, required this.colors, required this.gridKey});

  @override
  Widget build(BuildContext context) {
    return Container(
      key: gridKey,
      width: gridPx, height: gridPx,
      decoration: BoxDecoration(
        color: colors.gridBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1.5),
        boxShadow: [BoxShadow(color: colors.glowColor.withOpacity(0.15), blurRadius: 20, spreadRadius: 2)],
      ),
      child: CustomPaint(painter: _GridLinePainter(colors: colors)),
    );
  }
}

class _GridLinePainter extends CustomPainter {
  final GameThemeColors colors;
  const _GridLinePainter({required this.colors});
  @override
  void paint(Canvas canvas, Size size) {
    final G  = GameConstants.gridSize;
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final p  = Paint()..color = colors.gridLine.withOpacity(0.4)..strokeWidth = 0.5;
    for (int i = 0; i <= G; i++) {
      final pos = i * ct;
      canvas.drawLine(Offset(pos, 0), Offset(pos, size.height), p);
      canvas.drawLine(Offset(0, pos), Offset(size.width, pos), p);
    }
  }
  @override bool shouldRepaint(_GridLinePainter o) => false;
}

// ── Grid Cell ──────────────────────────────────────────────────────────────

class _GridCell extends StatefulWidget {
  final int row, col;
  final CellState state;
  final GameThemeColors colors;
  final bool isHovered, canDrop;
  final GameThemeData theme;
  const _GridCell({
    required this.row, required this.col, required this.state,
    required this.colors, required this.isHovered, required this.canDrop,
    required this.theme,
  });
  @override State<_GridCell> createState() => _GridCellState();
}

class _GridCellState extends State<_GridCell> with TickerProviderStateMixin {
  late AnimationController _ctrl;
  late AnimationController _shimmerCtrl;
  late Animation<double> _scaleAnim, _glowAnim;
  late Animation<double> _shimmerAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: GameConstants.lineClearDurationMs));
    _scaleAnim = Tween(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
    _glowAnim  = Tween(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
    _shimmerAnim = Tween(begin: -1.0, end: 1.0).animate(
      CurvedAnimation(parent: _shimmerCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void didUpdateWidget(_GridCell old) {
    super.didUpdateWidget(old);
    if (!old.state.clearing && widget.state.clearing) _ctrl.forward(from: 0);
    if ( old.state.clearing && !widget.state.clearing) _ctrl.reset();
  }

  @override void dispose() { _ctrl.dispose(); _shimmerCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final ct = GameConstants.cellSize + GameConstants.cellGap;
    final x  = widget.col * ct + GameConstants.cellGap / 2;
    final y  = widget.row * ct + GameConstants.cellGap / 2;
    final cs = GameConstants.cellSize;

    Color cellColor;
    double glowOpacity = 0;

    if (widget.state.clearing) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor   = widget.colors.blockColors[idx];
      glowOpacity = _glowAnim.value;
    } else if (widget.state.filled) {
      final idx = widget.state.colorIndex.clamp(0, widget.colors.blockColors.length - 1);
      cellColor   = widget.colors.blockColors[idx];
    } else if (widget.isHovered) {
      cellColor = widget.canDrop
          ? widget.colors.glowColor.withOpacity(0.5)
          : Colors.red.withOpacity(0.4);
    } else {
      cellColor = widget.colors.cellEmpty;
    }

    return Positioned(
      left: x, top: y,
      child: AnimatedBuilder(
        animation: Listenable.merge([_ctrl, _shimmerCtrl]),
        builder: (_, __) => Transform.scale(
          scale: widget.state.clearing ? _scaleAnim.value : 1.0,
          child: Container(
            width: cs, height: cs,
            decoration: widget.state.filled
                ? _buildPremiumBlockDecoration(cellColor, glowOpacity)
                : BoxDecoration(
                    color: cellColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
            child: widget.state.filled 
                ? _PremiumBlockHighlight(
                    color: cellColor,
                    shimmerValue: _shimmerAnim.value,
                  ) 
                : null,
          ),
        ),
      ),
    );
  }

  BoxDecoration _buildPremiumBlockDecoration(Color color, double glowOpacity) {
    // Create vibrant saturated base color
    final baseColor = Color.fromARGB(
      color.alpha,
      (color.red * 1.2).clamp(0, 255).toInt(),
      (color.green * 1.2).clamp(0, 255).toInt(),
      (color.blue * 1.2).clamp(0, 255).toInt(),
    );
    
    // Lighter color for highlights (embossed top-left)
    final highlightColor = Color.fromARGB(
      baseColor.alpha,
      (baseColor.red + 40).clamp(0, 255).toInt(),
      (baseColor.green + 40).clamp(0, 255).toInt(),
      (baseColor.blue + 40).clamp(0, 255).toInt(),
    );
    
    // Darker color for shadows (embossed bottom-right)
    final shadowColor = Color.fromARGB(
      baseColor.alpha,
      (baseColor.red - 40).clamp(0, 255).toInt(),
      (baseColor.green - 40).clamp(0, 255).toInt(),
      (baseColor.blue - 40).clamp(0, 255).toInt(),
    );
    
    // Enhanced gradient for embossed 3D depth
    final innerGradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        highlightColor.withOpacity(0.95),  // Top-left highlight
        baseColor.withOpacity(0.85),       // Mid-top
        baseColor.withOpacity(0.65),       // Mid-bottom
        shadowColor.withOpacity(0.75),     // Bottom-right shadow
      ],
      stops: const [0.0, 0.25, 0.75, 1.0],
    );
    
    return BoxDecoration(
      gradient: innerGradient,
      borderRadius: BorderRadius.circular(10),
      // Enhanced layered shadows for embossed depth
      boxShadow: [
        // Inner glow (bright)
        BoxShadow(
          color: baseColor.withOpacity(0.5 + glowOpacity * 0.4),
          blurRadius: 6 + glowOpacity * 12,
          spreadRadius: 0,
          offset: const Offset(0, -1),
        ),
        // Outer ambient glow
        BoxShadow(
          color: baseColor.withOpacity(0.25 + glowOpacity * 0.25),
          blurRadius: 18 + glowOpacity * 22,
          spreadRadius: 0,
        ),
        // Strong drop shadow for embossed elevation
        BoxShadow(
          color: Colors.black.withOpacity(0.4),
          blurRadius: 8,
          offset: const Offset(0, 4),
          spreadRadius: -2,
        ),
        // Inner shadow effect (top-left highlight)
        BoxShadow(
          color: Colors.white.withOpacity(0.15),
          blurRadius: 4,
          offset: const Offset(-2, -2),
          spreadRadius: -2,
        ),
      ],
      // Beveled border for embossed edge
      border: Border.all(
        color: baseColor.withOpacity(0.85),
        width: 2,
      ),
    );
  }
}

// ── Floating drag preview (follows finger) ───────────────────────────────

class _DragPreview extends StatelessWidget {
  final BlockShape shape;
  final Offset position;
  final GameThemeColors colors;

  const _DragPreview({
    required this.shape,
    required this.position,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    const mini = 22.0;
    final w = shape.width * mini;
    final h = shape.height * mini;
    return Positioned(
      left: position.dx - w / 2,
      top: position.dy - h / 2 - 30,
      child: IgnorePointer(
        child: Material(
          color: Colors.transparent,
          child: CustomPaint(
            size: Size(w, h),
            painter: _ShapePainter(
              shape: shape,
              colors: colors,
              cellSize: mini,
            ),
          ),
        ),
      ),
    );
  }
}

class _PremiumBlockHighlight extends StatelessWidget {
  final Color color;
  final double shimmerValue;
  const _PremiumBlockHighlight({
    required this.color,
    required this.shimmerValue,
  });
  
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Top glossy highlight (glass-like shine)
        Positioned(
          top: 2,
          left: 2,
          right: 2,
          child: Container(
            height: 12,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withOpacity(0.6),
                  Colors.white.withOpacity(0.3),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        // Reflective edge lighting
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.white.withOpacity(0.4),
                width: 1,
              ),
            ),
          ),
        ),
        // Animated shimmer sweep
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Opacity(
              opacity: 0.3,
              child: Transform.translate(
                offset: Offset(shimmerValue * 40, 0),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Colors.transparent,
                        Colors.white.withOpacity(0.5),
                        Colors.transparent,
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        // Inner glow gem effect
        Center(
          child: Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.4),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ── Ghost Overlay ──────────────────────────────────────────────────────────

class _GhostOverlay extends StatelessWidget {
  final BlockShape shape;
  final int row, col;
  final bool canDrop;
  final GameThemeColors colors;
  const _GhostOverlay({required this.shape, required this.row, required this.col,
    required this.canDrop, required this.colors});

  @override
  Widget build(BuildContext context) {
    final ct    = GameConstants.cellSize + GameConstants.cellGap;
    final cs    = GameConstants.cellSize;
    final color = canDrop ? colors.glowColor.withOpacity(0.6) : Colors.red.withOpacity(0.5);
    return Stack(
      children: shape.cells.map((cell) {
        final r = row + cell[0];
        final c = col + cell[1];
        if (r < 0 || r >= GameConstants.gridSize) return const SizedBox();
        if (c < 0 || c >= GameConstants.gridSize) return const SizedBox();
        return Positioned(
          left: c * ct + GameConstants.cellGap / 2,
          top:  r * ct + GameConstants.cellGap / 2,
          child: Container(
            width: cs, height: cs,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: canDrop ? colors.glowColor : Colors.red, width: 1),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ── Tray Row ───────────────────────────────────────────────────────────────

class _TrayRow extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  final void Function(int, BlockShape, Offset) onDragStart;
  final void Function(Offset) onDragUpdate;
  final VoidCallback onDragEnd;

  const _TrayRow({
    required this.theme,
    required this.gameState,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: GameConstants.blockPieceTrayHeight,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(
          3,
          (i) => _TrayPiece(
            index: i,
            shape: gameState.trayPieces[i],
            theme: theme,
            onDragStart: onDragStart,
            onDragUpdate: onDragUpdate,
            onDragEnd: onDragEnd,
            disabled: gameState.isAnimating || gameState.isGameOver,
          ),
        ),
      ),
    );
  }
}

class _TrayPiece extends StatefulWidget {
  final int index;
  final BlockShape? shape;
  final GameThemeData theme;
  final void Function(int, BlockShape, Offset) onDragStart;
  final void Function(Offset) onDragUpdate;
  final VoidCallback onDragEnd;
  final bool disabled;

  const _TrayPiece({
    required this.index,
    required this.shape,
    required this.theme,
    required this.onDragStart,
    required this.onDragUpdate,
    required this.onDragEnd,
    required this.disabled,
  });
  @override State<_TrayPiece> createState() => _TrayPieceState();
}

class _TrayPieceState extends State<_TrayPiece> with SingleTickerProviderStateMixin {
  late AnimationController _bounceCtrl;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
  }

  @override void dispose() { _bounceCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (widget.shape == null) return const SizedBox(width: 100, height: 100);
    final shape  = widget.shape!;
    final colors = widget.theme.colors;
    const mini   = 22.0;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: widget.disabled
          ? null
          : (details) {
              setState(() => _isDragging = true);
              widget.onDragStart(widget.index, shape, details.globalPosition);
            },
      onPanUpdate: widget.disabled
          ? null
          : (details) => widget.onDragUpdate(details.globalPosition),
      onPanEnd: widget.disabled
          ? null
          : (_) {
              setState(() => _isDragging = false);
              widget.onDragEnd();
            },
      onPanCancel: widget.disabled
          ? null
          : () {
              setState(() => _isDragging = false);
              widget.onDragEnd();
            },
      child: AnimatedBuilder(
        animation: _bounceCtrl,
        builder: (_, __) {
          final bounce = sin(_bounceCtrl.value * pi) * 3;
          return Transform.translate(
            offset: Offset(0, _isDragging ? 0 : bounce),
            child: Opacity(
              opacity: _isDragging ? 0.3 : 1.0,
              child: Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: colors.panelBorder.withOpacity(0.5), width: 1),
                  boxShadow: [BoxShadow(color: colors.glowColor.withOpacity(0.1), blurRadius: 8)],
                ),
                child: Center(
                  child: CustomPaint(
                    size: Size(shape.width * mini, shape.height * mini),
                    painter: _ShapePainter(shape: shape, colors: colors, cellSize: mini),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ShapePainter extends CustomPainter {
  final BlockShape shape;
  final GameThemeColors colors;
  final double cellSize;
  const _ShapePainter({required this.shape, required this.colors, required this.cellSize});

  @override
  void paint(Canvas canvas, Size size) {
    final idx   = shape.colorIndex.clamp(0, colors.blockColors.length - 1);
    final baseColor = colors.blockColors[idx];
    
    // Create vibrant saturated color
    final color = Color.fromARGB(
      baseColor.alpha,
      (baseColor.red * 1.2).clamp(0, 255).toInt(),
      (baseColor.green * 1.2).clamp(0, 255).toInt(),
      (baseColor.blue * 1.2).clamp(0, 255).toInt(),
    );
    
    // Lighter color for highlights (embossed top-left)
    final highlightColor = Color.fromARGB(
      baseColor.alpha,
      (baseColor.red + 40).clamp(0, 255).toInt(),
      (baseColor.green + 40).clamp(0, 255).toInt(),
      (baseColor.blue + 40).clamp(0, 255).toInt(),
    );
    
    // Darker color for shadows (embossed bottom-right)
    final shadowColor = Color.fromARGB(
      baseColor.alpha,
      (baseColor.red - 40).clamp(0, 255).toInt(),
      (baseColor.green - 40).clamp(0, 255).toInt(),
      (baseColor.blue - 40).clamp(0, 255).toInt(),
    );
    
    // Multiple glow layers for premium effect
    final glow1 = Paint()
      ..color = color.withOpacity(0.5)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    
    final glow2 = Paint()
      ..color = color.withOpacity(0.3)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);

    for (final cell in shape.cells) {
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cell[1]*cellSize+1, cell[0]*cellSize+1, cellSize-2, cellSize-2),
        const Radius.circular(6),
      );
      
      // Draw outer glow layers
      canvas.drawRRect(rect, glow2);
      canvas.drawRRect(rect, glow1);
      
      // Draw main block with embossed gradient effect
      final gradient = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          highlightColor.withOpacity(0.95),  // Top-left highlight
          color.withOpacity(0.85),          // Mid-top
          color.withOpacity(0.65),          // Mid-bottom
          shadowColor.withOpacity(0.75),    // Bottom-right shadow
        ],
        stops: const [0.0, 0.25, 0.75, 1.0],
      );
      
      final gradientPaint = Paint()
        ..shader = gradient.createShader(rect.outerRect);
      canvas.drawRRect(rect, gradientPaint);
      
      // Top glossy highlight (embossed edge)
      final highlightRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cell[1]*cellSize+2, cell[0]*cellSize+2, cellSize-4, cellSize*0.35),
        const Radius.circular(4),
      );
      
      final highlightGradient = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.white.withOpacity(0.6),
          Colors.white.withOpacity(0.3),
          Colors.transparent,
        ],
      );
      
      final highlightPaint = Paint()
        ..shader = highlightGradient.createShader(highlightRect.outerRect);
      canvas.drawRRect(highlightRect, highlightPaint);
      
      // Inner gem glow
      final gemCenter = Offset(
        cell[1]*cellSize + cellSize/2,
        cell[0]*cellSize + cellSize/2,
      );
      
      final gemPaint = Paint()
        ..color = Colors.white.withOpacity(0.35)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
      canvas.drawCircle(gemCenter, 3, gemPaint);
      
      // Embossed glossy border (beveled edge)
      final borderPaint = Paint()
        ..color = color.withOpacity(0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;
      canvas.drawRRect(rect, borderPaint);
      
      // Inner highlight for embossed depth (top-left)
      final innerHighlightPaint = Paint()
        ..color = Colors.white.withOpacity(0.2)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(cell[1]*cellSize+3, cell[0]*cellSize+3, cellSize-6, cellSize-6),
          const Radius.circular(4),
        ),
        innerHighlightPaint,
      );
    }
  }
  @override bool shouldRepaint(_ShapePainter o) => false;
}

// ── Score Panel ────────────────────────────────────────────────────────────

class _ScorePanel extends StatelessWidget {
  final GameThemeData theme;
  final GameState gameState;
  const _ScorePanel({required this.theme, required this.gameState});

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            c.panelBg,
            c.panelBg.withOpacity(0.85),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: c.panelBorder.withOpacity(0.6), width: 1.5),
        boxShadow: [
          // Inner glow
          BoxShadow(
            color: c.glowColor.withOpacity(0.25),
            blurRadius: 15,
            spreadRadius: 1,
          ),
          // Outer ambient glow
          BoxShadow(
            color: c.glowColor.withOpacity(0.15),
            blurRadius: 25,
            spreadRadius: 2,
          ),
          // Drop shadow for embossed depth
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
            spreadRadius: -3,
          ),
          // Top highlight for embossed effect
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            blurRadius: 6,
            offset: const Offset(-1, -1),
            spreadRadius: -1,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatBadge(label: 'SCORE', value: gameState.score.toString(), colors: c),
          if (gameState.combo > 1)
            _StatBadge(label: 'COMBO', value: '×${gameState.combo}', colors: c, isCombo: true),
          _StatBadge(label: 'BEST', value: gameState.highScore.toString(), colors: c),
        ],
      ),
    );
  }
}

class _StatBadge extends StatelessWidget {
  final String label, value;
  final GameThemeColors colors;
  final bool isCombo;
  const _StatBadge({required this.label, required this.value, required this.colors, this.isCombo = false});

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(label, style: TextStyle(
        color: colors.textPrimary.withOpacity(0.6), fontSize: 11,
        letterSpacing: 2, fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text(value, style: TextStyle(
        color: isCombo ? colors.textAccent : colors.textPrimary,
        fontSize: isCombo ? 24 : 22, fontWeight: FontWeight.w800,
        letterSpacing: 0.5,
        shadows: isCombo 
            ? [
                Shadow(color: colors.glowColor.withOpacity(0.8), blurRadius: 12),
                Shadow(color: colors.glowColor.withOpacity(0.4), blurRadius: 6, offset: Offset(0, 2)),
              ]
            : [
                Shadow(color: colors.glowColor.withOpacity(0.3), blurRadius: 6),
              ])),
    ],
  );
}

// ── Game Over Panel ────────────────────────────────────────────────────────

class _GameOverPanel extends StatelessWidget {
  final GameThemeData theme;
  final int score, highScore;
  final VoidCallback onRestart;
  const _GameOverPanel({required this.theme, required this.score,
    required this.highScore, required this.onRestart});

  @override
  Widget build(BuildContext context) {
    final c = theme.colors;
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.80),
        child: Center(
          child: Container(
            margin: const EdgeInsets.all(32),
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: c.panelBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: c.panelBorder, width: 1.5),
              boxShadow: [BoxShadow(color: c.glowColor.withOpacity(0.25),
                  blurRadius: 30, spreadRadius: 5)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('GAME OVER', style: TextStyle(
                  color: c.textPrimary, fontSize: 28, fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                  shadows: [Shadow(color: c.glowColor, blurRadius: 12)])),
                const SizedBox(height: 20),
                Text('Score: $score', style: TextStyle(
                  color: c.textAccent, fontSize: 20, fontWeight: FontWeight.w600)),
                Text('Best: $highScore', style: TextStyle(
                  color: c.textPrimary.withOpacity(0.6), fontSize: 14)),
                const SizedBox(height: 28),
                _PremiumButton(label: 'PLAY AGAIN', colors: c, onTap: onRestart),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Premium Button ─────────────────────────────────────────────────────────

class _PremiumButton extends StatefulWidget {
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;
  const _PremiumButton({required this.label, required this.colors, required this.onTap});
  @override State<_PremiumButton> createState() => _PremiumButtonState();
}

class _PremiumButtonState extends State<_PremiumButton> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween(begin: 1.0, end: 0.94).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeIn));
  }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [c.buttonPrimary, c.buttonSecondary],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: c.panelBorder.withOpacity(0.8), width: 1.5),
              boxShadow: [
                // Inner glow
                BoxShadow(
                  color: c.glowColor.withOpacity(0.5),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
                // Outer glow
                BoxShadow(
                  color: c.glowColor.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
                // Drop shadow
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                  spreadRadius: -2,
                ),
                // Top highlight
                BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  blurRadius: 6,
                  offset: const Offset(-1, -1),
                  spreadRadius: -1,
                ),
              ],
            ),
            child: Text(widget.label, style: TextStyle(
              color: c.textPrimary, fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: 2.5,
              shadows: [
                Shadow(color: c.glowColor.withOpacity(0.5), blurRadius: 8),
              ],
            )),
          ),
        ),
      ),
    );
  }
}
