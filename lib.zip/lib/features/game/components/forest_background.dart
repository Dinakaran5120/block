import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────
//  Forest Theme — Animated Background System
//  Particles · Leaves · Dynamic Glow · Fog
// ─────────────────────────────────────────────

class ForestBackground extends StatefulWidget {
  final Widget child;
  const ForestBackground({super.key, required this.child});

  @override
  State<ForestBackground> createState() => _ForestBackgroundState();
}

class _ForestBackgroundState extends State<ForestBackground>
    with TickerProviderStateMixin {
  late AnimationController _particleCtrl;
  late AnimationController _leafCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _fogCtrl;

  final List<_Particle> _particles = [];
  final List<_Leaf> _leaves = [];
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    _particleCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 4),
    )..repeat();

    _leafCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 8),
    )..repeat();

    _glowCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _fogCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 12),
    )..repeat(reverse: true);

    _spawnParticles();
    _spawnLeaves();
  }

  void _spawnParticles() {
    for (int i = 0; i < 30; i++) {
      _particles.add(_Particle(
        x: _rng.nextDouble(),
        y: _rng.nextDouble(),
        size: _rng.nextDouble() * 3 + 1,
        speed: _rng.nextDouble() * 0.3 + 0.05,
        opacity: _rng.nextDouble() * 0.6 + 0.2,
        hue: _rng.nextInt(3), // 0=green, 1=gold, 2=blue
        phase: _rng.nextDouble(),
      ));
    }
  }

  void _spawnLeaves() {
    for (int i = 0; i < 12; i++) {
      _leaves.add(_Leaf(
        x: _rng.nextDouble(),
        startY: _rng.nextDouble() * -0.5,
        size: _rng.nextDouble() * 12 + 8,
        speed: _rng.nextDouble() * 0.15 + 0.05,
        swayAmp: _rng.nextDouble() * 0.04 + 0.01,
        swayFreq: _rng.nextDouble() * 2 + 1,
        rotation: _rng.nextDouble() * pi * 2,
        rotSpeed: (_rng.nextDouble() - 0.5) * 2,
        phase: _rng.nextDouble(),
        colorIndex: _rng.nextInt(4),
      ));
    }
  }

  @override
  void dispose() {
    _particleCtrl.dispose();
    _leafCtrl.dispose();
    _glowCtrl.dispose();
    _fogCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(
          [_particleCtrl, _leafCtrl, _glowCtrl, _fogCtrl]),
      builder: (ctx, _) {
        return Stack(children: [
          // ── Deep forest gradient background ──
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF020802),
                  Color(0xFF081808),
                  Color(0xFF0D1F0D),
                  Color(0xFF091509),
                  Color(0xFF030A03),
                ],
                stops: [0.0, 0.2, 0.4, 0.7, 1.0],
              ),
            ),
          ),

          // ── Radial moonlight glow ──
          Positioned(
            top: -120,
            left: MediaQuery.of(context).size.width * 0.25,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    Color.fromRGBO(100, 200, 80,
                        0.12 + _glowCtrl.value * 0.08),
                    Color.fromRGBO(100, 200, 80,
                        0.06 + _glowCtrl.value * 0.04),
                    Colors.transparent,
                  ],
                  stops: [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          // ── Secondary ambient glow ──
          Positioned(
            bottom: -150,
            right: -100,
            child: Container(
              width: 400,
              height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    Color.fromRGBO(76, 175, 80,
                        0.08 + _glowCtrl.value * 0.05),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── Animated fog layer ──
          Positioned.fill(
            child: CustomPaint(
              painter: _FogPainter(_fogCtrl.value),
            ),
          ),

          // ── Firefly particles ──
          Positioned.fill(
            child: CustomPaint(
              painter: _ParticlePainter(
                _particles,
                _particleCtrl.value,
                _glowCtrl.value,
              ),
            ),
          ),

          // ── Falling leaves ──
          Positioned.fill(
            child: CustomPaint(
              painter: _LeafPainter(
                _leaves,
                _leafCtrl.value,
              ),
            ),
          ),

          // ── Tree silhouettes ──
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: CustomPaint(
              size: Size(MediaQuery.of(context).size.width, 200),
              painter: _TreeSilhouettePainter(),
            ),
          ),

          // ── Vignette overlay ──
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.center,
                  radius: 1.1,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.45),
                    Colors.black.withOpacity(0.65),
                  ],
                  stops: [0.0, 0.7, 1.0],
                ),
              ),
            ),
          ),

          // ── Game content ──
          widget.child,
        ]);
      },
    );
  }
}

// ─────────────────────────────────────────────
//  Particle system — fireflies
// ─────────────────────────────────────────────

class _Particle {
  double x, y, size, speed, opacity, phase;
  int hue;
  _Particle({
    required this.x, required this.y, required this.size,
    required this.speed, required this.opacity, required this.hue,
    required this.phase,
  });
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  final double t, glow;
  static const _colors = [
    Color(0xFF7FD96B), // green firefly
    Color(0xFFFFE066), // golden spark
    Color(0xFF4FC3F7), // blue wisp
  ];

  const _ParticlePainter(this.particles, this.t, this.glow);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final cycle = (t + p.phase) % 1.0;
      final py = (p.y + cycle * p.speed) % 1.0;
      final px = p.x + sin((cycle + p.phase) * pi * 4) * 0.03;
      final flicker = sin((t * 6 + p.phase * 10) * pi) * 0.3 + 0.7;
      final alpha = (p.opacity * flicker).clamp(0.0, 1.0);
      final color = _colors[p.hue].withOpacity(alpha);

      // Glow halo
      final haloPaint = Paint()
        ..color = color.withOpacity(alpha * 0.4)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(
        Offset(px * size.width, py * size.height),
        p.size * 3,
        haloPaint,
      );

      // Core dot
      final dotPaint = Paint()..color = color;
      canvas.drawCircle(
        Offset(px * size.width, py * size.height),
        p.size,
        dotPaint,
      );

      // Inner bright core
      final corePaint = Paint()
        ..color = Colors.white.withOpacity(alpha * 0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
      canvas.drawCircle(
        Offset(px * size.width, py * size.height),
        p.size * 0.5,
        corePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => true;
}

// ─────────────────────────────────────────────
//  Leaf system
// ─────────────────────────────────────────────

class _Leaf {
  double x, startY, size, speed, swayAmp, swayFreq;
  double rotation, rotSpeed, phase;
  int colorIndex;
  _Leaf({
    required this.x, required this.startY, required this.size,
    required this.speed, required this.swayAmp, required this.swayFreq,
    required this.rotation, required this.rotSpeed, required this.phase,
    required this.colorIndex,
  });
}

class _LeafPainter extends CustomPainter {
  final List<_Leaf> leaves;
  final double t;
  static const _colors = [
    Color(0xFF4CAF50),
    Color(0xFF388E3C),
    Color(0xFFA5D6A7),
    Color(0xFF827717),
  ];

  const _LeafPainter(this.leaves, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final l in leaves) {
      final cycle = (t * l.speed + l.phase) % 1.2;
      final py = (l.startY + cycle) * size.height;
      if (py > size.height + l.size) continue;

      final px = l.x * size.width +
          sin((cycle * l.swayFreq + l.phase) * pi * 2) *
              l.swayAmp *
              size.width;
      final rot = l.rotation + cycle * l.rotSpeed * pi * 4;

      canvas.save();
      canvas.translate(px, py);
      canvas.rotate(rot);

      final paint = Paint()
        ..color = _colors[l.colorIndex].withOpacity(0.7)
        ..style = PaintingStyle.fill;

      // Simple leaf shape
      final path = Path()
        ..moveTo(0, -l.size / 2)
        ..cubicTo(l.size / 2, -l.size / 4, l.size / 2, l.size / 4, 0, l.size / 2)
        ..cubicTo(-l.size / 2, l.size / 4, -l.size / 2, -l.size / 4, 0, -l.size / 2)
        ..close();

      canvas.drawPath(path, paint);

      // Leaf vein
      final veinPaint = Paint()
        ..color = _colors[l.colorIndex].withOpacity(0.3)
        ..strokeWidth = 0.5
        ..style = PaintingStyle.stroke;
      canvas.drawLine(Offset(0, -l.size / 2), Offset(0, l.size / 2), veinPaint);

      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_LeafPainter old) => true;
}

// ─────────────────────────────────────────────
//  Fog painter
// ─────────────────────────────────────────────

class _FogPainter extends CustomPainter {
  final double t;
  const _FogPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (int i = 0; i < 3; i++) {
      final offsetX = sin((t + i * 0.33) * pi * 2) * 40;
      final y = size.height * (0.6 + i * 0.1);
      final rect = Rect.fromLTWH(-50 + offsetX, y, size.width + 100, 80);
      paint.shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.transparent,
          const Color(0xFF1A3A1A).withOpacity(0.12 + i * 0.04),
          Colors.transparent,
        ],
      ).createShader(rect);
      canvas.drawRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(_FogPainter old) => true;
}

// ─────────────────────────────────────────────
//  Tree silhouette painter
// ─────────────────────────────────────────────

class _TreeSilhouettePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF020802)
      ..style = PaintingStyle.fill;

    void drawTree(double x, double h, double w) {
      final path = Path()
        ..moveTo(x, size.height)
        ..lineTo(x - w / 2, size.height - h * 0.4)
        ..lineTo(x - w * 0.3, size.height - h * 0.4)
        ..lineTo(x - w * 0.4, size.height - h * 0.7)
        ..lineTo(x - w * 0.2, size.height - h * 0.7)
        ..lineTo(x, size.height - h)
        ..lineTo(x + w * 0.2, size.height - h * 0.7)
        ..lineTo(x + w * 0.4, size.height - h * 0.7)
        ..lineTo(x + w * 0.3, size.height - h * 0.4)
        ..lineTo(x + w / 2, size.height - h * 0.4)
        ..close();
      canvas.drawPath(path, paint);
    }

    drawTree(size.width * 0.08, 180, 60);
    drawTree(size.width * 0.18, 140, 50);
    drawTree(size.width * 0.88, 170, 55);
    drawTree(size.width * 0.96, 130, 45);
    drawTree(size.width * 0.03, 100, 35);
    drawTree(size.width * 0.98, 90, 30);
  }

  @override
  bool shouldRepaint(_TreeSilhouettePainter old) => false;
}
