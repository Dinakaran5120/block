import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../auth/data/auth_repository.dart';

// ─────────────────────────────────────────────
//  CloudSaveService
//  Stores full game state in:
//  /users/{uid}/cloudSaveData (embedded map)
//  + /users/{uid}/save_history/{timestamp} (history)
//
//  Save data includes:
//  - highScore, totalScore, gamesPlayed
//  - selectedTheme, selectedAvatar
//  - coins, unlockedThemes
//  - settings (sfxEnabled, musicEnabled)
//  - lastSaved timestamp
// ─────────────────────────────────────────────

class CloudSaveData {
  final int highScore;
  final int totalScore;
  final int gamesPlayed;
  final int totalLinesCleared;
  final String selectedTheme;
  final String selectedAvatar;
  final int coins;
  final List<String> unlockedThemes;
  final bool sfxEnabled;
  final bool musicEnabled;
  final DateTime savedAt;

  const CloudSaveData({
    required this.highScore,
    required this.totalScore,
    required this.gamesPlayed,
    required this.totalLinesCleared,
    required this.selectedTheme,
    required this.selectedAvatar,
    required this.coins,
    required this.unlockedThemes,
    required this.sfxEnabled,
    required this.musicEnabled,
    required this.savedAt,
  });

  Map<String, dynamic> toMap() => {
        'highScore': highScore,
        'totalScore': totalScore,
        'gamesPlayed': gamesPlayed,
        'totalLinesCleared': totalLinesCleared,
        'selectedTheme': selectedTheme,
        'selectedAvatar': selectedAvatar,
        'coins': coins,
        'unlockedThemes': unlockedThemes,
        'sfxEnabled': sfxEnabled,
        'musicEnabled': musicEnabled,
        'savedAt': Timestamp.fromDate(savedAt),
      };

  factory CloudSaveData.fromMap(Map<String, dynamic> m) => CloudSaveData(
        highScore: (m['highScore'] as num?)?.toInt() ?? 0,
        totalScore: (m['totalScore'] as num?)?.toInt() ?? 0,
        gamesPlayed: (m['gamesPlayed'] as num?)?.toInt() ?? 0,
        totalLinesCleared: (m['totalLinesCleared'] as num?)?.toInt() ?? 0,
        selectedTheme: m['selectedTheme'] ?? 'forest',
        selectedAvatar: m['selectedAvatar'] ?? 'default',
        coins: (m['coins'] as num?)?.toInt() ?? 0,
        unlockedThemes: List<String>.from(m['unlockedThemes'] ?? ['forest']),
        sfxEnabled: m['sfxEnabled'] ?? true,
        musicEnabled: m['musicEnabled'] ?? true,
        savedAt: (m['savedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      );
}

class CloudSaveService {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;

  CloudSaveService({
    required FirebaseFirestore db,
    required AuthRepository authRepo,
  })  : _db = db,
        _authRepo = authRepo;

  DocumentReference<Map<String, dynamic>> _userDoc(String uid) =>
      _db.collection('users').doc(uid);

  // ── Save game state ───────────────────────
  Future<void> saveGame(CloudSaveData data) async {
    final uid = _authRepo.currentUid;
    if (uid == null) return;

    final saveMap = data.toMap();

    // Atomic write: update user doc + append to history
    final batch = _db.batch();

    // 1. Embed in user document
    batch.update(_userDoc(uid), {
      'cloudSaveData': saveMap,
      'lastSeen': FieldValue.serverTimestamp(),
    });

    // 2. History entry (keep last 10 saves)
    final histRef = _userDoc(uid)
        .collection('save_history')
        .doc(DateTime.now().millisecondsSinceEpoch.toString());
    batch.set(histRef, saveMap);

    await batch.commit();

    // Prune old history (keep 10)
    _pruneHistory(uid);
  }

  // ── Load game state ───────────────────────
  Future<CloudSaveData?> loadGame() async {
    final uid = _authRepo.currentUid;
    if (uid == null) return null;

    final snap = await _userDoc(uid).get();
    if (!snap.exists) return null;

    final saveData = snap.data()?['cloudSaveData'] as Map<String, dynamic>?;
    if (saveData == null) return null;

    return CloudSaveData.fromMap(saveData);
  }

  // ── Get save history ──────────────────────
  Future<List<CloudSaveData>> getSaveHistory() async {
    final uid = _authRepo.currentUid;
    if (uid == null) return [];

    final snap = await _userDoc(uid)
        .collection('save_history')
        .orderBy('savedAt', descending: true)
        .limit(10)
        .get();

    return snap.docs
        .map((d) => CloudSaveData.fromMap(d.data()))
        .toList();
  }

  // ── Restore from specific history point ───
  Future<bool> restoreFromHistory(CloudSaveData data) async {
    final uid = _authRepo.currentUid;
    if (uid == null) return false;

    await _userDoc(uid).update({
      'cloudSaveData': data.toMap(),
      'highScore': data.highScore,
      'totalScore': data.totalScore,
      'gamesPlayed': data.gamesPlayed,
      'totalLinesCleared': data.totalLinesCleared,
      'selectedTheme': data.selectedTheme,
      'selectedAvatar': data.selectedAvatar,
      'coins': data.coins,
      'lastSeen': FieldValue.serverTimestamp(),
    });
    return true;
  }

  // ── Auto-save after each game ─────────────
  Future<void> autoSave({
    required UserModel user,
    required bool sfxEnabled,
    required bool musicEnabled,
    List<String> unlockedThemes = const ['forest'],
  }) async {
    await saveGame(CloudSaveData(
      highScore: user.highScore,
      totalScore: user.totalScore,
      gamesPlayed: user.gamesPlayed,
      totalLinesCleared: user.totalLinesCleared,
      selectedTheme: user.selectedTheme,
      selectedAvatar: user.selectedAvatar,
      coins: user.coins,
      unlockedThemes: unlockedThemes,
      sfxEnabled: sfxEnabled,
      musicEnabled: musicEnabled,
      savedAt: DateTime.now(),
    ));
  }

  // ── Prune: keep only latest 10 history entries ──
  Future<void> _pruneHistory(String uid) async {
    try {
      final snap = await _userDoc(uid)
          .collection('save_history')
          .orderBy('savedAt', descending: true)
          .get();

      if (snap.docs.length > 10) {
        final toDelete = snap.docs.sublist(10);
        final batch = _db.batch();
        for (final d in toDelete) {
          batch.delete(d.reference);
        }
        await batch.commit();
      }
    } catch (_) {
      // Non-critical — ignore prune errors
    }
  }
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final cloudSaveServiceProvider = Provider<CloudSaveService>((ref) {
  return CloudSaveService(
    db: FirebaseFirestore.instance,
    authRepo: ref.read(authRepositoryProvider),
  );
});
