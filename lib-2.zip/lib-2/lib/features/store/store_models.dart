// ─────────────────────────────────────────────
//  Store Models — Powerups, Categories, Inventory
//  Redesigned: Avatar system removed, full powerup economy
// ─────────────────────────────────────────────

enum ItemCategory {
  powerup,    // Hammer, Bomb, Lightning, Shuffle, Rainbow, Combo, Freeze
  chest,      // Lucky Chest
  theme,      // Heaven, Beach, Devil, Angel themes
  coins,      // Coin packs
}

enum ItemRarity { common, rare, epic, legendary }

// ─── Powerup type for game integration ────────
enum PowerupType {
  hammer,       // Break one block
  bomb,         // Blast surrounding blocks
  lightning,    // Clear a row or column
  shuffle,      // Rearrange block layout
  rainbow,      // Universal block (matches anything)
  comboBooster, // Temporary score multiplier
  freezeTime,   // Slow gameplay temporarily
  luckyChest,   // Random reward
}

class StoreItem {
  final String id;
  final String name;
  final String description;
  final String emoji;
  final ItemCategory category;
  final ItemRarity rarity;
  final int coinPrice;
  final bool isPremium;
  final String? iapProductId;
  final Map<String, dynamic> metadata;
  final PowerupType? powerupType;
  final int? quantity; // how many granted per purchase

  const StoreItem({
    required this.id,
    required this.name,
    required this.description,
    required this.emoji,
    required this.category,
    required this.rarity,
    required this.coinPrice,
    this.isPremium = false,
    this.iapProductId,
    this.metadata = const {},
    this.powerupType,
    this.quantity,
  });
}

// ─────────────────────────────────────────────
//  Full store catalog
// ─────────────────────────────────────────────

const List<StoreItem> storeCatalog = [

  // ── Powerups ─────────────────────────────────

  StoreItem(
    id: 'powerup_hammer',
    name: 'Hammer',
    description: 'Break difficult blocks and create space.',
    emoji: '🔨',
    category: ItemCategory.powerup,
    rarity: ItemRarity.common,
    coinPrice: 150,
    powerupType: PowerupType.hammer,
    quantity: 1,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_hammer_x3',
    name: 'Hammer ×3',
    description: 'Break difficult blocks and create space.',
    emoji: '🔨',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 400,
    powerupType: PowerupType.hammer,
    quantity: 3,
    metadata: {'count': 3},
  ),
  StoreItem(
    id: 'powerup_bomb',
    name: 'Bomb',
    description: 'Clear crowded areas instantly.',
    emoji: '💣',
    category: ItemCategory.powerup,
    rarity: ItemRarity.common,
    coinPrice: 150,
    powerupType: PowerupType.bomb,
    quantity: 1,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_bomb_x5',
    name: 'Bomb ×5',
    description: 'Five explosive blasts ready to go.',
    emoji: '💥',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 600,
    powerupType: PowerupType.bomb,
    quantity: 5,
    metadata: {'count': 5},
  ),
  StoreItem(
    id: 'powerup_lightning',
    name: 'Lightning',
    description: 'Strike through obstacles instantly.',
    emoji: '⚡',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 200,
    powerupType: PowerupType.lightning,
    quantity: 1,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_shuffle',
    name: 'Shuffle',
    description: 'Get a better chance with a new layout.',
    emoji: '🔀',
    category: ItemCategory.powerup,
    rarity: ItemRarity.common,
    coinPrice: 100,
    powerupType: PowerupType.shuffle,
    quantity: 1,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_rainbow',
    name: 'Rainbow Block',
    description: 'Matches anything — universal wildcard.',
    emoji: '🌈',
    category: ItemCategory.powerup,
    rarity: ItemRarity.epic,
    coinPrice: 300,
    powerupType: PowerupType.rainbow,
    quantity: 1,
    metadata: {'count': 1},
  ),
  StoreItem(
    id: 'powerup_combo',
    name: 'Combo Booster',
    description: 'Boost your score with a multiplier.',
    emoji: '⭐',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 250,
    powerupType: PowerupType.comboBooster,
    quantity: 1,
    metadata: {'count': 1, 'multiplier': 2},
  ),
  StoreItem(
    id: 'powerup_freeze',
    name: 'Freeze Time',
    description: 'Think before your move — time slows.',
    emoji: '❄️',
    category: ItemCategory.powerup,
    rarity: ItemRarity.rare,
    coinPrice: 200,
    powerupType: PowerupType.freezeTime,
    quantity: 1,
    metadata: {'count': 1, 'durationSec': 10},
  ),

  // ── Lucky Chest ──────────────────────────────

  StoreItem(
    id: 'chest_lucky',
    name: 'Lucky Chest',
    description: 'Random reward — coins, powerups & more!',
    emoji: '📦',
    category: ItemCategory.chest,
    rarity: ItemRarity.epic,
    coinPrice: 500,
    metadata: {'type': 'lucky'},
  ),
  StoreItem(
    id: 'chest_premium',
    name: 'Premium Chest',
    description: 'Rare guaranteed rewards inside.',
    emoji: '💎',
    category: ItemCategory.chest,
    rarity: ItemRarity.legendary,
    coinPrice: 1200,
    metadata: {'type': 'premium'},
  ),

  // ── Themes ───────────────────────────────────

  StoreItem(
    id: 'theme_beach',
    name: 'Sunset Beach',
    description: 'Neon ocean vibes at sunset.',
    emoji: '🏖️',
    category: ItemCategory.theme,
    rarity: ItemRarity.rare,
    coinPrice: 2000,
    metadata: {'themeId': 'beach'},
  ),
  StoreItem(
    id: 'theme_devil',
    name: 'Inferno Realm',
    description: 'Hellfire, lava and chaos.',
    emoji: '😈',
    category: ItemCategory.theme,
    rarity: ItemRarity.epic,
    coinPrice: 3500,
    metadata: {'themeId': 'devil'},
  ),
  StoreItem(
    id: 'theme_angel',
    name: 'Celestial Heaven',
    description: 'Divine clouds and golden light.',
    emoji: '😇',
    category: ItemCategory.theme,
    rarity: ItemRarity.legendary,
    coinPrice: 4000,
    metadata: {'themeId': 'angel'},
  ),

  // ── Coin Packs ───────────────────────────────

  StoreItem(
    id: 'coins_small',
    name: '500 Coins',
    description: 'Quick top-up for your wallet.',
    emoji: '🪙',
    category: ItemCategory.coins,
    rarity: ItemRarity.common,
    coinPrice: 0,
    isPremium: true,
    iapProductId: 'coins_500',
    metadata: {'coins': 500},
  ),
  StoreItem(
    id: 'coins_medium',
    name: '1,500 Coins',
    description: 'Best value for regular players.',
    emoji: '💰',
    category: ItemCategory.coins,
    rarity: ItemRarity.rare,
    coinPrice: 0,
    isPremium: true,
    iapProductId: 'coins_1500',
    metadata: {'coins': 1500},
  ),
  StoreItem(
    id: 'coins_large',
    name: '5,000 Coins',
    description: 'Power player\'s treasury.',
    emoji: '🏆',
    category: ItemCategory.coins,
    rarity: ItemRarity.legendary,
    coinPrice: 0,
    isPremium: true,
    iapProductId: 'coins_5000',
    metadata: {'coins': 5000},
  ),
];

// ─────────────────────────────────────────────
//  Inventory — what user owns
// ─────────────────────────────────────────────

class Inventory {
  final Set<String> ownedItems;
  final Set<String> unlockedThemes;

  // Powerup counts
  final int hammers;
  final int bombs;
  final int lightnings;
  final int shuffles;
  final int rainbows;
  final int comboBoosters;
  final int freezes;

  const Inventory({
    this.ownedItems = const {},
    this.unlockedThemes = const {'forest'},
    this.hammers = 0,
    this.bombs = 0,
    this.lightnings = 0,
    this.shuffles = 0,
    this.rainbows = 0,
    this.comboBoosters = 0,
    this.freezes = 0,
  });

  bool owns(String itemId) => ownedItems.contains(itemId);

  int countForPowerup(PowerupType type) => switch (type) {
        PowerupType.hammer => hammers,
        PowerupType.bomb => bombs,
        PowerupType.lightning => lightnings,
        PowerupType.shuffle => shuffles,
        PowerupType.rainbow => rainbows,
        PowerupType.comboBooster => comboBoosters,
        PowerupType.freezeTime => freezes,
        _ => 0,
      };

  int get totalPowerups =>
      hammers + bombs + lightnings + shuffles + rainbows + comboBoosters + freezes;

  Inventory copyWith({
    Set<String>? ownedItems,
    Set<String>? unlockedThemes,
    int? hammers,
    int? bombs,
    int? lightnings,
    int? shuffles,
    int? rainbows,
    int? comboBoosters,
    int? freezes,
  }) =>
      Inventory(
        ownedItems: ownedItems ?? this.ownedItems,
        unlockedThemes: unlockedThemes ?? this.unlockedThemes,
        hammers: hammers ?? this.hammers,
        bombs: bombs ?? this.bombs,
        lightnings: lightnings ?? this.lightnings,
        shuffles: shuffles ?? this.shuffles,
        rainbows: rainbows ?? this.rainbows,
        comboBoosters: comboBoosters ?? this.comboBoosters,
        freezes: freezes ?? this.freezes,
      );

  Map<String, dynamic> toMap() => {
        'ownedItems': ownedItems.toList(),
        'unlockedThemes': unlockedThemes.toList(),
        'hammers': hammers,
        'bombs': bombs,
        'lightnings': lightnings,
        'shuffles': shuffles,
        'rainbows': rainbows,
        'comboBoosters': comboBoosters,
        'freezes': freezes,
      };

  factory Inventory.fromMap(Map<String, dynamic> m) => Inventory(
        ownedItems: Set<String>.from(m['ownedItems'] ?? []),
        unlockedThemes: Set<String>.from(m['unlockedThemes'] ?? ['forest']),
        hammers: (m['hammers'] as num?)?.toInt() ?? 0,
        bombs: (m['bombs'] as num?)?.toInt() ?? 0,
        lightnings: (m['lightnings'] as num?)?.toInt() ?? 0,
        shuffles: (m['shuffles'] as num?)?.toInt() ?? 0,
        rainbows: (m['rainbows'] as num?)?.toInt() ?? 0,
        comboBoosters: (m['comboBoosters'] as num?)?.toInt() ?? 0,
        freezes: (m['freezes'] as num?)?.toInt() ?? 0,
      );

  static Inventory get empty => const Inventory(unlockedThemes: {'forest'});
}

// ─────────────────────────────────────────────
//  Rarity styles
// ─────────────────────────────────────────────

extension RarityStyle on ItemRarity {
  String get label => switch (this) {
        ItemRarity.common => 'Common',
        ItemRarity.rare => 'Rare',
        ItemRarity.epic => 'Epic',
        ItemRarity.legendary => 'Legendary',
      };

  List<int> get colors => switch (this) {
        ItemRarity.common => [0xFF9E9E9E, 0xFF757575],
        ItemRarity.rare => [0xFF2196F3, 0xFF1565C0],
        ItemRarity.epic => [0xFF9C27B0, 0xFF6A1B9A],
        ItemRarity.legendary => [0xFFFF9800, 0xFFE65100],
      };
}

// ─────────────────────────────────────────────
//  Purchase Result
// ─────────────────────────────────────────────

enum PurchaseStatus { success, insufficientCoins, alreadyOwned, error }

class PurchaseResult {
  final PurchaseStatus status;
  final StoreItem? item;
  final int? coinsNeeded;
  final String? errorMessage;

  const PurchaseResult._({
    required this.status,
    this.item,
    this.coinsNeeded,
    this.errorMessage,
  });

  factory PurchaseResult.success(StoreItem item) =>
      PurchaseResult._(status: PurchaseStatus.success, item: item);
  factory PurchaseResult.insufficient(int needed) =>
      PurchaseResult._(status: PurchaseStatus.insufficientCoins, coinsNeeded: needed);
  factory PurchaseResult.alreadyOwned() =>
      const PurchaseResult._(status: PurchaseStatus.alreadyOwned);
  factory PurchaseResult.error(String msg) =>
      PurchaseResult._(status: PurchaseStatus.error, errorMessage: msg);

  bool get isSuccess => status == PurchaseStatus.success;

  String get message => switch (status) {
        PurchaseStatus.success => '${item?.name} added!',
        PurchaseStatus.insufficientCoins => 'Need ${coinsNeeded ?? 0} more coins',
        PurchaseStatus.alreadyOwned => 'Already owned',
        PurchaseStatus.error => errorMessage ?? 'Purchase failed',
      };
}

// ─────────────────────────────────────────────
//  Lucky Chest Reward
// ─────────────────────────────────────────────

class ChestReward {
  final String label;
  final String emoji;
  final int? coins;
  final PowerupType? powerup;
  final int powerupCount;

  const ChestReward({
    required this.label,
    required this.emoji,
    this.coins,
    this.powerup,
    this.powerupCount = 1,
  });
}

const List<ChestReward> luckyChestRewards = [
  ChestReward(label: '+100 Coins', emoji: '🪙', coins: 100),
  ChestReward(label: '+250 Coins', emoji: '💰', coins: 250),
  ChestReward(label: '+500 Coins', emoji: '💎', coins: 500),
  ChestReward(label: 'Hammer', emoji: '🔨', powerup: PowerupType.hammer),
  ChestReward(label: 'Bomb', emoji: '💣', powerup: PowerupType.bomb),
  ChestReward(label: 'Lightning', emoji: '⚡', powerup: PowerupType.lightning),
  ChestReward(label: '3× Bombs', emoji: '💥', powerup: PowerupType.bomb, powerupCount: 3),
  ChestReward(label: 'Rainbow', emoji: '🌈', powerup: PowerupType.rainbow),
];

// ─────────────────────────────────────────────
//  Store State
// ─────────────────────────────────────────────

class StoreState {
  final Inventory inventory;
  final bool isLoading;
  final String? message;
  final ItemCategory selectedCategory;

  const StoreState({
    this.inventory = const Inventory(),
    this.isLoading = false,
    this.message,
    this.selectedCategory = ItemCategory.powerup,
  });

  StoreState copyWith({
    Inventory? inventory,
    bool? isLoading,
    String? message,
    ItemCategory? selectedCategory,
  }) =>
      StoreState(
        inventory: inventory ?? this.inventory,
        isLoading: isLoading ?? this.isLoading,
        message: message,
        selectedCategory: selectedCategory ?? this.selectedCategory,
      );

  List<StoreItem> get filteredItems =>
      storeCatalog.where((i) => i.category == selectedCategory).toList();
}
