import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'components/game_grid.dart';
import 'components/theme_backgrounds.dart';
import '../../core/theme/game_theme.dart';
import '../../core/services/sound_manager.dart';
import '../spin_wheel/spin_wheel_screen.dart';
import '../leaderboard/presentation/leaderboard_screen.dart';
import '../store/store_screen.dart';
import '../store/store_models.dart';
import '../store/store_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../daily_reward/presentation/daily_reward_screen.dart';

// ─────────────────────────────────────────────
//  Game Screen — Sunset Beach (default)
// ─────────────────────────────────────────────

class GameScreen extends ConsumerStatefulWidget {
  const GameScreen({super.key});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  GameThemeData _theme = beachTheme;

  // Game state (wire these to your actual GameGrid controller)
  int _currentScore = 0;
  bool _gameOver = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _startAmbient();
  }

  Future<void> _startAmbient() async {
    final sound = ref.read(soundManagerProvider);
    await sound.preload();
    await sound.playMusic(_theme.ambientSound);
  }

  void _onThemeChanged(GameThemeData theme) {
    if (theme.type == _theme.type) return;
    setState(() => _theme = theme);
    ref.read(soundManagerProvider).playMusic(theme.ambientSound);
  }

  Widget _themedBackground({required Widget child}) {
    return switch (_theme.type) {
      GameThemeType.beach  => BeachBackground(child: child),
      GameThemeType.devil  => DevilBackground(child: child),
      GameThemeType.angel  => AngelBackground(child: child),
      GameThemeType.forest => BeachBackground(child: child),
    };
  }

  // ── Called by GameGrid when game ends ──
  void _onGameOver(int score) {
    setState(() {
      _currentScore = score;
      _gameOver = true;
    });
    final inventory = ref.read(inventoryProvider).value;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => GameOverReviveDialog(
        theme: _theme,
        score: score,
        inventory: inventory,
        onReviveAd: _handleReviveAd,
        onReviveHammer: _handleReviveHammer,
        onReviveBomb: _handleReviveBomb,
        onRestart: _handleRestart,
      ),
    );
  }

  void _handleReviveAd() {
    Navigator.pop(context);
    // Wire your AdMob rewarded ad here, e.g.:
    //   AdMobService.instance.showRewardedAd(onRewarded: () { ... revive ... });
    // Reviving directly until AdMob is integrated:
    setState(() => _gameOver = false);
    // TODO: call gameGridKey.currentState?.revive()
  }

  void _handleReviveHammer() {
    Navigator.pop(context);
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.hammer, inv);
    }
    setState(() => _gameOver = false);
    // TODO: call gameGridKey.currentState?.revive()
  }

  void _handleReviveBomb() {
    Navigator.pop(context);
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.bomb, inv);
    }
    setState(() => _gameOver = false);
    // TODO: call gameGridKey.currentState?.revive()
  }

  void _handleRestart() {
    Navigator.pop(context);
    setState(() {
      _gameOver = false;
      _currentScore = 0;
    });
    // TODO: call gameGridKey.currentState?.restart()
  }

  // ── Powerup HUD actions ──
  void _useHammer() {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.hammers <= 0) {
      _showNoPowerupSnack('🔨 No hammers left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv = ref.read(inventoryProvider).value;
    if (uid != null && inv != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.hammer, inv);
    }
    // TODO: call gameGridKey.currentState?.activateHammer()
    HapticFeedback.mediumImpact();
  }

  void _useBomb() {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.bombs <= 0) {
      _showNoPowerupSnack('💣 No bombs left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv2 = ref.read(inventoryProvider).value;
    if (uid != null && inv2 != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.bomb, inv2);
    }
    // TODO: call gameGridKey.currentState?.activateBomb()
    HapticFeedback.mediumImpact();
  }

  void _useLightning() {
    final inventory = ref.read(inventoryProvider).value;
    if (inventory == null || inventory.lightnings <= 0) {
      _showNoPowerupSnack('⚡ No lightning left! Buy more in the Store.');
      return;
    }
    final uid = ref.read(authNotifierProvider).user?.uid;
    final inv3 = ref.read(inventoryProvider).value;
    if (uid != null && inv3 != null) {
      ref.read(storeRepositoryProvider).usePowerup(uid, PowerupType.lightning, inv3);
    }
    // TODO: call gameGridKey.currentState?.activateLightning()
    HapticFeedback.mediumImpact();
  }

  void _showNoPowerupSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: _theme.colors.panelBg,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inventory = ref.watch(inventoryProvider).value;

    return Scaffold(
      backgroundColor: Colors.black,
      body: _themedBackground(
        child: SafeArea(
          child: Column(
            children: [
              _TopHUD(
                theme: _theme,
                onThemeChanged: _onThemeChanged,
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: GameGrid(
                  theme: _theme,
                  // Wire game-over callback when your GameGrid supports it:
                  // onGameOver: _onGameOver,
                ),
              ),
              const Spacer(),
              // ── Powerup HUD ──
              _PowerupHUD(
                theme: _theme,
                inventory: inventory,
                onHammer: _useHammer,
                onBomb: _useBomb,
                onLightning: _useLightning,
              ),
              const SizedBox(height: 8),
              _FeatureNavBar(theme: _theme, themedBackground: _themedBackground),
              const SizedBox(height: 4),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Powerup HUD  (hammer / bomb / lightning)
// ─────────────────────────────────────────────

class _PowerupHUD extends StatelessWidget {
  final GameThemeData theme;
  final Inventory? inventory;
  final VoidCallback onHammer;
  final VoidCallback onBomb;
  final VoidCallback onLightning;

  const _PowerupHUD({
    required this.theme,
    required this.inventory,
    required this.onHammer,
    required this.onBomb,
    required this.onLightning,
  });

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        decoration: BoxDecoration(
          color: colors.panelBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: colors.panelBorder.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.08),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _PowerupButton(
              emoji: '🔨',
              label: 'Hammer',
              count: inventory?.hammers ?? 0,
              colors: colors,
              onTap: onHammer,
            ),
            _PowerupDivider(colors: colors),
            _PowerupButton(
              emoji: '💣',
              label: 'Bomb',
              count: inventory?.bombs ?? 0,
              colors: colors,
              onTap: onBomb,
            ),
            _PowerupDivider(colors: colors),
            _PowerupButton(
              emoji: '⚡',
              label: 'Lightning',
              count: inventory?.lightnings ?? 0,
              colors: colors,
              onTap: onLightning,
            ),
          ],
        ),
      ),
    );
  }
}

class _PowerupDivider extends StatelessWidget {
  final GameThemeColors colors;
  const _PowerupDivider({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 36,
      color: colors.panelBorder.withOpacity(0.25),
    );
  }
}

class _PowerupButton extends StatefulWidget {
  final String emoji;
  final String label;
  final int count;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _PowerupButton({
    required this.emoji,
    required this.label,
    required this.count,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_PowerupButton> createState() => _PowerupButtonState();
}

class _PowerupButtonState extends State<_PowerupButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hasStock = widget.count > 0;
    final colors = widget.colors;

    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: SizedBox(
            width: 80,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: hasStock
                            ? colors.glowColor.withOpacity(0.15)
                            : colors.panelBorder.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: hasStock
                              ? colors.glowColor.withOpacity(0.4)
                              : colors.panelBorder.withOpacity(0.2),
                          width: 1.5,
                        ),
                        boxShadow: hasStock
                            ? [
                                BoxShadow(
                                  color: colors.glowColor.withOpacity(0.2),
                                  blurRadius: 8,
                                ),
                              ]
                            : null,
                      ),
                      child: Center(
                        child: Opacity(
                          opacity: hasStock ? 1.0 : 0.35,
                          child: Text(
                            widget.emoji,
                            style: const TextStyle(fontSize: 24),
                          ),
                        ),
                      ),
                    ),
                    // Count badge
                    Positioned(
                      top: -6,
                      right: -6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(
                          color: hasStock
                              ? colors.glowColor
                              : colors.panelBorder.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: colors.panelBg,
                            width: 1.5,
                          ),
                        ),
                        child: Text(
                          '×${widget.count}',
                          style: TextStyle(
                            color: hasStock ? Colors.white : colors.textPrimary.withOpacity(0.5),
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  widget.label,
                  style: TextStyle(
                    color: hasStock
                        ? colors.textPrimary.withOpacity(0.8)
                        : colors.textPrimary.withOpacity(0.35),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Game Over Revive Dialog  (exported for reuse)
// ─────────────────────────────────────────────

class GameOverReviveDialog extends StatefulWidget {
  final GameThemeData theme;
  final int score;
  final Inventory? inventory;
  final VoidCallback onReviveAd;
  final VoidCallback onReviveHammer;
  final VoidCallback onReviveBomb;
  final VoidCallback onRestart;

  const GameOverReviveDialog({
    super.key,
    required this.theme,
    required this.score,
    this.inventory,
    required this.onReviveAd,
    required this.onReviveHammer,
    required this.onReviveBomb,
    required this.onRestart,
  });

  @override
  State<GameOverReviveDialog> createState() => _GameOverReviveDialogState();
}

class _GameOverReviveDialogState extends State<GameOverReviveDialog>
    with TickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<double> _scaleAnim;
  late AnimationController _countdownController;
  int _countdown = 5;
  Timer? _countdownTimer;

  @override
  void initState() {
    super.initState();
    // Entry elastic animation
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleAnim = CurvedAnimation(
      parent: _entryController,
      curve: Curves.elasticOut,
    );
    _entryController.forward();

    // Countdown to auto-dismiss
    _countdownController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _countdownController.forward();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _countdown--);
      if (_countdown <= 0) {
        t.cancel();
        widget.onRestart();
      }
    });
  }

  @override
  void dispose() {
    _entryController.dispose();
    _countdownController.dispose();
    _countdownTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.theme.colors;
    final inv = widget.inventory;
    final hasHammer = (inv?.hammers ?? 0) > 0;
    final hasBomb = (inv?.bombs ?? 0) > 0;

    return Dialog(
      backgroundColor: Colors.transparent,
      child: ScaleTransition(
        scale: _scaleAnim,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors.panelBg,
                colors.panelBg.withOpacity(0.9),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: colors.panelBorder.withOpacity(0.6),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: colors.glowColor.withOpacity(0.3),
                blurRadius: 40,
                spreadRadius: 4,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Game Over header
              Text(
                'Game Over',
                style: TextStyle(
                  color: colors.textPrimary,
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Score: ${widget.score}',
                style: TextStyle(
                  color: colors.textAccent,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 20),

              // Countdown ring
              _CountdownRing(
                countdown: _countdown,
                colors: colors,
                controller: _countdownController,
              ),
              const SizedBox(height: 6),
              Text(
                'Continue?',
                style: TextStyle(
                  color: colors.textPrimary.withOpacity(0.6),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 24),

              // Watch Ad — always available
              _ReviveButton(
                icon: Icons.play_circle_fill_rounded,
                emoji: null,
                label: 'Watch Ad to Revive',
                sublabel: 'FREE  •  Continue where you left off',
                colors: colors,
                isPrimary: true,
                onTap: widget.onReviveAd,
              ),
              const SizedBox(height: 10),

              // Hammer — only if owned
              if (hasHammer) ...[
                _ReviveButton(
                  icon: null,
                  emoji: '🔨',
                  label: 'Use Hammer  ×${inv!.hammers}',
                  sublabel: 'Clear a block and revive',
                  colors: colors,
                  isPrimary: false,
                  onTap: widget.onReviveHammer,
                ),
                const SizedBox(height: 10),
              ],

              // Bomb — only if owned
              if (hasBomb) ...[
                _ReviveButton(
                  icon: null,
                  emoji: '💣',
                  label: 'Use Bomb  ×${inv!.bombs}',
                  sublabel: 'Blast an area and revive',
                  colors: colors,
                  isPrimary: false,
                  onTap: widget.onReviveBomb,
                ),
                const SizedBox(height: 10),
              ],

              // Divider
              Divider(color: colors.panelBorder.withOpacity(0.3), height: 24),

              // Restart
              GestureDetector(
                onTap: widget.onRestart,
                child: Text(
                  'Restart',
                  style: TextStyle(
                    color: colors.textPrimary.withOpacity(0.45),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                    decorationColor: colors.textPrimary.withOpacity(0.25),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountdownRing extends StatelessWidget {
  final int countdown;
  final GameThemeColors colors;
  final AnimationController controller;

  const _CountdownRing({
    required this.countdown,
    required this.colors,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 64,
      height: 64,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: controller,
            builder: (_, __) => CircularProgressIndicator(
              value: 1.0 - controller.value,
              strokeWidth: 4,
              backgroundColor: colors.panelBorder.withOpacity(0.2),
              valueColor: AlwaysStoppedAnimation(colors.glowColor),
            ),
          ),
          Text(
            '$countdown',
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviveButton extends StatefulWidget {
  final IconData? icon;
  final String? emoji;
  final String label;
  final String sublabel;
  final GameThemeColors colors;
  final bool isPrimary;
  final VoidCallback onTap;

  const _ReviveButton({
    required this.icon,
    required this.emoji,
    required this.label,
    required this.sublabel,
    required this.colors,
    required this.isPrimary,
    required this.onTap,
  });

  @override
  State<_ReviveButton> createState() => _ReviveButtonState();
}

class _ReviveButtonState extends State<_ReviveButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _s;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 130));
    _s = Tween(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.colors;
    return GestureDetector(
      onTapDown: (_) => _c.forward(),
      onTapUp: (_) {
        _c.reverse();
        widget.onTap();
      },
      onTapCancel: () => _c.reverse(),
      child: AnimatedBuilder(
        animation: _s,
        builder: (_, __) => Transform.scale(
          scale: _s.value,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            decoration: BoxDecoration(
              gradient: widget.isPrimary
                  ? LinearGradient(
                      colors: [
                        c.buttonPrimary,
                        c.buttonSecondary,
                      ],
                    )
                  : null,
              color: widget.isPrimary ? null : c.panelBorder.withOpacity(0.15),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: widget.isPrimary
                    ? c.glowColor.withOpacity(0.5)
                    : c.panelBorder.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: widget.isPrimary
                  ? [
                      BoxShadow(
                        color: c.glowColor.withOpacity(0.3),
                        blurRadius: 14,
                        offset: const Offset(0, 4),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                if (widget.emoji != null)
                  Text(widget.emoji!, style: const TextStyle(fontSize: 22))
                else if (widget.icon != null)
                  Icon(widget.icon!, color: Colors.white, size: 24),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.label,
                        style: TextStyle(
                          color: widget.isPrimary
                              ? Colors.white
                              : c.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        widget.sublabel,
                        style: TextStyle(
                          color: widget.isPrimary
                              ? Colors.white.withOpacity(0.75)
                              : c.textPrimary.withOpacity(0.5),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Top HUD
// ─────────────────────────────────────────────

class _TopHUD extends StatelessWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;
  const _TopHUD({required this.theme, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    final colors    = theme.colors;
    final canGoBack = Navigator.canPop(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Left: optional back button + theme name pill
          Row(
            children: [
              if (canGoBack) ...[
                _HudButton(
                  icon: Icons.arrow_back_ios_new_rounded,
                  colors: colors,
                  onTap: () => Navigator.of(context).pop(),
                ),
                const SizedBox(width: 8),
              ],
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: colors.panelBg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: colors.panelBorder.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: colors.glowColor,
                        boxShadow: [
                          BoxShadow(color: colors.glowColor, blurRadius: 4),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      theme.name,
                      style: TextStyle(
                        color: colors.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          // Right: settings
          _HudButton(
            icon: Icons.settings_outlined,
            colors: colors,
            onTap: () => _showSettings(context),
          ),
        ],
      ),
    );
  }

  void _showSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _SettingsSheet(
        theme: theme,
        onThemeChanged: onThemeChanged,
      ),
    );
  }
}

class _HudButton extends StatelessWidget {
  final IconData icon;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _HudButton({
    required this.icon,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: colors.panelBg,
          shape: BoxShape.circle,
          border: Border.all(
            color: colors.panelBorder.withOpacity(0.4),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.1),
              blurRadius: 8,
            ),
          ],
        ),
        child: Icon(icon, color: colors.textPrimary, size: 20),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Feature navigation (spin, leaderboard, store, rewards)
// ─────────────────────────────────────────────

class _FeatureNavBar extends StatelessWidget {
  final GameThemeData theme;
  final Widget Function({required Widget child}) themedBackground;

  const _FeatureNavBar({
    required this.theme,
    required this.themedBackground,
  });

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => themedBackground(child: screen)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = theme.colors;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: colors.panelBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: colors.panelBorder.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.08),
              blurRadius: 12,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _NavItem(
              icon: Icons.casino_outlined,
              label: 'Spin',
              colors: colors,
              onTap: () => _open(context, SpinWheelScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.leaderboard_outlined,
              label: 'Ranks',
              colors: colors,
              onTap: () => _open(context, LeaderboardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.card_giftcard_outlined,
              label: 'Daily',
              colors: colors,
              onTap: () => _open(context, DailyRewardScreen(theme: theme)),
            ),
            _NavItem(
              icon: Icons.storefront_outlined,
              label: 'Store',
              colors: colors,
              onTap: () => _open(context, StoreScreen(theme: theme)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: colors.textAccent, size: 26),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: colors.textPrimary.withOpacity(0.75),
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Settings Sheet
// ─────────────────────────────────────────────

class _SettingsSheet extends ConsumerStatefulWidget {
  final GameThemeData theme;
  final ValueChanged<GameThemeData> onThemeChanged;
  const _SettingsSheet({required this.theme, required this.onThemeChanged});

  @override
  ConsumerState<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends ConsumerState<_SettingsSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _sheetController;
  late Animation<double> _fadeAnimation;
  bool _showShareOptions = false;

  @override
  void initState() {
    super.initState();
    _sheetController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _sheetController,
      curve: Curves.easeOut,
    );
    _sheetController.forward();
  }

  @override
  void dispose() {
    _sheetController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.theme.colors;
    final sound = ref.read(soundManagerProvider);
    final screenHeight = MediaQuery.of(context).size.height;

    return AnimatedBuilder(
      animation: _fadeAnimation,
      builder: (_, __) => FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.1),
            end: Offset.zero,
          ).animate(_fadeAnimation),
          child: Container(
            constraints: BoxConstraints(
              maxHeight: screenHeight * 0.85,
            ),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colors.panelBg,
                  colors.panelBg.withOpacity(0.85),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: colors.panelBorder.withOpacity(0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: colors.glowColor.withOpacity(0.25),
                  blurRadius: 35,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                  spreadRadius: -5,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                  spreadRadius: -2,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                colors.buttonPrimary.withOpacity(0.2),
                                colors.buttonSecondary.withOpacity(0.15),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: colors.glowColor.withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Icon(
                            Icons.settings_rounded,
                            color: colors.textAccent,
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Settings',
                                style: TextStyle(
                                  color: colors.textPrimary,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              Text(
                                'Customize your experience',
                                style: TextStyle(
                                  color: colors.textPrimary.withOpacity(0.5),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: colors.panelBorder.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.close_rounded,
                              color: colors.textPrimary.withOpacity(0.6),
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Sound Settings
                    _SettingsSection(
                      title: 'Audio',
                      icon: Icons.volume_up_rounded,
                      colors: colors,
                      children: [
                        _SettingsRow(
                          label: 'Music',
                          icon: Icons.music_note_outlined,
                          value: sound.musicEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleMusic(),
                        ),
                        const SizedBox(height: 12),
                        _SettingsRow(
                          label: 'Sound Effects',
                          icon: Icons.volume_up_outlined,
                          value: sound.sfxEnabled,
                          colors: colors,
                          onChanged: (_) => sound.toggleSfx(),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Theme Section
                    _SettingsSection(
                      title: 'Theme',
                      icon: Icons.palette_rounded,
                      colors: colors,
                      children: [
                        _ThemeChips(
                          currentTheme: widget.theme,
                          colors: colors,
                          onThemeSelected: (t) {
                            widget.onThemeChanged(t);
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Additional Options
                    _SettingsSection(
                      title: 'More',
                      icon: Icons.more_horiz_rounded,
                      colors: colors,
                      children: [
                        _SettingsButton(
                          icon: Icons.description_outlined,
                          label: 'Terms & Conditions',
                          colors: colors,
                          onTap: () {},
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.privacy_tip_outlined,
                          label: 'Privacy Policy',
                          colors: colors,
                          onTap: () {},
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.contact_mail_outlined,
                          label: 'Contact Us',
                          colors: colors,
                          onTap: () => _showContactDialog(context, colors),
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.share_outlined,
                          label: 'Share with Friends',
                          colors: colors,
                          onTap: () => setState(() => _showShareOptions = !_showShareOptions),
                        ),
                        if (_showShareOptions) ...[
                          const SizedBox(height: 12),
                          _ShareOptions(colors: colors),
                        ],
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.star_rate_outlined,
                          label: 'Rate App',
                          colors: colors,
                          onTap: () {},
                        ),
                        const SizedBox(height: 8),
                        _SettingsButton(
                          icon: Icons.restore_outlined,
                          label: 'Restore Purchases',
                          colors: colors,
                          onTap: () {},
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showContactDialog(BuildContext context, GameThemeColors colors) {
    showDialog(
      context: context,
      builder: (_) => _ContactDialog(colors: colors),
    );
  }
}

// ─────────────────────────────────────────────
//  Settings Section Widget
// ─────────────────────────────────────────────

class _SettingsSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final GameThemeColors colors;
  final List<Widget> children;

  const _SettingsSection({
    required this.title,
    required this.icon,
    required this.colors,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: colors.textAccent, size: 18),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: colors.textPrimary.withOpacity(0.6),
                fontSize: 13,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors.panelBorder.withOpacity(0.15),
                colors.panelBorder.withOpacity(0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: colors.panelBorder.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  Settings Button Widget
// ─────────────────────────────────────────────

class _SettingsButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SettingsButton({
    required this.icon,
    required this.label,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SettingsButton> createState() => _SettingsButtonState();
}

class _SettingsButtonState extends State<_SettingsButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: widget.colors.panelBorder.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: widget.colors.panelBorder.withOpacity(0.25),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    widget.icon,
                    color: widget.colors.textAccent,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    widget.label,
                    style: TextStyle(
                      color: widget.colors.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: widget.colors.textPrimary.withOpacity(0.4),
                  size: 22,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Share Options Widget
// ─────────────────────────────────────────────

class _ShareOptions extends StatefulWidget {
  final GameThemeColors colors;
  const _ShareOptions({required this.colors});

  @override
  State<_ShareOptions> createState() => _ShareOptionsState();
}

class _ShareOptionsState extends State<_ShareOptions>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, -0.2),
          end: Offset.zero,
        ).animate(_fade),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                widget.colors.buttonPrimary.withOpacity(0.15),
                widget.colors.buttonSecondary.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: widget.colors.glowColor.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Share via',
                style: TextStyle(
                  color: widget.colors.textPrimary.withOpacity(0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _SocialButton(
                    icon: Icons.message_rounded,
                    label: 'WhatsApp',
                    color: const Color(0xFF25D366),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.camera_alt_rounded,
                    label: 'Instagram',
                    color: const Color(0xFFE4405F),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                  _SocialButton(
                    icon: Icons.facebook_rounded,
                    label: 'Facebook',
                    color: const Color(0xFF1877F2),
                    colors: widget.colors,
                    onTap: () {},
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SocialButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _SocialButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
    );
    _scale = Tween(begin: 1.0, end: 0.9).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Column(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: widget.color.withOpacity(0.4),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Icon(
                  widget.icon,
                  color: Colors.white,
                  size: 26,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.colors.textPrimary.withOpacity(0.7),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  Contact Dialog Widget
// ─────────────────────────────────────────────

class _ContactDialog extends StatelessWidget {
  final GameThemeColors colors;
  const _ContactDialog({required this.colors});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 32),
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              colors.panelBg,
              colors.panelBg.withOpacity(0.85),
            ],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: colors.panelBorder.withOpacity(0.6),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.glowColor.withOpacity(0.25),
              blurRadius: 35,
              spreadRadius: 3,
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 20,
              offset: const Offset(0, 10),
              spreadRadius: -5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        colors.buttonPrimary.withOpacity(0.2),
                        colors.buttonSecondary.withOpacity(0.15),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.contact_mail_rounded,
                    color: colors.textAccent,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Contact Us',
                        style: TextStyle(
                          color: colors.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'We\'re here to help',
                        style: TextStyle(
                          color: colors.textPrimary.withOpacity(0.5),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(
                    Icons.close_rounded,
                    color: colors.textPrimary.withOpacity(0.5),
                    size: 24,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _ContactOption(
              icon: Icons.email_rounded,
              label: 'Email Support',
              subtitle: 'support@blockblast.com',
              colors: colors,
              onTap: () {},
            ),
            const SizedBox(height: 12),
            _ContactOption(
              icon: Icons.discord_rounded,
              label: 'Discord',
              subtitle: 'Join our community',
              colors: colors,
              onTap: () {},
            ),
            const SizedBox(height: 12),
            _ContactOption(
              icon: Icons.telegram_rounded,
              label: 'Telegram',
              subtitle: 'Get instant support',
              colors: colors,
              onTap: () {},
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _ContactOption extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final GameThemeColors colors;
  final VoidCallback onTap;

  const _ContactOption({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.colors,
    required this.onTap,
  });

  @override
  State<_ContactOption> createState() => _ContactOptionState();
}

class _ContactOptionState extends State<_ContactOption>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scale = Tween(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  widget.colors.panelBorder.withOpacity(0.2),
                  widget.colors.panelBorder.withOpacity(0.1),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: widget.colors.panelBorder.withOpacity(0.35),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: widget.colors.glowColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    widget.icon,
                    color: widget.colors.textAccent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.label,
                        style: TextStyle(
                          color: widget.colors.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        widget.subtitle,
                        style: TextStyle(
                          color: widget.colors.textPrimary.withOpacity(0.5),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: widget.colors.textPrimary.withOpacity(0.4),
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingsRow extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool value;
  final GameThemeColors colors;
  final ValueChanged<bool> onChanged;

  const _SettingsRow({
    required this.label,
    required this.icon,
    required this.value,
    required this.colors,
    required this.onChanged,
  });

  @override
  State<_SettingsRow> createState() => _SettingsRowState();
}

class _SettingsRowState extends State<_SettingsRow> {
  late bool _value;

  @override
  void initState() {
    super.initState();
    _value = widget.value;
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.colors;
    return Row(
      children: [
        Icon(widget.icon, color: colors.textPrimary.withOpacity(0.7), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            widget.label,
            style: TextStyle(
              color: colors.textPrimary,
              fontSize: 15,
            ),
          ),
        ),
        Switch.adaptive(
          value: _value,
          onChanged: (v) {
            setState(() => _value = v);
            widget.onChanged(v);
          },
          activeColor: colors.glowColor,
        ),
      ],
    );
  }
}

class _ThemeChips extends StatelessWidget {
  final GameThemeData currentTheme;
  final GameThemeColors colors;
  final ValueChanged<GameThemeData> onThemeSelected;

  const _ThemeChips({
    required this.currentTheme,
    required this.colors,
    required this.onThemeSelected,
  });

  @override
  Widget build(BuildContext context) {
    final themes = ThemeRegistry.themes.values.toList();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: themes.map((t) {
        final isActive = t.type == currentTheme.type;
        return GestureDetector(
          onTap: () => onThemeSelected(t),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: isActive
                  ? colors.buttonPrimary.withOpacity(0.3)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isActive
                    ? colors.panelBorder
                    : colors.panelBorder.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Text(
              t.name,
              style: TextStyle(
                color: isActive
                    ? colors.textAccent
                    : colors.textPrimary.withOpacity(0.5),
                fontSize: 12,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
