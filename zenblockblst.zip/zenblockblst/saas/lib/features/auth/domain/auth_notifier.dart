import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../data/auth_repository.dart';
import '../data/user_repository.dart';
import '../../../core/models/user_model.dart';
import '../../../core/services/location_service.dart';
import '../../starter_rewards/data/starter_rewards_service.dart';

// ─────────────────────────────────────────────
//  AuthStatus
// ─────────────────────────────────────────────
enum AuthStatus { initial, loading, authenticated, unauthenticated, error }

// ─────────────────────────────────────────────
//  AuthState
// ─────────────────────────────────────────────
class AuthState {
  final AuthStatus status;
  final UserModel? user;
  final String?   errorMessage;
  final bool      needsUsername;
  final bool      shouldShowStarterRewards;

  const AuthState({
    this.status       = AuthStatus.initial,
    this.user,
    this.errorMessage,
    this.needsUsername = false,
    this.shouldShowStarterRewards = false,
  });

  AuthState copyWith({
    AuthStatus? status,
    UserModel?  user,
    String?     errorMessage,
    bool?       needsUsername,
    bool?       shouldShowStarterRewards,
  }) => AuthState(
    status:       status       ?? this.status,
    user:         user         ?? this.user,
    errorMessage: errorMessage ?? this.errorMessage,
    needsUsername: needsUsername ?? this.needsUsername,
    shouldShowStarterRewards: shouldShowStarterRewards ?? this.shouldShowStarterRewards,
  );

  bool get isAuthenticated => status == AuthStatus.authenticated;
  bool get isLoading       => status == AuthStatus.loading;
}

// ─────────────────────────────────────────────
//  AuthNotifier
//
//  LOCAL TESTING MODE (Firebase commented out):
//  _init() immediately sets authenticated state
//  with a dummy user so you can see the game.
//
//  TO ENABLE REAL AUTH:
//  Uncomment the Firebase block inside _init()
//  and comment out the bypass block.
// ─────────────────────────────────────────────
class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository  _authRepo;
  final UserRepository  _userRepo;
  final LocationService _locationService;
  final StarterRewardsService _starterRewardsService;
  StreamSubscription? _authSub;

  AuthNotifier(
    this._authRepo,
    this._userRepo,
    this._locationService,
    this._starterRewardsService,
  ) : super(const AuthState()) {
    _init();
  }

  void _init() {
    // Start in loading state to prevent flickering
    state = const AuthState(status: AuthStatus.loading);

    _authSub = _authRepo.authStateChanges.listen((user) async {
      if (user == null) {
        state = const AuthState(status: AuthStatus.unauthenticated);
      } else {
        await _onUserSignedIn(user);
      }
    });
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  Future<void> _onUserSignedIn(User firebaseUser) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      var profile = await _userRepo.getUserProfile(firebaseUser.uid);
      bool shouldShowRewards = false;
      
      if (profile == null) {
        final username = firebaseUser.isAnonymous
            ? 'Player${firebaseUser.uid.substring(0, 4).toUpperCase()}'
            : (firebaseUser.displayName ?? 'Player');
        await _userRepo.createUserProfile(
          uid:      firebaseUser.uid,
          email:    firebaseUser.email ?? '',
          username: username,
          photoUrl: firebaseUser.photoURL,
        );
        profile = await _userRepo.getUserProfile(firebaseUser.uid);
        _fetchAndSaveLocation(firebaseUser.uid);
        
        // Grant starter rewards for new users
        try {
          await _starterRewardsService.grantRewards();
          shouldShowRewards = true;
        } catch (_) {
          // Rewards already granted or error - continue anyway
        }
      } else {
        await _userRepo.touchLastSeen(firebaseUser.uid);
        
        // Check if starter rewards need to be shown for existing users
        if (_starterRewardsService.canGrant(profile)) {
          try {
            await _starterRewardsService.grantRewards();
            shouldShowRewards = true;
          } catch (_) {
            // Rewards already granted or error - continue anyway
          }
        }
      }
      
      state = AuthState(
        status:       AuthStatus.authenticated,
        user:         profile,
        needsUsername: firebaseUser.isAnonymous,
        shouldShowStarterRewards: shouldShowRewards,
      );
    } catch (e) {
      state = state.copyWith(
        status:       AuthStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  Future<void> signInWithGoogle() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInWithGoogle();
    } on AuthException catch (e) {
      state = state.copyWith(
          status: AuthStatus.unauthenticated, errorMessage: e.message);
    }
  }

  Future<void> signInAnonymously() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInAnonymously();
    } on AuthException catch (e) {
      state = state.copyWith(
          status: AuthStatus.unauthenticated, errorMessage: e.message);
    }
  }

  Future<void> signInWithEmail(
      {required String email, required String password}) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      await _authRepo.signInWithEmail(email: email, password: password);
    } on AuthException catch (e) {
      state = state.copyWith(
          status: AuthStatus.unauthenticated, errorMessage: e.message);
    }
  }

  Future<void> createAccount({
    required String email,
    required String password,
    required String username,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final cred = await _authRepo.createUserWithEmail(
          email: email, password: password);
      if (cred.user != null) {
        await _userRepo.createUserProfile(
          uid: cred.user!.uid, email: email, username: username);
      }
    } on AuthException catch (e) {
      state = state.copyWith(
          status: AuthStatus.unauthenticated, errorMessage: e.message);
    }
  }

  Future<bool> setUsername(String username) async {
    final uid = _authRepo.currentUid;
    if (uid == null) {
      state = state.copyWith(errorMessage: 'User not authenticated');
      return false;
    }
    try {
      await _userRepo.updateUsername(uid, username);
      state = state.copyWith(
        needsUsername: false,
        user: state.user?.copyWith(username: username),
      );
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: e.toString());
      return false;
    }
  }

  Future<void> _fetchAndSaveLocation(String uid) async {
    final result = await _locationService.getLocation();
    if (result == null) return;
    await _userRepo.updateLocation(
      uid:         uid,
      latitude:    result.latitude,
      longitude:   result.longitude,
      country:     result.country,
      countryName: result.countryName,
    );
  }

  Future<void> signOut() async {
    await _authRepo.signOut();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  void clearError() => state = state.copyWith(errorMessage: null);
  
  void clearStarterRewardsFlag() => state = state.copyWith(shouldShowStarterRewards: false);
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────
final authNotifierProvider =
    StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(
    ref.read(authRepositoryProvider),
    ref.read(userRepositoryProvider),
    ref.read(locationServiceProvider),
    ref.read(starterRewardsServiceProvider),
  );
});
