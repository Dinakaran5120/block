import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/game_theme.dart';

// ─────────────────────────────────────────────
//  Starter Rewards Popup
//  Premium animated popup showing welcome rewards
// ─────────────────────────────────────────────

class StarterRewardsPopup extends ConsumerStatefulWidget {
  final GameThemeData theme;
  final VoidCallback onDismiss;

  const StarterRewardsPopup({
    super.key,
    required this.theme,
    required this.onDismiss,
  });

  @override
  ConsumerState<StarterRewardsPopup> createState() => _StarterRewardsPopupState();
}

class _StarterRewardsPopupState extends ConsumerState<StarterRewardsPopup>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _fade = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.4, curve: Curves.easeIn)),
    );

    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = widget.theme.colors;

    return GestureDetector(
      onTap: widget.onDismiss,
      child: Container(
        color: Colors.black.withOpacity(0.8 * _fade.value),
        child: SafeArea(
          child: Center(
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (ctx, _) => Transform.scale(
                scale: _scale.value,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 24),
                  constraints: const BoxConstraints(maxWidth: 400),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Container(
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            colors.panelBg,
                            colors.panelBg.withOpacity(0.85),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: colors.panelBorder.withOpacity(0.8), width: 2),
                        boxShadow: [
                          BoxShadow(color: colors.glowColor.withOpacity(0.5), blurRadius: 50, spreadRadius: 5),
                          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30, offset: const Offset(0, 10), spreadRadius: -5),
                          BoxShadow(color: Colors.white.withOpacity(0.1), blurRadius: 10, offset: const Offset(-2, -2), spreadRadius: -2),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Glow bar
                          Container(
                            height: 3,
                            width: 60,
                            margin: const EdgeInsets.only(bottom: 20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.transparent, colors.glowColor, Colors.transparent],
                              ),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          
                          // Icon
                          Container(
                            width: 70,
                            height: 70,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [colors.buttonPrimary, colors.buttonSecondary],
                              ),
                              boxShadow: [
                                BoxShadow(color: colors.glowColor.withOpacity(0.6), blurRadius: 20, spreadRadius: 2),
                              ],
                            ),
                            child: const Icon(Icons.card_giftcard_rounded, color: Colors.white, size: 36),
                          ),
                          
                          const SizedBox(height: 16),
                          
                          // Title
                          Text(
                            'WELCOME BONUS!',
                            style: TextStyle(
                              color: colors.textPrimary,
                              fontSize: 24,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                              shadows: [
                                Shadow(color: colors.glowColor.withOpacity(0.6), blurRadius: 12),
                              ],
                            ),
                          ),
                          
                          const SizedBox(height: 8),
                          
                          // Subtitle
                          Text(
                            'Here are your starter powerups',
                            style: TextStyle(
                              color: colors.textPrimary.withOpacity(0.6),
                              fontSize: 13,
                            ),
                          ),
                          
                          const SizedBox(height: 20),
                          
                          // Powerup grid
                          _PowerupGrid(colors: colors),
                          
                          const SizedBox(height: 24),
                          
                          // Claim button
                          GestureDetector(
                            onTap: widget.onDismiss,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [colors.buttonPrimary, colors.buttonSecondary],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(color: colors.panelBorder.withOpacity(0.8), width: 1.5),
                                boxShadow: [
                                  BoxShadow(color: colors.glowColor.withOpacity(0.5), blurRadius: 25, spreadRadius: 2),
                                  BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 5), spreadRadius: -3),
                                  BoxShadow(color: Colors.white.withOpacity(0.12), blurRadius: 6, offset: const Offset(-1, -1), spreadRadius: -1),
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text('🎁', style: TextStyle(fontSize: 20)),
                                  const SizedBox(width: 8),
                                  Text(
                                    'CLAIM REWARDS',
                                    style: TextStyle(
                                      color: colors.textPrimary,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 2,
                                      shadows: [
                                        Shadow(color: colors.glowColor.withOpacity(0.5), blurRadius: 8),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 12),
                          
                          Text(
                            'Tap anywhere to continue',
                            style: TextStyle(
                              color: colors.textPrimary.withOpacity(0.3),
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PowerupGrid extends StatelessWidget {
  final GameThemeColors colors;
  const _PowerupGrid({required this.colors});

  @override
  Widget build(BuildContext context) {
    final powerups = [
      {'emoji': '🔨', 'name': 'Hammer', 'count': 1},
      {'emoji': '💣', 'name': 'Bomb', 'count': 1},
      {'emoji': '🌈', 'name': 'Rainbow', 'count': 1},
      {'emoji': '🔀', 'name': 'Shuffle', 'count': 1},
      {'emoji': '⚡', 'name': 'Lightning', 'count': 1},
      {'emoji': '🎯', 'name': 'Combo', 'count': 1},
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 1.0,
          ),
          itemCount: powerups.length,
          itemBuilder: (context, index) {
            final powerup = powerups[index];
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    colors.panelBg,
                    colors.panelBg.withOpacity(0.85),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: colors.panelBorder.withOpacity(0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(color: colors.glowColor.withOpacity(0.2), blurRadius: 12, spreadRadius: 1),
                  BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 3), spreadRadius: -2),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(powerup['emoji'] as String, style: const TextStyle(fontSize: 28)),
                  const SizedBox(height: 2),
                  Text(
                    powerup['name'] as String,
                    style: TextStyle(
                      color: colors.textPrimary,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    'x${powerup['count']}',
                    style: TextStyle(
                      color: colors.textAccent,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
