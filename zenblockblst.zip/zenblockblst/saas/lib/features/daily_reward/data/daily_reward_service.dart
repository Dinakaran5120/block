import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/models/user_model.dart';
import '../../auth/data/auth_repository.dart';
import '../../auth/data/user_repository.dart';
import '../../auth/domain/auth_notifier.dart';

// ─────────────────────────────────────────────
//  DailyRewardService
//  Tracks: last claim timestamp, streak count
//  Stores in: /users/{uid}.lastDailyRewardAt
//             /users/{uid}.dailyRewardStreak
// ─────────────────────────────────────────────

class DailyRewardResult {
  final bool claimed;
  final int coinsEarned;
  final int streak;
  final DailyRewardDay rewardDay;
  final String? bonusItem;
  final String message;

  const DailyRewardResult({
    required this.claimed,
    required this.coinsEarned,
    required this.streak,
    required this.rewardDay,
    this.bonusItem,
    required this.message,
  });
}

class DailyRewardService {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;
  final UserRepository _userRepo;

  DailyRewardService({
    required FirebaseFirestore db,
    required AuthRepository authRepo,
    required UserRepository userRepo,
  })  : _db = db,
        _authRepo = authRepo,
        _userRepo = userRepo;

  // ── Check if reward is available ──────────
  bool canClaim(UserModel user) {
    if (user.lastDailyRewardAt == null) return true;
    final now = DateTime.now();
    final last = user.lastDailyRewardAt!;
    // Check if it's a new calendar day (UTC)
    return !_isSameDay(now, last);
  }

  // ── Time until next reward ────────────────
  Duration timeUntilNextReward(UserModel user) {
    if (user.lastDailyRewardAt == null) return Duration.zero;
    final nextMidnight = DateTime(
      user.lastDailyRewardAt!.year,
      user.lastDailyRewardAt!.month,
      user.lastDailyRewardAt!.day + 1,
    );
    final diff = nextMidnight.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff;
  }

  // ── Claim reward ──────────────────────────
  Future<DailyRewardResult> claimReward() async {
    final uid = _authRepo.currentUid;
    if (uid == null) throw Exception('Not authenticated');

    final user = await _userRepo.getUserProfile(uid);
    if (user == null) throw Exception('User not found');

    if (!canClaim(user)) {
      throw Exception('Reward already claimed today');
    }

    // Calculate new streak
    int newStreak = 1;
    if (user.lastDailyRewardAt != null) {
      final yesterday = DateTime.now().subtract(const Duration(days: 1));
      if (_isSameDay(yesterday, user.lastDailyRewardAt!)) {
        // Consecutive day — continue streak
        newStreak = (user.dailyRewardStreak % 7) + 1;
      }
      // else streak resets to 1
    }

    // Get reward for streak day (1-7, repeating)
    final rewardDay = dailyRewardSchedule[(newStreak - 1) % 7];
    final coins = rewardDay.coins;

    // Atomic Firestore update
    final docRef = _db.collection('users').doc(uid);
    await _db.runTransaction((tx) async {
      tx.update(docRef, {
        'coins': FieldValue.increment(coins),
        'lastDailyRewardAt': Timestamp.fromDate(DateTime.now()),
        'dailyRewardStreak': newStreak,
      });
    });

    // Also log to reward_history sub-collection
    await docRef.collection('reward_history').add({
      'day': rewardDay.day,
      'coins': coins,
      'streak': newStreak,
      'bonusItem': rewardDay.bonusItem,
      'claimedAt': Timestamp.fromDate(DateTime.now()),
    });

    return DailyRewardResult(
      claimed: true,
      coinsEarned: coins,
      streak: newStreak,
      rewardDay: rewardDay,
      bonusItem: rewardDay.bonusItem,
      message: newStreak >= 7
          ? '🎉 Week complete! Bonus unlocked!'
          : '🌟 Day $newStreak streak!',
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}

// ─────────────────────────────────────────────
//  DailyRewardState + Notifier
// ─────────────────────────────────────────────

class DailyRewardState {
  final bool canClaim;
  final int currentStreak;
  final Duration? timeUntilNext;
  final DailyRewardResult? lastResult;
  final bool isLoading;
  final String? error;

  const DailyRewardState({
    this.canClaim = false,
    this.currentStreak = 0,
    this.timeUntilNext,
    this.lastResult,
    this.isLoading = false,
    this.error,
  });

  DailyRewardState copyWith({
    bool? canClaim,
    int? currentStreak,
    Duration? timeUntilNext,
    DailyRewardResult? lastResult,
    bool? isLoading,
    String? error,
  }) =>
      DailyRewardState(
        canClaim: canClaim ?? this.canClaim,
        currentStreak: currentStreak ?? this.currentStreak,
        timeUntilNext: timeUntilNext ?? this.timeUntilNext,
        lastResult: lastResult ?? this.lastResult,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

class DailyRewardNotifier extends StateNotifier<DailyRewardState> {
  final DailyRewardService _service;
  final UserRepository _userRepo;
  final String? _uid;
  Timer? _timer;

  DailyRewardNotifier(this._service, this._userRepo, this._uid)
      : super(const DailyRewardState()) {
    _loadStatus();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_uid != null) {
        _loadStatus();
      }
    });
  }

  Future<void> _loadStatus() async {
    if (_uid == null) return;
    final user = await _userRepo.getUserProfile(_uid);
    if (user == null) return;

    state = state.copyWith(
      canClaim: _service.canClaim(user),
      currentStreak: user.dailyRewardStreak,
      timeUntilNext: _service.timeUntilNextReward(user),
    );
  }

  Future<DailyRewardResult?> claimReward() async {
    state = state.copyWith(isLoading: true);
    try {
      final result = await _service.claimReward();
      state = state.copyWith(
        isLoading: false,
        canClaim: false,
        currentStreak: result.streak,
        lastResult: result,
      );
      return result;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return null;
    }
  }

  void refresh() => _loadStatus();
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final dailyRewardServiceProvider = Provider<DailyRewardService>((ref) {
  return DailyRewardService(
    db: FirebaseFirestore.instance,
    authRepo: ref.read(authRepositoryProvider),
    userRepo: ref.read(userRepositoryProvider),
  );
});

final dailyRewardProvider =
    StateNotifierProvider<DailyRewardNotifier, DailyRewardState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return DailyRewardNotifier(
    ref.read(dailyRewardServiceProvider),
    ref.read(userRepositoryProvider),
    uid,
  );
});
