import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'store_models.dart';
import '../auth/data/auth_repository.dart';
import '../auth/data/user_repository.dart';
import '../auth/domain/auth_notifier.dart';
import '../../core/analytics/analytics_service.dart';

// ─────────────────────────────────────────────
//  StoreRepository — purchase + inventory sync
// ─────────────────────────────────────────────

class StoreRepository {
  final FirebaseFirestore _db;
  final AuthRepository _authRepo;
  final UserRepository _userRepo;
  final AnalyticsService _analytics;

  StoreRepository({
    required AuthRepository authRepo,
    required UserRepository userRepo,
    required AnalyticsService analytics,
    FirebaseFirestore? db,
  })  : _db = db ?? FirebaseFirestore.instance,
        _authRepo = authRepo,
        _userRepo = userRepo,
        _analytics = analytics;

  DocumentReference<Map<String, dynamic>> _userDoc(String uid) =>
      _db.collection('users').doc(uid);

  // ── Load inventory ────────────────────────
  Future<Inventory> loadInventory(String uid) async {
    final snap = await _userDoc(uid).get();
    final data = snap.data()?['inventory'] as Map<String, dynamic>?;
    return data != null ? Inventory.fromMap(data) : Inventory.empty;
  }

  Stream<Inventory> watchInventory(String uid) {
    return _userDoc(uid).snapshots().map((snap) {
      final data = snap.data()?['inventory'] as Map<String, dynamic>?;
      return data != null ? Inventory.fromMap(data) : Inventory.empty;
    });
  }

  // ── Purchase item with coins ──────────────
  Future<PurchaseResult> purchaseItem({
    required String uid,
    required StoreItem item,
    required int currentCoins,
  }) async {
    if (currentCoins < item.coinPrice) {
      return PurchaseResult.insufficient(item.coinPrice - currentCoins);
    }

    try {
      final inventory = await loadInventory(uid);

      // Themes can't be re-bought
      if (item.category == ItemCategory.theme &&
          inventory.unlockedThemes.contains(item.metadata['themeId'])) {
        return PurchaseResult.alreadyOwned();
      }

      await _db.runTransaction((tx) async {
        final ref = _userDoc(uid);
        final snap = await tx.get(ref);
        final coins = (snap.data()?['coins'] as num?)?.toInt() ?? 0;

        if (coins < item.coinPrice) {
          throw Exception('Insufficient coins');
        }

        final currentInv = Inventory.fromMap(
            snap.data()?['inventory'] as Map<String, dynamic>? ?? {});

        Inventory updatedInv = _applyPurchase(currentInv, item);

        tx.update(ref, {
          'coins': FieldValue.increment(-item.coinPrice),
          'inventory': updatedInv.toMap(),
        });
      });

      await _analytics.logPurchase(
        itemId: item.id,
        itemName: item.name,
        coinCost: item.coinPrice,
      );

      return PurchaseResult.success(item);
    } catch (e) {
      return PurchaseResult.error(e.toString());
    }
  }

  // ── Apply purchase to inventory ───────────
  Inventory _applyPurchase(Inventory inv, StoreItem item) {
    final count = item.quantity ?? (item.metadata['count'] as int? ?? 1);

    if (item.category == ItemCategory.theme) {
      final newThemes = {...inv.unlockedThemes, item.metadata['themeId'] as String};
      return inv.copyWith(
        ownedItems: {...inv.ownedItems, item.id},
        unlockedThemes: newThemes,
      );
    }

    if (item.powerupType != null) {
      return switch (item.powerupType!) {
        PowerupType.hammer =>
          inv.copyWith(hammers: inv.hammers + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.bomb =>
          inv.copyWith(bombs: inv.bombs + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.lightning =>
          inv.copyWith(lightnings: inv.lightnings + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.shuffle =>
          inv.copyWith(shuffles: inv.shuffles + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.rainbow =>
          inv.copyWith(rainbows: inv.rainbows + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.comboBooster =>
          inv.copyWith(comboBoosters: inv.comboBoosters + count, ownedItems: {...inv.ownedItems, item.id}),
        PowerupType.freezeTime =>
          inv.copyWith(freezes: inv.freezes + count, ownedItems: {...inv.ownedItems, item.id}),
        _ => inv.copyWith(ownedItems: {...inv.ownedItems, item.id}),
      };
    }

    return inv.copyWith(ownedItems: {...inv.ownedItems, item.id});
  }

  // ── Use a powerup ─────────────────────────
  Future<bool> usePowerup(String uid, PowerupType type, Inventory current) async {
    final count = current.countForPowerup(type);
    if (count <= 0) return false;

    final field = switch (type) {
      PowerupType.hammer => 'inventory.hammers',
      PowerupType.bomb => 'inventory.bombs',
      PowerupType.lightning => 'inventory.lightnings',
      PowerupType.shuffle => 'inventory.shuffles',
      PowerupType.rainbow => 'inventory.rainbows',
      PowerupType.comboBooster => 'inventory.comboBoosters',
      PowerupType.freezeTime => 'inventory.freezes',
      _ => null,
    };

    if (field == null) return false;
    await _userDoc(uid).update({field: FieldValue.increment(-1)});
    return true;
  }

  // ── Grant chest reward ────────────────────
  Future<void> grantChestReward(String uid, ChestReward reward) async {
    final updates = <String, dynamic>{};
    if (reward.coins != null) {
      updates['coins'] = FieldValue.increment(reward.coins!);
    }
    if (reward.powerup != null) {
      final field = switch (reward.powerup!) {
        PowerupType.hammer => 'inventory.hammers',
        PowerupType.bomb => 'inventory.bombs',
        PowerupType.lightning => 'inventory.lightnings',
        PowerupType.shuffle => 'inventory.shuffles',
        PowerupType.rainbow => 'inventory.rainbows',
        PowerupType.comboBooster => 'inventory.comboBoosters',
        PowerupType.freezeTime => 'inventory.freezes',
        _ => null,
      };
      if (field != null) {
        updates[field] = FieldValue.increment(reward.powerupCount);
      }
    }
    if (updates.isNotEmpty) {
      await _userDoc(uid).update(updates);
    }
  }

  // ── Add coins (from ads, spin, rewards) ───
  Future<void> addCoins(String uid, int amount) async {
    await _userDoc(uid).update({'coins': FieldValue.increment(amount)});
  }

  // ── Update high score ───────────────────────
  Future<void> updateHighScore(String uid, int highScore) async {
    await _userDoc(uid).update({'highScore': highScore});
  }
}

// ─────────────────────────────────────────────
//  Store Notifier
// ─────────────────────────────────────────────

class StoreNotifier extends StateNotifier<StoreState> {
  final StoreRepository _repo;
  final String? _uid;
  StreamSubscription? _inventorySub;

  StoreNotifier(this._repo, this._uid) : super(const StoreState()) {
    if (_uid != null) _watchInventory();
  }

  void _watchInventory() {
    _inventorySub = _repo.watchInventory(_uid!).listen((inv) {
      state = state.copyWith(inventory: inv);
    });
  }

  @override
  void dispose() {
    _inventorySub?.cancel();
    super.dispose();
  }

  void selectCategory(ItemCategory cat) =>
      state = state.copyWith(selectedCategory: cat, message: null);

  Future<PurchaseResult> purchase(StoreItem item, int coins) async {
    state = state.copyWith(isLoading: true, message: null);
    final result = await _repo.purchaseItem(
      uid: _uid!,
      item: item,
      currentCoins: coins,
    );
    state = state.copyWith(isLoading: false, message: result.message);
    return result;
  }

  void clearMessage() => state = state.copyWith(message: null);
}

// ─────────────────────────────────────────────
//  Providers
// ─────────────────────────────────────────────

final storeRepositoryProvider = Provider<StoreRepository>((ref) => StoreRepository(
  authRepo: ref.read(authRepositoryProvider),
  userRepo: ref.read(userRepositoryProvider),
  analytics: ref.read(analyticsServiceProvider),
));

final storeProvider = StateNotifierProvider<StoreNotifier, StoreState>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  return StoreNotifier(ref.read(storeRepositoryProvider), uid);
});

final inventoryProvider = StreamProvider.autoDispose<Inventory>((ref) {
  final uid = ref.watch(authNotifierProvider).user?.uid;
  if (uid == null) return Stream.value(Inventory.empty);
  return ref.read(storeRepositoryProvider).watchInventory(uid);
});
