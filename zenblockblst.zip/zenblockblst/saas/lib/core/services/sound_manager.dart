import 'package:flame_audio/flame_audio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/game_constants.dart';

// ─────────────────────────────────────────────
//  SoundManager — wraps flame_audio with persistent state
// ─────────────────────────────────────────────

class SoundManager {
  bool _sfxEnabled = true;
  bool _musicEnabled = true;
  String? _currentMusic;
  bool _initialized = false;

  Future<void> preload() async {
    if (_initialized) return;
    
    // Load preferences
    final prefs = await SharedPreferences.getInstance();
    _sfxEnabled = prefs.getBool('sfx_enabled') ?? true;
    _musicEnabled = prefs.getBool('music_enabled') ?? true;
    
    await FlameAudio.audioCache.loadAll([
      'place_block.mp3',
      'line_clear.mp3',
      'combo.mp3',
      'game_over.mp3',
      'tap.mp3',
    ]);
    
    _initialized = true;
  }

  Future<void> playMusic(String file) async {
    if (!_musicEnabled) return;
    if (_currentMusic == file) return;
    await FlameAudio.bgm.stop();
    await FlameAudio.bgm.play(file, volume: GameConstants.musicVolume);
    _currentMusic = file;
  }

  Future<void> stopMusic() async {
    await FlameAudio.bgm.stop();
    _currentMusic = null;
  }

  void playSfx(String file) {
    if (!_sfxEnabled) return;
    FlameAudio.play(file, volume: GameConstants.sfxVolume);
  }

  void placeBlock() => playSfx('place_block.mp3');
  void lineClear() => playSfx('line_clear.mp3');
  void combo()     => playSfx('combo.mp3');
  void gameOver()  => playSfx('game_over.mp3');
  void tap()       => playSfx('tap.mp3');

  Future<void> toggleSfx() async {
    _sfxEnabled = !_sfxEnabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sfx_enabled', _sfxEnabled);
  }

  Future<void> toggleMusic() async {
    _musicEnabled = !_musicEnabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('music_enabled', _musicEnabled);
    
    if (!_musicEnabled) {
      FlameAudio.bgm.pause();
    } else {
      FlameAudio.bgm.resume();
    }
  }

  bool get sfxEnabled   => _sfxEnabled;
  bool get musicEnabled => _musicEnabled;
  bool get initialized => _initialized;
}

final soundManagerProvider = Provider<SoundManager>((ref) => SoundManager());
