import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/performance/performance_optimizer.dart';
import 'core/widgets/app_logo.dart';
import 'core/services/sound_manager.dart';
import 'features/auth/domain/auth_notifier.dart';
import 'features/auth/presentation/login_screen.dart';
import 'features/levels/presentation/levels_page.dart';
import 'features/game/game_screen.dart';

// ─────────────────────────────────────────────
//  main.dart — Block Blast production entry point
// ─────────────────────────────────────────────

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'firebase_options.dart';
import 'core/analytics/analytics_service.dart';
import 'features/admob/admob_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  configureImageCache();

  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform);
  await FirebaseCrashlytics.instance
      .setCrashlyticsCollectionEnabled(true);
  FlutterError.onError =
      FirebaseCrashlytics.instance.recordFlutterFatalError;

  runApp(const ProviderScope(child: BlockBlastApp()));
}

class BlockBlastApp extends ConsumerStatefulWidget {
  const BlockBlastApp({super.key});

  @override
  ConsumerState<BlockBlastApp> createState() => _BlockBlastAppState();
}

class _BlockBlastAppState extends ConsumerState<BlockBlastApp> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    ref.read(performanceProvider);

    // Initialize audio first
    try {
      await ref.read(soundManagerProvider).preload();
      // Start background music
      await ref.read(soundManagerProvider).playMusic('background.mp3');
    } catch (_) {
      // Audio optional — app must still start.
    }

    try {
      await ref.read(analyticsServiceProvider).initialize();
    } catch (_) {
      // Analytics optional — app must still start.
    }

    try {
      await ref
          .read(adMobServiceProvider)
          .initialize()
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // Ads load in background — do not block the splash.
    }

    if (mounted) setState(() => _ready = true);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Block Blast',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF004D99),
          secondary: Color(0xFF007A8A),
        ),
      ),
      home: _ready ? const AppShell() : const _SplashScreen(),
    );
  }
}

// ─────────────────────────────────────────────
//  AppShell — routes based on auth state
// ─────────────────────────────────────────────

class AppShell extends ConsumerWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authNotifierProvider);
    return switch (auth.status) {
      AuthStatus.initial ||
      AuthStatus.loading      => const _SplashScreen(),
      AuthStatus.unauthenticated ||
      AuthStatus.error        => const LoginScreen(),
      AuthStatus.authenticated => auth.needsUsername
          ? const UsernameSetupScreen()
          : const LevelsPage(),
    };
  }
}

// ─────────────────────────────────────────────
//  Splash Screen
// ─────────────────────────────────────────────

class _SplashScreen extends StatefulWidget {
  const _SplashScreen();

  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF040D1A),
      body: SafeArea(
        child: Center(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, __) => LayoutBuilder(
              builder: (context, constraints) {
                final logoSize = (constraints.maxWidth * 0.35).clamp(110.0, 160.0);
                final logoPadding = logoSize * 0.12;
                
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Transform.scale(
                      scale: 0.92 + _ctrl.value * 0.08,
                      child: Container(
                        width: logoSize,
                        height: logoSize,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          color: const Color(0xFF0A1628),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00F5FF)
                                  .withOpacity(0.25 + _ctrl.value * 0.25),
                              blurRadius: 40,
                              spreadRadius: 8,
                            ),
                          ],
                        ),
                        padding: EdgeInsets.all(logoPadding),
                        child: AppLogo(size: logoSize - (logoPadding * 2)),
                      ),
                    ),
                    const SizedBox(height: 28),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFF00F5FF), Color(0xFFBF40FF)],
                      ).createShader(bounds),
                      child: const Text(
                        'BLOCK BLAST',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'NEON EDITION',
                      style: TextStyle(
                        color: Color(0xFF00F5FF),
                        fontSize: 11,
                        letterSpacing: 4,
                      ),
                    ),
                    const SizedBox(height: 40),
                SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: const Color(0xFF00F5FF).withOpacity(0.6),
                    strokeWidth: 2,
                  ),
                ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
